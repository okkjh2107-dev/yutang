import { AlertTriangle, BookOpen, CheckCircle2, Info, RotateCcw, Save } from 'lucide-react';
import { useState } from 'react';
import type { GameState } from '../../types/pond';
import { SectionHeading } from './PanelPrimitives';

interface LogsPanelProps {
  gameState: GameState;
  onResetSave: () => void;
}

export function LogsPanel({ gameState, onResetSave }: LogsPanelProps) {
  const [confirmReset, setConfirmReset] = useState(false);
  const recentLogs = gameState.logs.slice(0, 20);

  return (
    <div className="space-y-4 sm:space-y-5">
      {/* 01. Save Archive Management */}
      <section className="space-y-2.5">
        <SectionHeading
          title="庄园本地存档"
          caption="实时自动保存"
          icon={<Save className="h-4 w-4" />}
        />

        <div className="manor-wood-card flex flex-col gap-3 rounded-2xl p-3 sm:p-3.5 text-xs sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="font-semibold text-[#13221d]">本地浏览器自动存档</div>
            <div className="mt-0.5 text-[11px] text-[#5e5140]">
              自动保留庄园资金、在池鱼群、设施等级与最近 20 条经营日志
            </div>
          </div>

          {!confirmReset ? (
            <button
              type="button"
              onClick={() => setConfirmReset(true)}
              className="inline-flex min-h-[42px] sm:min-h-[38px] w-full sm:w-auto shrink-0 items-center justify-center gap-1.5 rounded-xl border border-[#5e4126]/25 bg-white/80 px-3 py-1.5 text-xs font-semibold text-[#3f3428] transition-colors hover:bg-white cursor-pointer whitespace-nowrap"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>重开存档</span>
            </button>
          ) : (
            <div className="flex w-full sm:w-auto items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => {
                  setConfirmReset(false);
                  onResetSave();
                }}
                className="flex-1 sm:flex-initial min-h-[42px] sm:min-h-[38px] rounded-xl bg-[#a93327] px-3 py-1.5 text-xs font-semibold text-white hover:bg-[#8d281e] cursor-pointer whitespace-nowrap"
              >
                确认重置
              </button>
              <button
                type="button"
                onClick={() => setConfirmReset(false)}
                className="flex-1 sm:flex-initial min-h-[42px] sm:min-h-[38px] rounded-xl border border-[#5d6e67]/25 bg-white/80 px-3 py-1.5 text-xs font-medium text-[#465951] cursor-pointer whitespace-nowrap"
              >
                取消
              </button>
            </div>
          )}
        </div>
      </section>

      {/* 02. Latest 20 Aquaculture Logs */}
      <section className="space-y-2.5">
        <SectionHeading
          title="庄园每日养殖日志"
          caption={`最新 ${recentLogs.length} / 20 条`}
          icon={<BookOpen className="h-4 w-4" />}
        />

        {recentLogs.length === 0 ? (
          <div className="manor-stone-card rounded-2xl p-5 text-center text-xs text-[#556860]">
            暂无养殖日志记录。
          </div>
        ) : (
          <div className="space-y-2">
            {recentLogs.map((entry) => {
              const meta =
                entry.level === 'success'
                  ? { label: '经营捷报', tone: 'text-[#1b5951]', Icon: CheckCircle2 }
                  : entry.level === 'warning'
                    ? { label: '养殖提醒', tone: 'text-[#9e5c14]', Icon: AlertTriangle }
                    : entry.level === 'danger'
                      ? { label: '紧急警报', tone: 'text-[#a93327]', Icon: AlertTriangle }
                      : { label: '日常记录', tone: 'text-[#465951]', Icon: Info };

              const Icon = meta.Icon;

              return (
                <article key={entry.id} className="manor-stone-card rounded-xl px-3 py-2.5 sm:px-3.5 text-xs">
                  <div className="flex items-center justify-between gap-2 text-[11px] tabular-nums">
                    <span className={`inline-flex items-center gap-1 font-semibold ${meta.tone}`}>
                      <Icon className="h-3.5 w-3.5" aria-hidden="true" />
                      <span>{meta.label}</span>
                    </span>
                    <span className="font-medium text-[#5c6f67]">第 {entry.day} 天</span>
                  </div>
                  <p className="mt-1.5 text-[12px] leading-relaxed text-[#13221d]">{entry.message}</p>
                </article>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
