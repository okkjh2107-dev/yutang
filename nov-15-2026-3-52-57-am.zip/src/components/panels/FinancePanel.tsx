import { ArrowDownLeft, ArrowUpRight, Landmark, ReceiptText } from 'lucide-react';
import type { GameState } from '../../types/pond';
import { SectionHeading } from './PanelPrimitives';

interface FinancePanelProps {
  gameState: GameState;
}

export function FinancePanel({ gameState }: FinancePanelProps) {
  const netProfit = gameState.totalRevenue - gameState.totalExpense;
  const totalTurnover = Math.max(1, gameState.totalRevenue + gameState.totalExpense);
  const revenueRatioPct = Math.round((gameState.totalRevenue / totalTurnover) * 100);
  const recentTransactions = gameState.transactions.slice(0, 20);

  return (
    <div className="space-y-4 sm:space-y-5">
      {/* 01. Core Financial Ledger KPIs */}
      <section className="space-y-2.5">
        <SectionHeading
          title="庄园资产与收支总览"
          caption={`第 ${gameState.day} 天累计`}
          icon={<Landmark className="h-4 w-4" />}
        />

        <div className="grid grid-cols-2 gap-2 sm:gap-2.5">
          <div className="manor-jade-card rounded-2xl p-3 sm:p-3.5">
            <div className="text-[11px] font-medium text-[#3b5d56]">累计营业收入</div>
            <div className="mt-1 font-display text-base sm:text-lg font-semibold text-[#1b5951] tabular-nums truncate">
              ¥{gameState.totalRevenue.toLocaleString('zh-CN')}
            </div>
          </div>

          <div className="manor-wood-card rounded-2xl p-3 sm:p-3.5">
            <div className="text-[11px] font-medium text-[#705330]">累计养殖支出</div>
            <div className="mt-1 font-display text-base sm:text-lg font-semibold text-[#9e5c14] tabular-nums truncate">
              ¥{gameState.totalExpense.toLocaleString('zh-CN')}
            </div>
          </div>

          <div className="manor-stone-card rounded-2xl p-3 sm:p-3.5">
            <div className="text-[11px] font-medium text-[#556860]">经营净利润</div>
            <div
              className={`mt-1 font-display text-base sm:text-lg font-semibold tabular-nums truncate ${
                netProfit >= 0 ? 'text-[#1b5951]' : 'text-[#a93327]'
              }`}
            >
              {netProfit >= 0 ? '+' : ''}¥{netProfit.toLocaleString('zh-CN')}
            </div>
          </div>

          <div className="manor-stone-card rounded-2xl p-3 sm:p-3.5">
            <div className="text-[11px] font-medium text-[#556860]">累计出栏 / 钓获</div>
            <div className="mt-1 font-display text-base sm:text-lg font-semibold text-[#13221d] tabular-nums">
              {gameState.totalHarvestedCount} 尾
            </div>
          </div>
        </div>

        {/* Revenue vs Expense Balance Bar */}
        <div className="manor-stone-card rounded-xl p-3 text-[11px] tabular-nums">
          <div className="flex items-center justify-between text-[#465951]">
            <span>收入占比 {revenueRatioPct}%</span>
            <span>支出占比 {100 - revenueRatioPct}%</span>
          </div>
          <div className="mt-1.5 flex h-2 w-full overflow-hidden rounded-full bg-[#9e5c14]/25">
            <div
              className="h-full bg-gradient-to-r from-[#1b5951] to-[#2e8577] transition-all duration-300"
              style={{ width: `${revenueRatioPct}%` }}
            />
          </div>
        </div>
      </section>

      {/* 02. Latest 20 Transactions */}
      <section className="space-y-2.5">
        <SectionHeading
          title="近期收支流水明细"
          caption={`最新 ${recentTransactions.length} / 20 条`}
          icon={<ReceiptText className="h-4 w-4" />}
        />

        {recentTransactions.length === 0 ? (
          <div className="manor-stone-card rounded-2xl p-5 text-center text-xs text-[#556860]">
            暂无收支流水记录。
          </div>
        ) : (
          <div className="manor-stone-card divide-y divide-[#5d6e67]/12 overflow-hidden rounded-2xl">
            {recentTransactions.map((tx) => {
              const isIncome = tx.type === 'income';
              return (
                <div
                  key={tx.id}
                  className="flex items-center justify-between gap-2.5 px-3 py-2.5 sm:px-3.5 text-xs transition-colors hover:bg-white/60"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div
                      aria-hidden="true"
                      className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-lg ${
                        isIncome
                          ? 'bg-[#1b5951]/12 text-[#1b5951]'
                          : 'bg-[#a93327]/10 text-[#a93327]'
                      }`}
                    >
                      {isIncome ? (
                        <ArrowDownLeft className="h-3.5 w-3.5" />
                      ) : (
                        <ArrowUpRight className="h-3.5 w-3.5" />
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="font-medium text-[#13221d] truncate">{tx.description}</div>
                      <div className="text-[11px] text-[#5c6f67] tabular-nums">
                        第 {tx.day} 天 · {tx.category}
                      </div>
                    </div>
                  </div>
                  <div
                    className={`font-semibold tabular-nums shrink-0 ${
                      isIncome ? 'text-[#1b5951]' : 'text-[#a93327]'
                    }`}
                  >
                    {isIncome ? '+' : '-'}¥{tx.amount.toFixed(0)}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
