import { Minus, Package, Plus, ShoppingBag } from 'lucide-react';
import { useState } from 'react';
import {
  FEED_CATALOG,
  FEED_LIST,
  FEED_STANDARD_CAPACITY_KG,
  FISH_SPECIES_LIST,
  getPondTier,
} from '../../game/catalog';
import { getEffectiveFeedBagPrice, getEffectiveFryPrice } from '../../game/simulation';
import type { AdRewardType, FeedTypeId, FishSpeciesId, GameState } from '../../types/pond';
import { AutomationRow, SectionHeading, SpeciesEmblem } from './PanelPrimitives';

interface ShopPanelProps {
  gameState: GameState;
  onBuyFry: (speciesId: FishSpeciesId, qty: number) => void;
  onBuyFeed: (feedId: FeedTypeId, bags: number) => void;
  onToggleAutoRestock: () => void;
  onWatchAd: (adType: AdRewardType) => void;
}

export function ShopPanel({
  gameState,
  onBuyFry,
  onBuyFeed,
  onToggleAutoRestock,
  onWatchAd,
}: ShopPanelProps) {
  const [shopSection, setShopSection] = useState<'fry' | 'feed'>('fry');
  const [fryQtyMap, setFryQtyMap] = useState<Record<FishSpeciesId, number>>({
    grass_carp: 2,
    common_carp: 2,
    tilapia: 2,
  });
  const [feedBagsMap, setFeedBagsMap] = useState<Record<FeedTypeId, number>>({
    standard: 1,
    high_protein: 1,
  });

  const { pond, fishes } = gameState;
  const currentTier = getPondTier(pond.facilityLevel);
  const remainingSlots = Math.max(0, pond.maxRecommendedFish - fishes.length);

  return (
    <div className="space-y-4">
      <AutomationRow
        title="自动买鱼苗与鱼饲料"
        description={`鱼塘鱼数未过半(<${Math.floor(pond.maxRecommendedFish / 2)}尾)或饲料未过半(<${FEED_STANDARD_CAPACITY_KG / 2}kg)时自动补购`}
        unlocked={gameState.autoRestockUnlocked}
        enabled={gameState.autoRestockEnabled}
        activeLabel="自动开启中"
        pausedLabel="已暂停"
        adLabel="看广告自动买"
        onToggle={onToggleAutoRestock}
        onWatchAd={() => onWatchAd('auto_restock')}
      />

      {currentTier.purchaseCostMultiplier < 1 && (
        <div className="manor-jade-card rounded-xl px-3.5 py-2.5 text-xs font-medium text-[#134740]">
          庄园等级特惠已生效：鱼苗与鱼饲料采购按{' '}
          <span className="font-semibold tabular-nums">
            {Math.round(currentTier.purchaseCostMultiplier * 100)}%
          </span>{' '}
          结算。
        </div>
      )}

      {/* Segmented Category Switcher */}
      <div className="grid grid-cols-2 gap-1.5 rounded-xl border border-[#5e4126]/20 bg-[#13221d]/6 p-1">
        <button
          type="button"
          onClick={() => setShopSection('fry')}
          className={`min-h-[40px] sm:min-h-[36px] rounded-lg px-2 text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
            shopSection === 'fry'
              ? 'bg-white/95 text-[#13221d] shadow-xs'
              : 'text-[#4c5f58] hover:text-[#13221d]'
          }`}
        >
          食用鱼苗（余位 {remainingSlots}）
        </button>
        <button
          type="button"
          onClick={() => setShopSection('feed')}
          className={`min-h-[40px] sm:min-h-[36px] rounded-lg px-2 text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
            shopSection === 'feed'
              ? 'bg-white/95 text-[#13221d] shadow-xs'
              : 'text-[#4c5f58] hover:text-[#13221d]'
          }`}
        >
          生态鱼饲料
        </button>
      </div>

      {shopSection === 'fry' ? (
        <section className="space-y-3">
          <SectionHeading
            title="鲜活食用鱼苗供应"
            caption={`可投放余位 ${remainingSlots} 尾`}
            icon={<ShoppingBag className="h-4 w-4" />}
          />

          <div className="space-y-3">
            {FISH_SPECIES_LIST.map((spec) => {
              const qty = fryQtyMap[spec.id] ?? 1;
              const unitPrice = getEffectiveFryPrice(spec, gameState);
              const totalCost = unitPrice * qty;
              const canFit = qty <= remainingSlots;
              const canAfford = gameState.funds >= totalCost;

              return (
                <article key={spec.id} className="manor-stone-card rounded-2xl p-3.5 space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-2.5 min-w-0">
                      <SpeciesEmblem speciesId={spec.id} />
                      <div className="min-w-0">
                        <div className="flex items-baseline gap-2">
                          <h4 className="font-display text-sm font-semibold text-[#13221d]">
                            {spec.name}
                          </h4>
                          <span className="text-[11px] font-medium text-[#1b5951]">生态食用鱼</span>
                        </div>
                        <p className="mt-0.5 text-[11.5px] leading-relaxed text-[#556860]">
                          {spec.description}
                        </p>
                      </div>
                    </div>

                    <div className="text-right shrink-0 tabular-nums">
                      <div className="font-display text-base font-semibold text-[#9e5c14]">
                        ¥{unitPrice}
                      </div>
                      {unitPrice < spec.fryPrice && (
                        <div className="text-[11px] text-[#6d7d76] line-through">¥{spec.fryPrice}</div>
                      )}
                      <div className="text-[10.5px] text-[#556860]">单尾鱼苗</div>
                    </div>
                  </div>

                  <div className="manor-divider" />

                  <div className="grid grid-cols-3 gap-2 text-[11px] text-[#465951] tabular-nums">
                    <div>
                      <span className="text-[#6d7d76]">初始体重 </span>
                      <span className="font-semibold text-[#13221d]">{spec.initialWeightKg} kg</span>
                    </div>
                    <div>
                      <span className="text-[#6d7d76]">成鱼标准 </span>
                      <span className="font-semibold text-[#13221d]">{spec.marketWeightKg} kg</span>
                    </div>
                    <div className="truncate">
                      <span className="text-[#6d7d76]">偏爱 </span>
                      <span className="font-semibold text-[#1b5951]">
                        {FEED_CATALOG[spec.preferredFeed].name}
                      </span>
                    </div>
                  </div>

                  <div className="flex flex-col gap-2 min-[380px]:flex-row min-[380px]:items-center">
                    <div className="flex h-10 items-center justify-between rounded-xl border border-[#5e4126]/20 bg-white/75 px-1 sm:w-auto">
                      <button
                        type="button"
                        onClick={() =>
                          setFryQtyMap((prev) => ({
                            ...prev,
                            [spec.id]: Math.max(1, (prev[spec.id] ?? 1) - 1),
                          }))
                        }
                        aria-label="减少鱼苗数量"
                        className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-[#2c3e37] hover:bg-[#13221d]/8 cursor-pointer"
                      >
                        <Minus className="h-3.5 w-3.5" />
                      </button>
                      <span className="w-10 text-center text-xs font-semibold text-[#13221d] tabular-nums">
                        {qty} 尾
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          setFryQtyMap((prev) => ({
                            ...prev,
                            [spec.id]: Math.min(50, (prev[spec.id] ?? 1) + 1),
                          }))
                        }
                        aria-label="增加鱼苗数量"
                        className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-[#2c3e37] hover:bg-[#13221d]/8 cursor-pointer"
                      >
                        <Plus className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          setFryQtyMap((prev) => ({
                            ...prev,
                            [spec.id]: Math.min(50, (prev[spec.id] ?? 1) + 5),
                          }))
                        }
                        aria-label="增加5尾鱼苗"
                        className="inline-flex h-7 items-center justify-center rounded-md bg-[#1b5951]/10 px-1.5 text-[11px] font-semibold text-[#1b5951] hover:bg-[#1b5951]/18 cursor-pointer tabular-nums"
                      >
                        +5
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={() => onBuyFry(spec.id, qty)}
                      className={`inline-flex min-h-[40px] flex-1 items-center justify-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-semibold transition-all cursor-pointer ${
                        canFit && canAfford
                          ? 'bg-gradient-to-r from-[#1b5951] to-[#267367] text-white shadow-xs hover:brightness-105'
                          : 'border border-[#5d6e67]/25 bg-white/60 text-[#556860] hover:bg-white/85'
                      }`}
                    >
                      <ShoppingBag className="h-3.5 w-3.5 shrink-0" />
                      <span className="tabular-nums">
                        {!canFit
                          ? '鱼塘容量不足'
                          : !canAfford
                            ? `资金不足 (¥${totalCost})`
                            : `购买投放 (¥${totalCost})`}
                      </span>
                    </button>
                  </div>
                </article>
              );
            })}
          </div>
        </section>
      ) : (
        <section className="space-y-3">
          <SectionHeading
            title="生态颗粒鱼饲料库存"
            caption={`标准仓容 ${FEED_STANDARD_CAPACITY_KG} kg / 种`}
            icon={<Package className="h-4 w-4" />}
          />

          <div className="space-y-3">
            {FEED_LIST.map((feed) => {
              const bags = feedBagsMap[feed.id] ?? 1;
              const bagPrice = getEffectiveFeedBagPrice(feed, gameState);
              const cost = bagPrice * bags;
              const currentKg = gameState.feedInventory[feed.id];
              const isBelowHalf = currentKg < feed.standardCapacityKg / 2;
              const invPct = Math.min(100, (currentKg / feed.standardCapacityKg) * 100);

              return (
                <article key={feed.id} className="manor-stone-card rounded-2xl p-3.5 space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-baseline gap-2">
                        <h4 className="font-display text-sm font-semibold text-[#13221d]">
                          {feed.name}
                        </h4>
                        <span
                          className={`text-[11px] font-semibold tabular-nums ${
                            isBelowHalf ? 'text-[#9e5c14]' : 'text-[#1b5951]'
                          }`}
                        >
                          库存 {currentKg.toFixed(1)} / {feed.standardCapacityKg} kg
                          {isBelowHalf && ' · 未过半'}
                        </span>
                      </div>
                      <p className="mt-0.5 text-[11.5px] leading-relaxed text-[#556860]">
                        {feed.description}
                      </p>
                    </div>

                    <div className="text-right shrink-0 tabular-nums">
                      <div className="font-display text-base font-semibold text-[#9e5c14]">
                        ¥{bagPrice}
                      </div>
                      {bagPrice < feed.pricePerBag && (
                        <div className="text-[11px] text-[#6d7d76] line-through">
                          ¥{feed.pricePerBag}
                        </div>
                      )}
                      <div className="text-[10.5px] text-[#556860]">/ {feed.bagWeightKg}kg 袋</div>
                    </div>
                  </div>

                  {/* Inventory Fill Gauge */}
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-[#13221d]/10">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        isBelowHalf
                          ? 'bg-gradient-to-r from-[#b86d15] to-[#df9936]'
                          : 'bg-gradient-to-r from-[#1b5951] to-[#2e8577]'
                      }`}
                      style={{ width: `${Math.max(4, invPct)}%` }}
                    />
                  </div>

                  <div className="flex flex-wrap gap-x-3 text-[11px] text-[#465951]">
                    <span>适用鱼种：{feed.suitableFor}</span>
                    <span aria-hidden="true">·</span>
                    <span className="tabular-nums">增重系数 {feed.growthMultiplier.toFixed(2)}x</span>
                  </div>

                  <div className="flex flex-col gap-2 min-[380px]:flex-row min-[380px]:items-center">
                    <div className="flex h-10 items-center justify-between rounded-xl border border-[#5e4126]/20 bg-white/75 px-1 sm:w-auto">
                      <button
                        type="button"
                        onClick={() =>
                          setFeedBagsMap((prev) => ({
                            ...prev,
                            [feed.id]: Math.max(1, (prev[feed.id] ?? 1) - 1),
                          }))
                        }
                        aria-label="减少饲料袋数"
                        className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-[#2c3e37] hover:bg-[#13221d]/8 cursor-pointer"
                      >
                        <Minus className="h-3.5 w-3.5" />
                      </button>
                      <span className="w-10 text-center text-xs font-semibold text-[#13221d] tabular-nums">
                        {bags} 袋
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          setFeedBagsMap((prev) => ({
                            ...prev,
                            [feed.id]: Math.min(20, (prev[feed.id] ?? 1) + 1),
                          }))
                        }
                        aria-label="增加饲料袋数"
                        className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-[#2c3e37] hover:bg-[#13221d]/8 cursor-pointer"
                      >
                        <Plus className="h-3.5 w-3.5" />
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={() => onBuyFeed(feed.id, bags)}
                      className="inline-flex min-h-[40px] flex-1 items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-[#1b5951] to-[#267367] px-3.5 py-2 text-xs font-semibold text-white shadow-xs transition-all hover:brightness-105 cursor-pointer"
                    >
                      <ShoppingBag className="h-3.5 w-3.5 shrink-0" />
                      <span className="tabular-nums">
                        采购 {bags * feed.bagWeightKg}kg (¥{cost})
                      </span>
                    </button>
                  </div>
                </article>
              );
            })}
          </div>
        </section>
      )}
    </div>
  );
}
