import { Droplets, Heart, HeartPulse, Sparkles, Utensils, Wind } from 'lucide-react';
import { useMemo, useState } from 'react';
import { FEED_CATALOG, FEED_LIST, FISH_SPECIES_LIST, getPondTier } from '../../game/catalog';
import { computeRecommendedDailyFeedKg, getEffectiveCareCost } from '../../game/simulation';
import type { AdRewardType, FeedTypeId, FishSpeciesId, GameState } from '../../types/pond';
import { AutomationRow, SectionHeading } from './PanelPrimitives';

interface CarePanelProps {
  gameState: GameState;
  onFeedPond: (feedId: FeedTypeId, amountKg: number) => void;
  onAeratePond: () => void;
  onChangeWater: () => void;
  onTreatDisease: () => void;
  onBreedPair: (speciesId: FishSpeciesId) => void;
  onToggleAutoCare: () => void;
  onWatchAd: (adType: AdRewardType) => void;
}

export function CarePanel({
  gameState,
  onFeedPond,
  onAeratePond,
  onChangeWater,
  onTreatDisease,
  onBreedPair,
  onToggleAutoCare,
  onWatchAd,
}: CarePanelProps) {
  const [selectedFeedType, setSelectedFeedType] = useState<FeedTypeId>('standard');
  const [feedMultiplier, setFeedMultiplier] = useState<number>(1.0);

  const { pond, fishes } = gameState;
  const currentTier = getPondTier(pond.facilityLevel);
  const recommendedFeedKg = useMemo(
    () => computeRecommendedDailyFeedKg(fishes, pond.facilityLevel),
    [fishes, pond.facilityLevel],
  );
  const plannedFeedKg = Math.max(0.1, Math.round(recommendedFeedKg * feedMultiplier * 10) / 10);

  const breedableSpecies = useMemo(() => {
    return FISH_SPECIES_LIST.map((spec) => {
      const matureCount = fishes.filter(
        (f) => f.speciesId === spec.id && f.growthStage === '成熟期' && f.health >= 70,
      ).length;
      return { spec, matureCount };
    }).filter((item) => item.matureCount >= 2);
  }, [fishes]);

  const aerateCost = getEffectiveCareCost(25, gameState);
  const waterChangeCost = getEffectiveCareCost(45, gameState);
  const diseaseCost = getEffectiveCareCost(65, gameState);
  const breedCost = getEffectiveCareCost(60, gameState);

  return (
    <div className="space-y-4 sm:space-y-5">
      <AutomationRow
        title="自动投喂护理管家"
        description="达警戒或偏离「优」时自动增氧、换水、防病与精准投喂，全程保持优质水质"
        unlocked={gameState.autoCareUnlocked}
        enabled={gameState.autoCareEnabled}
        activeLabel="自动护理中"
        pausedLabel="已暂停"
        onToggle={onToggleAutoCare}
        onWatchAd={() => onWatchAd('auto_care')}
      />

      {/* 01. Manual Feeding */}
      <section className="space-y-2.5">
        <SectionHeading
          title="手动鱼塘投喂"
          caption={`今日建议 ${recommendedFeedKg.toFixed(1)} kg${currentTier.consumptionMultiplier < 1 ? ' (消耗减半)' : ''}`}
          icon={<Utensils className="h-4 w-4" />}
        />

        <div className="manor-stone-card rounded-2xl p-3 sm:p-3.5 space-y-3">
          <div className="grid grid-cols-2 gap-2 sm:gap-2.5">
            {FEED_LIST.map((f) => {
              const active = selectedFeedType === f.id;
              const inv = gameState.feedInventory[f.id];
              return (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setSelectedFeedType(f.id)}
                  className={`min-h-[56px] rounded-xl border p-2.5 text-left transition-all cursor-pointer ${
                    active
                      ? 'manor-jade-card border-[#1b5951] ring-1 ring-[#1b5951]/20'
                      : 'border-[#5d6e67]/18 bg-white/60 hover:bg-white/90'
                  }`}
                >
                  <div className="text-xs font-semibold text-[#13221d] truncate">{f.name}</div>
                  <div className="mt-0.5 text-[11px] text-[#556860] tabular-nums">
                    库存 {inv.toFixed(1)} kg
                  </div>
                </button>
              );
            })}
          </div>

          <div>
            <div className="mb-2 flex items-center justify-between text-xs">
              <span className="font-medium text-[#465951]">投喂分量比例</span>
              <span className="font-semibold text-[#13221d] tabular-nums">
                本次投喂 {plannedFeedKg.toFixed(1)} kg
              </span>
            </div>
            <div className="grid grid-cols-3 gap-1.5 sm:gap-2">
              {[
                { mult: 0.6, label: '少量 60%', desc: '低残饵' },
                { mult: 1.0, label: '标准 100%', desc: '均衡成长' },
                { mult: 1.65, label: '过量 165%', desc: '易留残饵' },
              ].map((opt) => {
                const selected = feedMultiplier === opt.mult;
                return (
                  <button
                    key={opt.mult}
                    type="button"
                    onClick={() => setFeedMultiplier(opt.mult)}
                    className={`min-h-[48px] rounded-xl border px-1.5 sm:px-2 py-1.5 text-center text-[11px] sm:text-xs transition-all cursor-pointer ${
                      selected
                        ? 'border-[#1b5951] bg-gradient-to-b from-[#1b5951] to-[#236b61] text-white shadow-xs'
                        : 'border-[#5d6e67]/18 bg-white/65 text-[#2c3e37] hover:bg-white'
                    }`}
                  >
                    <div className="font-semibold whitespace-nowrap">{opt.label}</div>
                    <div
                      className={`text-[10px] sm:text-[10.5px] ${
                        selected ? 'text-white/85' : 'text-[#5c6f67]'
                      }`}
                    >
                      {opt.desc}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <button
            type="button"
            onClick={() => onFeedPond(selectedFeedType, plannedFeedKg)}
            className="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#1b5951] to-[#267367] px-4 py-2.5 text-xs font-semibold text-white shadow-xs transition-all hover:brightness-105 cursor-pointer"
          >
            <Utensils className="h-3.5 w-3.5 shrink-0" />
            <span className="tabular-nums">
              投放 {FEED_CATALOG[selectedFeedType].name} · {plannedFeedKg.toFixed(1)} kg
            </span>
          </button>
        </div>
      </section>

      {/* 02. Water & Disease Care */}
      <section className="space-y-2.5">
        <SectionHeading
          title="水质调控与鱼病防治"
          caption="即时改善水体环境"
          icon={<Droplets className="h-4 w-4" />}
        />

        <div className="manor-stone-card rounded-2xl p-3 sm:p-3.5 space-y-2.5">
          <div className="grid grid-cols-2 gap-2 sm:gap-2.5">
            <button
              type="button"
              onClick={onAeratePond}
              className="flex min-h-[84px] flex-col items-start justify-between rounded-xl border border-[#5d6e67]/20 bg-white/65 p-2.5 sm:p-3 text-left transition-all hover:border-[#1b5951] hover:bg-[#eef7f4]/80 cursor-pointer"
            >
              <div className="flex w-full items-center justify-between">
                <Wind className="h-4 w-4 text-[#1b5951]" />
                <span className="text-xs font-semibold text-[#9e5c14] tabular-nums">¥{aerateCost}</span>
              </div>
              <div className="mt-2">
                <div className="text-xs font-semibold text-[#13221d]">开启强力增氧</div>
                <div className="mt-0.5 text-[10.5px] sm:text-[11px] text-[#556860] tabular-nums">
                  当前 {pond.dissolvedOxygenMgL.toFixed(1)} · 增至 +2.2 mg/L
                </div>
              </div>
            </button>

            <button
              type="button"
              onClick={onChangeWater}
              className="flex min-h-[84px] flex-col items-start justify-between rounded-xl border border-[#5d6e67]/20 bg-white/65 p-2.5 sm:p-3 text-left transition-all hover:border-[#1b5951] hover:bg-[#eef7f4]/80 cursor-pointer"
            >
              <div className="flex w-full items-center justify-between">
                <Droplets className="h-4 w-4 text-[#235d70]" />
                <span className="text-xs font-semibold text-[#9e5c14] tabular-nums">¥{waterChangeCost}</span>
              </div>
              <div className="mt-2">
                <div className="text-xs font-semibold text-[#13221d]">生态换水 35%</div>
                <div className="mt-0.5 text-[10.5px] sm:text-[11px] text-[#556860] tabular-nums">
                  氨氮 {pond.ammoniaMgL.toFixed(2)} · 净水降残饵
                </div>
              </div>
            </button>
          </div>

          <button
            type="button"
            onClick={onTreatDisease}
            className="flex min-h-[54px] w-full items-center justify-between gap-3 rounded-xl border border-[#5d6e67]/20 bg-white/65 px-3 sm:px-3.5 py-2.5 text-left transition-all hover:border-[#1b5951] hover:bg-[#eef7f4]/80 cursor-pointer"
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <HeartPulse className="h-4 w-4 shrink-0 text-[#b5482a]" />
              <div className="min-w-0">
                <div className="text-xs font-semibold text-[#13221d]">
                  鱼病防治与益生菌调水
                  {gameState.diseaseDaysRemaining > 0 && (
                    <span className="ml-1.5 text-[#a93327]">（建议立即处理）</span>
                  )}
                </div>
                <div className="text-[11px] text-[#556860]">
                  全池健康度 +18 并立即解除活跃鱼病风险
                </div>
              </div>
            </div>
            <span className="text-xs font-semibold text-[#9e5c14] tabular-nums shrink-0">
              ¥{diseaseCost}
            </span>
          </button>
        </div>
      </section>

      {/* 03. Ecological Breeding */}
      <section className="space-y-2.5">
        <SectionHeading
          title="亲鱼生态繁育"
          caption="需同种成熟期 ≥ 2 尾"
          icon={<Heart className="h-4 w-4 text-[#b5482a]" />}
        />

        <div className="manor-stone-card rounded-2xl p-3 sm:p-3.5">
          {breedableSpecies.length === 0 ? (
            <p className="text-xs leading-relaxed text-[#556860]">
              池内暂无同种 2 尾以上健康（≥70）成熟亲鱼，待成鱼达标后可在此繁育新苗。
            </p>
          ) : (
            <div className="space-y-2">
              {breedableSpecies.map(({ spec, matureCount }) => (
                <div
                  key={spec.id}
                  className="flex flex-col gap-2 rounded-xl border border-[#5d6e67]/15 bg-white/65 px-3 py-2.5 min-[380px]:flex-row min-[380px]:items-center min-[380px]:justify-between"
                >
                  <div className="text-xs">
                    <span className="font-semibold text-[#13221d]">{spec.name}</span>
                    <span className="ml-2 text-[#556860] tabular-nums">
                      健康成熟亲鱼 {matureCount} 尾
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => onBreedPair(spec.id)}
                    className="inline-flex min-h-[40px] sm:min-h-[36px] items-center justify-center gap-1.5 rounded-xl sm:rounded-lg bg-[#1b5951] px-3 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-[#144740] cursor-pointer whitespace-nowrap"
                  >
                    <Sparkles className="h-3.5 w-3.5" />
                    <span className="tabular-nums">繁育 +2尾 (¥{breedCost})</span>
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
