import {
  Activity,
  AlertTriangle,
  ArrowUpCircle,
  Bot,
  Droplets,
  Fish,
  Waves,
} from 'lucide-react';
import { useMemo } from 'react';
import {
  FEED_STANDARD_CAPACITY_KG,
  MAX_POND_LEVEL,
  POND_EXPANSION_TIERS,
  getPondTier,
} from '../../game/catalog';
import {
  computeEventProbabilities,
  evaluateWaterQualityStatus,
  getEffectiveSaleMultiplier,
} from '../../game/simulation';
import type {
  AdRewardType,
  FishQuality,
  GameState,
  GrowthStage,
  ManagedFish,
  PondLevel,
} from '../../types/pond';
import { AutomationRow, MeterBar, SectionHeading, SpeciesEmblem } from './PanelPrimitives';

const QUALITY_RANK: Record<FishQuality, number> = {
  极品: 4,
  精品: 3,
  良种: 2,
  普通: 1,
};

const STAGE_RANK: Record<GrowthStage, number> = {
  成熟期: 4,
  成长期: 3,
  幼鱼期: 2,
  鱼苗期: 1,
};

interface PondPanelProps {
  gameState: GameState;
  selectedFishId: string | null;
  onSelectFishInScene: (fishId: string) => void;
  onExpandPond: () => void;
  onToggleAutoCare: () => void;
  onToggleAutoRestock: () => void;
  onToggleAnglerOpen: () => void;
  onToggleAutoSellMature: () => void;
  onWatchAd: (adType: AdRewardType) => void;
}

export function PondPanel({
  gameState,
  selectedFishId,
  onSelectFishInScene,
  onExpandPond,
  onToggleAutoCare,
  onToggleAutoRestock,
  onToggleAnglerOpen,
  onToggleAutoSellMature,
  onWatchAd,
}: PondPanelProps) {
  const { pond, fishes } = gameState;
  const currentTier = getPondTier(pond.facilityLevel);
  const nextTier =
    pond.facilityLevel < MAX_POND_LEVEL
      ? POND_EXPANSION_TIERS[(pond.facilityLevel + 1) as PondLevel]
      : null;
  const nextUpgradeCost = nextTier ? nextTier.upgradeCost : null;

  const saleMult = getEffectiveSaleMultiplier(gameState);
  const saleBonusPct = Math.round((saleMult - 1) * 100);
  const remainingSlots = Math.max(0, pond.maxRecommendedFish - fishes.length);

  const waterEval = useMemo(() => evaluateWaterQualityStatus(gameState), [gameState]);
  const riskProbs = useMemo(() => computeEventProbabilities(gameState), [gameState]);

  const topFishes = useMemo(() => {
    return [...fishes]
      .sort((a, b) => {
        const qDiff = QUALITY_RANK[b.quality] - QUALITY_RANK[a.quality];
        if (qDiff !== 0) return qDiff;
        const sDiff = STAGE_RANK[b.growthStage] - STAGE_RANK[a.growthStage];
        if (sDiff !== 0) return sDiff;
        if (b.weightKg !== a.weightKg) return b.weightKg - a.weightKg;
        return b.health - a.health;
      })
      .slice(0, 10);
  }, [fishes]);

  const capacityPct = Math.min(100, (fishes.length / pond.maxRecommendedFish) * 100);

  return (
    <div className="space-y-4 sm:space-y-5">
      {/* 01. Current Pond Tier Card (ONLY displays current level details) */}
      <section className="space-y-2.5">
        <SectionHeading
          title="池体概况与扩建"
          caption={`当前 Lv.${currentTier.level} · ${currentTier.name}`}
          icon={<Waves className="h-4 w-4" />}
        />

        <div className="manor-wood-card rounded-2xl p-3.5 sm:p-4 space-y-3">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="text-[11px] font-medium text-[#8b633c] tabular-nums">
                当前规模 · 水域比例 {currentTier.visualScale.toFixed(2)}x
              </div>
              <h4 className="font-display mt-0.5 text-base font-semibold text-[#13221d] truncate">
                {pond.name}
              </h4>
            </div>
            <div className="text-right shrink-0 tabular-nums">
              <div className="text-[11px] text-[#556860]">在池密度</div>
              <div className="font-display text-base font-semibold text-[#13221d]">
                {fishes.length} <span className="text-xs font-normal text-[#556860]">/ {pond.maxRecommendedFish} 尾</span>
              </div>
            </div>
          </div>

          <div>
            <div className="h-2 w-full overflow-hidden rounded-full bg-[#5e4126]/12">
              <div
                className={`h-full rounded-full transition-all duration-300 ${
                  fishes.length >= pond.maxRecommendedFish
                    ? 'bg-gradient-to-r from-[#b86d15] to-[#d98a29]'
                    : 'bg-gradient-to-r from-[#1b5951] to-[#2e8577]'
                }`}
                style={{ width: `${Math.max(4, capacityPct)}%` }}
              />
            </div>
            <div className="mt-1.5 flex flex-wrap items-center gap-x-2.5 gap-y-0.5 text-[11px] text-[#556860] tabular-nums">
              <span>水面 {pond.areaSqm} m²</span>
              <span aria-hidden="true">·</span>
              <span>水体 {pond.waterVolumeM3} m³</span>
              <span aria-hidden="true">·</span>
              <span>余位 {remainingSlots} 尾</span>
            </div>
          </div>

          <div className="manor-divider" />

          <div className="grid grid-cols-3 gap-2 text-center tabular-nums">
            <div className="rounded-xl border border-[#5e4126]/14 bg-white/55 px-2 py-2">
              <div className="text-[10.5px] text-[#556860]">售价加成</div>
              <div className="mt-0.5 text-xs font-semibold text-[#1b5951]">
                {saleBonusPct > 0 ? `+${saleBonusPct}%` : '标准 100%'}
              </div>
            </div>
            <div className="rounded-xl border border-[#5e4126]/14 bg-white/55 px-2 py-2">
              <div className="text-[10.5px] text-[#556860]">采购价格</div>
              <div className="mt-0.5 text-xs font-semibold text-[#13221d]">
                {Math.round(currentTier.purchaseCostMultiplier * 100)}%
              </div>
            </div>
            <div className="rounded-xl border border-[#5e4126]/14 bg-white/55 px-2 py-2">
              <div className="text-[10.5px] text-[#556860]">消耗属性</div>
              <div className="mt-0.5 text-xs font-semibold text-[#13221d]">
                {Math.round(currentTier.consumptionMultiplier * 100)}%
              </div>
            </div>
          </div>

          <p className="text-[11.5px] leading-relaxed text-[#4f4335]">{currentTier.summary}</p>

          {fishes.length <= 2 && (
            <div className="rounded-xl border border-[#b5372b]/30 bg-[#fdf0ee]/90 p-3 text-xs text-[#8f241b]">
              <div className="flex items-center gap-1.5 font-semibold">
                <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                <span>空塘破产风险警告</span>
              </div>
              <p className="mt-1 text-[11px] leading-relaxed">
                当鱼塘鱼数降至 0 尾时，钓鱼人离去、鱼塘荒废，将判定破产失败！请及时补苗。
              </p>
            </div>
          )}

          {waterEval.issues.length > 0 && (
            <div className="rounded-xl border border-[#c77d1e]/30 bg-[#fdf6ea]/90 p-3 text-xs text-[#8a510c]">
              <div className="flex items-center gap-1.5 font-semibold">
                <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                <span>水质与密度异常提示</span>
              </div>
              <p className="mt-1 text-[11px] leading-relaxed">{waterEval.issues.join('；')}</p>
            </div>
          )}

          {nextUpgradeCost !== null && nextTier ? (
            <button
              type="button"
              onClick={onExpandPond}
              className={`flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl px-3.5 py-2.5 text-xs font-semibold transition-all cursor-pointer ${
                gameState.funds >= nextUpgradeCost
                  ? 'bg-gradient-to-r from-[#1b5951] to-[#267367] text-white shadow-sm hover:brightness-105'
                  : 'border border-[#5d6e67]/25 bg-white/60 text-[#556860] hover:bg-white/85'
              }`}
            >
              <ArrowUpCircle className="h-4 w-4 shrink-0" />
              <span className="tabular-nums">
                {gameState.funds >= nextUpgradeCost
                  ? `扩建升级 Lv.${nextTier.level}（${nextTier.capacity}尾 · ¥${nextUpgradeCost.toLocaleString('zh-CN')}）`
                  : `扩建 Lv.${nextTier.level} 资金不足（需 ¥${nextUpgradeCost.toLocaleString('zh-CN')}）`}
              </span>
            </button>
          ) : (
            <div className="manor-jade-card rounded-xl py-2.5 text-center text-xs font-semibold text-[#134740]">
              当前鱼塘已达最高扩建规模
            </div>
          )}
        </div>
      </section>

      {/* 02. Watch-Ad Smart Manor Automation */}
      <section className="space-y-2.5">
        <SectionHeading
          title="庄园智能托管（看广告开启）"
          caption="解锁后可随时切换"
          icon={<Bot className="h-4 w-4" />}
        />

        <div className="space-y-2">
          <AutomationRow
            title="自动投喂与水质护理"
            description="当水质偏离优质或接近警戒时自动增氧、换水、治病并精准投喂，全程维持「优」"
            unlocked={gameState.autoCareUnlocked}
            enabled={gameState.autoCareEnabled}
            activeLabel="运行中"
            pausedLabel="已暂停"
            onToggle={onToggleAutoCare}
            onWatchAd={() => onWatchAd('auto_care')}
          />

          <AutomationRow
            title="自动买鱼苗与鱼饲料"
            description={`当池内鱼数未过半（<${Math.floor(pond.maxRecommendedFish / 2)}尾）或饲料未过半（<${FEED_STANDARD_CAPACITY_KG / 2}kg）时自动下单补齐`}
            unlocked={gameState.autoRestockUnlocked}
            enabled={gameState.autoRestockEnabled}
            activeLabel="运行中"
            pausedLabel="已暂停"
            onToggle={onToggleAutoRestock}
            onWatchAd={() => onWatchAd('auto_restock')}
          />

          <AutomationRow
            title="钓鱼人免费入场"
            description={`开放免费垂钓客进场，钓获鱼只按成熟市价入账（已创收 ¥${gameState.totalAnglerRevenue.toLocaleString('zh-CN')}）`}
            unlocked={gameState.anglerUnlocked}
            enabled={gameState.anglerOpen}
            activeLabel="已开放"
            pausedLabel="已关闭"
            onToggle={onToggleAnglerOpen}
            onWatchAd={() => onWatchAd('angler_open')}
          />

          <AutomationRow
            title="成熟鱼自动售出"
            description="普通与良种成熟鱼自动出栏结算；精品与极品成鱼保留供「售鱼行情」高价出售"
            unlocked={gameState.autoSellUnlocked}
            enabled={gameState.autoSellMature}
            activeLabel="售出中"
            pausedLabel="已暂停"
            onToggle={onToggleAutoSellMature}
            onWatchAd={() => onWatchAd('auto_sell')}
          />
        </div>
      </section>

      {/* 03. Water Quality Telemetry */}
      <section className="space-y-2.5">
        <SectionHeading
          title="水质生态精密监测"
          caption={`综合评分：${waterEval.label}`}
          icon={<Droplets className="h-4 w-4" />}
        />

        <div className="grid grid-cols-2 gap-2 sm:gap-2.5">
          <MeterBar
            label="溶氧量 (DO)"
            valueText={`${pond.dissolvedOxygenMgL.toFixed(1)} mg/L`}
            percent={(pond.dissolvedOxygenMgL / 10.6) * 100}
            status={pond.dissolvedOxygenMgL >= 7.5 ? 'good' : pond.dissolvedOxygenMgL >= 5.2 ? 'warn' : 'bad'}
            hint="优质 ≥ 7.5 mg/L"
          />
          <MeterBar
            label="酸碱度 (pH)"
            valueText={pond.ph.toFixed(2)}
            percent={((pond.ph - 5.5) / 3.5) * 100}
            status={pond.ph >= 6.8 && pond.ph <= 7.8 ? 'good' : 'warn'}
            hint="优质 6.8 – 7.8"
          />
          <MeterBar
            label="氨氮浓度"
            valueText={`${pond.ammoniaMgL.toFixed(2)} mg/L`}
            percent={(pond.ammoniaMgL / 0.45) * 100}
            status={pond.ammoniaMgL <= 0.08 ? 'good' : pond.ammoniaMgL <= 0.18 ? 'warn' : 'bad'}
            hint="优质 ≤ 0.08 mg/L"
          />
          <MeterBar
            label="亚硝酸盐"
            valueText={`${pond.nitriteMgL.toFixed(2)} mg/L`}
            percent={(pond.nitriteMgL / 0.25) * 100}
            status={pond.nitriteMgL <= 0.04 ? 'good' : pond.nitriteMgL <= 0.1 ? 'warn' : 'bad'}
            hint="优质 ≤ 0.04 mg/L"
          />
          <MeterBar
            label="实时水温"
            valueText={`${pond.temperatureC.toFixed(1)} °C`}
            percent={((pond.temperatureC - 12) / 20) * 100}
            status={pond.temperatureC >= 18 && pond.temperatureC <= 26 ? 'good' : 'warn'}
            hint="适温 18 – 26 °C"
          />
          <MeterBar
            label="池底残饵"
            valueText={`${pond.leftoverFeedKg.toFixed(2)} kg`}
            percent={(pond.leftoverFeedKg / 2.0) * 100}
            status={pond.leftoverFeedKg <= 0.3 ? 'good' : pond.leftoverFeedKg <= 0.8 ? 'warn' : 'bad'}
            hint="优质 ≤ 0.30 kg"
          />
        </div>
      </section>

      {/* 04. Random Events Probability */}
      <section className="space-y-2.5">
        <SectionHeading
          title="每日生态风险与行情概率"
          caption="随水质动态变化"
          icon={<Activity className="h-4 w-4" />}
        />

        <div className="manor-stone-card rounded-2xl p-3.5 space-y-3">
          <div className="grid grid-cols-2 gap-2.5 text-xs tabular-nums">
            <div className="rounded-xl border border-[#5d6e67]/12 bg-white/55 px-3 py-2">
              <div className="text-[11px] text-[#556860]">天气突变概率</div>
              <div className="mt-0.5 font-semibold text-[#235d70]">{riskProbs.weatherEventPct}% / 天</div>
            </div>
            <div className="rounded-xl border border-[#5d6e67]/12 bg-white/55 px-3 py-2">
              <div className="text-[11px] text-[#556860]">鱼病爆发概率</div>
              <div
                className={`mt-0.5 font-semibold ${
                  riskProbs.diseaseRiskPct > 15 ? 'text-[#a93327]' : 'text-[#13221d]'
                }`}
              >
                {riskProbs.diseaseRiskPct}% / 天
              </div>
            </div>
            <div className="rounded-xl border border-[#5d6e67]/12 bg-white/55 px-3 py-2">
              <div className="text-[11px] text-[#556860]">水体污染概率</div>
              <div
                className={`mt-0.5 font-semibold ${
                  riskProbs.pollutionRiskPct > 15 ? 'text-[#9a590e]' : 'text-[#13221d]'
                }`}
              >
                {riskProbs.pollutionRiskPct}% / 天
              </div>
            </div>
            <div className="rounded-xl border border-[#5d6e67]/12 bg-white/55 px-3 py-2">
              <div className="text-[11px] text-[#556860]">行情走高概率</div>
              <div className="mt-0.5 font-semibold text-[#1b5951]">{riskProbs.marketBoomPct}% / 天</div>
            </div>
          </div>

          {gameState.lastEvent && (
            <div className="rounded-xl border border-[#5e4126]/15 bg-[#faf7ef]/80 px-3 py-2.5 text-xs">
              <div className="font-semibold text-[#13221d]">
                最近事件（第 {gameState.lastEvent.day} 天）· {gameState.lastEvent.title}
              </div>
              <p className="mt-0.5 text-[11px] leading-relaxed text-[#556860]">
                {gameState.lastEvent.description}
              </p>
            </div>
          )}
        </div>
      </section>

      {/* 05. Top 10 Best Quality Fish Roster */}
      <section className="space-y-2.5">
        <SectionHeading
          title="在池优质鱼群名录（点击定位）"
          caption={`精选前 ${topFishes.length} 尾（在池共 ${fishes.length} 尾）`}
          icon={<Fish className="h-4 w-4" />}
        />

        {fishes.length === 0 ? (
          <div className="rounded-xl border border-[#b5372b]/25 bg-[#fdf0ee]/90 p-4 text-center text-xs text-[#8f241b]">
            鱼塘暂无鱼类，请立刻前往「鱼苗饲料店」补充鱼苗。
          </div>
        ) : (
          <div className="space-y-2">
            {topFishes.map((fish: ManagedFish) => {
              const isSel = selectedFishId === fish.id;
              return (
                <button
                  key={fish.id}
                  type="button"
                  onClick={() => onSelectFishInScene(fish.id)}
                  className={`flex min-h-[54px] w-full items-center justify-between gap-2.5 rounded-xl border px-3 py-2 text-left text-xs transition-all cursor-pointer ${
                    isSel
                      ? 'manor-jade-card border-[#1b5951] ring-1 ring-[#1b5951]/25'
                      : 'manor-stone-card hover:bg-white/90'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <SpeciesEmblem speciesId={fish.speciesId} />
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="font-semibold text-[#13221d] truncate">{fish.name}</span>
                        <span className="text-[11px] font-medium text-[#1b5951]">{fish.growthStage}</span>
                        <span
                          className={`text-[11px] font-semibold ${
                            fish.quality === '极品'
                              ? 'text-[#9e5c14]'
                              : fish.quality === '精品'
                                ? 'text-[#1b5951]'
                                : 'text-[#556860]'
                          }`}
                        >
                          {fish.quality}
                        </span>
                      </div>
                      <div className="mt-0.5 text-[11px] text-[#5c6f67] tabular-nums truncate">
                        {fish.id} · {fish.weightKg.toFixed(2)}kg · {fish.lengthCm.toFixed(0)}cm
                      </div>
                    </div>
                  </div>
                  <div className="text-right text-[11px] tabular-nums shrink-0">
                    <div className={fish.health < 65 ? 'font-semibold text-[#a93327]' : 'font-medium text-[#1b5951]'}>
                      健康 {Math.round(fish.health)}
                    </div>
                    <div className={fish.hunger > 70 ? 'font-semibold text-[#9a590e]' : 'text-[#5c6f67]'}>
                      饥饿 {Math.round(fish.hunger)}
                    </div>
                  </div>
                </button>
              );
            })}
            {fishes.length > 10 && (
              <div className="pt-1 text-center text-[11px] text-[#5c6f67] tabular-nums">
                仅展示品质最优的前 10 尾（按极品 → 精品 → 良种排序，池内共计 {fishes.length} 尾）
              </div>
            )}
          </div>
        )}
      </section>
    </div>
  );
}
