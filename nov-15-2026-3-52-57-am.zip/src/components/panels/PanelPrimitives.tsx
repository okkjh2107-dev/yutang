import { CheckCircle2, PlayCircle } from 'lucide-react';
import type { ReactNode } from 'react';
import type { FishSpeciesId } from '../../types/pond';

export function CornerOrnaments({ tone = 'wood' }: { tone?: 'wood' | 'stone' | 'danger' }) {
  const color =
    tone === 'danger'
      ? 'border-[#b5372b]/45'
      : tone === 'stone'
        ? 'border-[#1b5951]/35'
        : 'border-[#8b633c]/45';
  return (
    <div className="pointer-events-none absolute inset-1.5 z-0 rounded-[inherit]" aria-hidden="true">
      <span className={`absolute top-0 left-0 h-2.5 w-2.5 border-t-2 border-l-2 rounded-tl-[3px] ${color}`} />
      <span className={`absolute top-0 right-0 h-2.5 w-2.5 border-t-2 border-r-2 rounded-tr-[3px] ${color}`} />
      <span className={`absolute bottom-0 left-0 h-2.5 w-2.5 border-b-2 border-l-2 rounded-bl-[3px] ${color}`} />
      <span className={`absolute bottom-0 right-0 h-2.5 w-2.5 border-b-2 border-r-2 rounded-br-[3px] ${color}`} />
    </div>
  );
}

export function SectionHeading({
  title,
  caption,
  icon,
}: {
  title: string;
  caption?: string;
  icon?: ReactNode;
}) {
  return (
    <div className="flex items-baseline justify-between gap-2 pb-1">
      <div className="flex items-center gap-1.5 min-w-0">
        {icon && <span className="shrink-0 text-[#1b5951]">{icon}</span>}
        <h3 className="font-display text-[13px] sm:text-[13.5px] font-semibold tracking-tight text-[#13221d] truncate">
          {title}
        </h3>
      </div>
      {caption && (
        <span className="shrink-0 text-[11px] font-medium text-[#5c6f67] tabular-nums whitespace-nowrap">
          {caption}
        </span>
      )}
    </div>
  );
}

export function MeterBar({
  label,
  valueText,
  percent,
  status,
  hint,
}: {
  label: string;
  valueText: string;
  percent: number;
  status: 'good' | 'warn' | 'bad';
  hint: string;
}) {
  const barColor =
    status === 'good'
      ? 'bg-gradient-to-r from-[#1b5951] to-[#2e8577]'
      : status === 'warn'
        ? 'bg-gradient-to-r from-[#b86d15] to-[#df9936]'
        : 'bg-gradient-to-r from-[#a93327] to-[#d65748]';

  const statusText = status === 'good' ? '优质' : status === 'warn' ? '偏离' : '警戒';
  const statusColor =
    status === 'good'
      ? 'text-[#1b5951]'
      : status === 'warn'
        ? 'text-[#9a590e]'
        : 'text-[#a93327]';

  return (
    <div className="manor-stone-card rounded-xl p-2.5 sm:p-3">
      <div className="flex items-baseline justify-between gap-1.5 text-[11.5px] sm:text-xs">
        <span className="font-medium text-[#465951] truncate">{label}</span>
        <span className="font-semibold text-[#13221d] tabular-nums whitespace-nowrap">{valueText}</span>
      </div>
      <div className="relative mt-2 h-1.5 w-full overflow-hidden rounded-full bg-[#13221d]/10">
        <div
          className={`h-full rounded-full transition-all duration-300 ${barColor}`}
          style={{ width: `${Math.min(100, Math.max(5, percent))}%` }}
        />
      </div>
      <div className="mt-1.5 flex items-center justify-between gap-1 text-[10.5px] sm:text-[11px]">
        <span className="text-[#5d7068] truncate">{hint}</span>
        <span className={`font-semibold shrink-0 ${statusColor}`}>{statusText}</span>
      </div>
    </div>
  );
}

export function AutomationRow({
  title,
  description,
  unlocked,
  enabled,
  activeLabel,
  pausedLabel,
  adLabel = '看广告开启',
  onToggle,
  onWatchAd,
}: {
  title: string;
  description: string;
  unlocked: boolean;
  enabled: boolean;
  activeLabel: string;
  pausedLabel: string;
  adLabel?: string;
  onToggle: () => void;
  onWatchAd: () => void;
}) {
  return (
    <div className="manor-stone-card flex flex-col gap-2.5 rounded-xl p-3 sm:flex-row sm:items-center sm:justify-between sm:p-3.5">
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
          <span className="text-xs font-semibold text-[#13221d]">{title}</span>
          <span
            className={`text-[11px] font-medium ${
              !unlocked
                ? 'text-[#8a510c]'
                : enabled
                  ? 'text-[#1b5951]'
                  : 'text-[#5d7068]'
            }`}
          >
            · {!unlocked ? '未解锁' : enabled ? activeLabel : pausedLabel}
          </span>
        </div>
        <p className="mt-0.5 text-[11px] leading-relaxed text-[#556860]">{description}</p>
      </div>

      {unlocked ? (
        <button
          type="button"
          onClick={onToggle}
          className={`inline-flex min-h-[42px] sm:min-h-[34px] w-full sm:w-auto shrink-0 items-center justify-center gap-1.5 rounded-xl sm:rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
            enabled
              ? 'bg-gradient-to-r from-[#1b5951] to-[#267267] text-white shadow-xs hover:brightness-105'
              : 'border border-[#5d6e67]/25 bg-white/75 text-[#31443d] hover:bg-white'
          }`}
        >
          <CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" />
          <span>{enabled ? activeLabel : pausedLabel}</span>
        </button>
      ) : (
        <button
          type="button"
          onClick={onWatchAd}
          className="inline-flex min-h-[42px] sm:min-h-[34px] w-full sm:w-auto shrink-0 items-center justify-center gap-1.5 rounded-xl sm:rounded-lg bg-gradient-to-r from-[#9e5c14] via-[#b86d15] to-[#ca7f22] px-3.5 py-1.5 text-xs font-semibold text-white shadow-xs transition-all hover:brightness-105 cursor-pointer whitespace-nowrap"
        >
          <PlayCircle className="h-3.5 w-3.5" aria-hidden="true" />
          <span>{adLabel}</span>
        </button>
      )}
    </div>
  );
}

export function SpeciesEmblem({ speciesId }: { speciesId: FishSpeciesId }) {
  const palette: Record<FishSpeciesId, { bg: string; body: string; fin: string; accent: string }> = {
    grass_carp: {
      bg: 'from-[#e4efe9] to-[#d1e4dc]',
      body: '#486b5c',
      fin: '#2f4d41',
      accent: '#b5d0c4',
    },
    common_carp: {
      bg: 'from-[#f8eedb] to-[#eed9b8]',
      body: '#9c6734',
      fin: '#c67d39',
      accent: '#ebd1a7',
    },
    tilapia: {
      bg: 'from-[#e6ecee] to-[#d2dde0]',
      body: '#4b5e67',
      fin: '#2e3e46',
      accent: '#9eb2ba',
    },
  };
  const c = palette[speciesId];
  return (
    <div
      aria-hidden="true"
      className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-[#5e4126]/20 bg-gradient-to-br ${c.bg} shadow-inner`}
    >
      <svg viewBox="0 0 36 24" className="h-6 w-8">
        <path d="M5 12 L1 6 L2.5 12 L1 18 Z" fill={c.fin} />
        <ellipse cx="18" cy="12" rx="11" ry="6.2" fill={c.body} />
        <path d="M10 13 Q18 17.5 27 12.5 Q19 15 10 13 Z" fill={c.accent} opacity="0.85" />
        <path d="M14 6.5 L20 4 L22 7 Z" fill={c.fin} />
        <circle cx="25.2" cy="10.8" r="1.15" fill="#13221d" />
      </svg>
    </div>
  );
}
