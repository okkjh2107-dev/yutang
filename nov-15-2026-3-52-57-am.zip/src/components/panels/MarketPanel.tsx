import { Award, Coins } from 'lucide-react';
import { useMemo } from 'react';
import { FISH_SPECIES_LIST } from '../../game/catalog';
import { computeEdibleSinglePrice, getEffectiveSaleMultiplier } from '../../game/simulation';
import type { AdRewardType, GameState } from '../../types/pond';
import { AutomationRow, SectionHeading, SpeciesEmblem } from './PanelPrimitives';

interface MarketPanelProps {
  gameState: GameState;
  onToggleAutoSellMature: () => void;
  onToggleAnglerOpen: () => void;
  onWatchAd: (adType: AdRewardType) => void;
  onSellSingleFish: (fishId: string) => void;
}

export function MarketPanel({
  gameState,
  onToggleAutoSellMature,
  onToggleAnglerOpen,
  onWatchAd,
  onSellSingleFish,
}: MarketPanelProps) {
  const saleMult = getEffectiveSaleMultiplier(gameState);
  const saleBonusPct = Math.round((saleMult - 1) * 100);

  // Strictly display mature 精品 & 极品 fishes sorted with 极品 first
  const prizedMatureFishes = useMemo(() => {
    return gameState.fishes
      .filter(
        (f) =>
          f.growthStage === '成熟期' &&
          (f.quality === '精品' || f.quality === '极品'),
      )
      .sort((a, b) => {
        if (a.quality !== b.quality) return a.quality === '极品' ? -1 : 1;
        return b.weightKg - a.weightKg;
      });
  }, [gameState.fishes]);

  return (
    <div className="space-y-4 sm:space-y-5">
      {/* 01. Market Multiplier & Live Species Price Reference */}
      <section className="space-y-2.5">
        <SectionHeading
          title="庄园售鱼行情与自动出栏"
          caption={`当前倍率 ${saleMult.toFixed(2)}x${saleBonusPct > 0 ? ` (+${saleBonusPct}%)` : ''}`}
          icon={<Coins className="h-4 w-4" />}
        />

        <div className="manor-jade-card rounded-2xl p-3 sm:p-3.5 space-y-2.5">
          <p className="text-[11.5px] sm:text-xs leading-relaxed text-[#224640]">
            看广告解锁后，池内「普通」与「良种」成熟鱼将自动出栏变现；钓鱼客免费入场钓起的食用鱼也按成熟市价实时入账。成熟期「精品」与「极品」珍品将保留在下方供您单独高价售出。
          </p>

          <div className="grid grid-cols-3 gap-1.5 sm:gap-2 tabular-nums">
            {FISH_SPECIES_LIST.map((spec) => {
              const effectivePerKg = Math.round(spec.marketPricePerKg * saleMult);
              const refMaturePrice = Math.round(spec.marketPricePerKg * spec.marketWeightKg * saleMult);
              return (
                <div
                  key={spec.id}
                  className="rounded-xl border border-[#1b5951]/18 bg-white/70 px-2 py-2 text-center"
                >
                  <div className="text-[11px] font-semibold text-[#13221d] truncate">{spec.name}</div>
                  <div className="mt-0.5 text-xs font-bold text-[#1b5951]">¥{effectivePerKg}/kg</div>
                  <div className="mt-0.5 text-[10px] text-[#556860]">达标约 ¥{refMaturePrice}</div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="space-y-2">
          <AutomationRow
            title="成熟鱼自动售出"
            description="普通与良种食用鱼达到成熟期即按实时行情自动结算入账"
            unlocked={gameState.autoSellUnlocked}
            enabled={gameState.autoSellMature}
            activeLabel="自动售出中"
            pausedLabel="已暂停"
            onToggle={onToggleAutoSellMature}
            onWatchAd={() => onWatchAd('auto_sell')}
          />

          <AutomationRow
            title="钓鱼人免费入场"
            description={`钓鱼客岸边垂钓并按成熟市价结算（累计创收 ¥${gameState.totalAnglerRevenue.toLocaleString('zh-CN')}）`}
            unlocked={gameState.anglerUnlocked}
            enabled={gameState.anglerOpen}
            activeLabel="开放中"
            pausedLabel="已关闭"
            onToggle={onToggleAnglerOpen}
            onWatchAd={() => onWatchAd('angler_open')}
          />
        </div>
      </section>

      {/* 02. Mature 精品 & 极品 Showcase */}
      <section className="space-y-2.5">
        <SectionHeading
          title="成熟精品 · 极品精选出售"
          caption={`待售 ${prizedMatureFishes.length} 尾`}
          icon={<Award className="h-4 w-4 text-[#9e5c14]" />}
        />

        {prizedMatureFishes.length === 0 ? (
          <div className="manor-stone-card rounded-2xl p-4 text-center text-xs leading-relaxed text-[#556860]">
            当前池内暂无成熟期的「精品」或「极品」食用鱼，可通过高蛋白饲料精养或亲鱼生态繁育培育高品级成鱼。
          </div>
        ) : (
          <div className="space-y-2.5">
            {prizedMatureFishes.map((fish) => {
              const price = computeEdibleSinglePrice(fish, gameState);
              const cost = fish.purchasePrice + fish.feedCostAccumulated;
              const profit = price - cost;
              const isSupreme = fish.quality === '极品';

              return (
                <article
                  key={fish.id}
                  className={`rounded-2xl p-3 sm:p-3.5 transition-all ${
                    isSupreme ? 'manor-wood-card' : 'manor-jade-card'
                  }`}
                >
                  <div className="flex flex-col gap-2.5 min-[420px]:flex-row min-[420px]:items-center min-[420px]:justify-between">
                    <div className="flex items-start gap-2.5 min-w-0">
                      <SpeciesEmblem speciesId={fish.speciesId} />
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-1.5 text-xs">
                          <span
                            className={`rounded px-1.5 py-0.5 text-[10px] font-bold tracking-wide ${
                              isSupreme
                                ? 'bg-[#9e5c14] text-white'
                                : 'bg-[#1b5951] text-white'
                            }`}
                          >
                            {fish.quality}
                          </span>
                          <span className="font-display text-sm font-semibold text-[#13221d] truncate">
                            {fish.name}
                          </span>
                          <span className="text-[11px] font-medium text-[#465951]">
                            · {fish.growthStage}
                          </span>
                        </div>
                        <div className="mt-1 flex flex-wrap gap-x-2 text-[11px] text-[#556860] tabular-nums">
                          <span>体长 {fish.lengthCm.toFixed(0)}cm</span>
                          <span aria-hidden="true">·</span>
                          <span>体重 {fish.weightKg.toFixed(2)}kg</span>
                          <span aria-hidden="true">·</span>
                          <span>成本 ¥{cost.toFixed(0)}</span>
                          <span aria-hidden="true">·</span>
                          <span className={profit >= 0 ? 'font-semibold text-[#1b5951]' : 'text-[#a93327]'}>
                            净利 {profit >= 0 ? '+' : ''}¥{profit.toFixed(0)}
                          </span>
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => onSellSingleFish(fish.id)}
                      className={`inline-flex min-h-[42px] sm:min-h-[36px] w-full min-[420px]:w-auto shrink-0 items-center justify-center rounded-xl px-3.5 py-2 text-xs font-semibold text-white shadow-xs transition-all hover:brightness-105 cursor-pointer tabular-nums whitespace-nowrap ${
                        isSupreme
                          ? 'bg-gradient-to-r from-[#9e5c14] via-[#b86d15] to-[#ca7f22]'
                          : 'bg-gradient-to-r from-[#1b5951] to-[#267367]'
                      }`}
                    >
                      高价出售 ¥{price}
                    </button>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
