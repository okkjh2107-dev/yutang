import { BookOpen, Coins, Landmark, ShoppingBag, Utensils, Waves, X } from 'lucide-react';
import { getPondTier } from '../game/catalog';
import type {
  AdRewardType,
  FeedTypeId,
  FishSpeciesId,
  GameState,
} from '../types/pond';
import { CarePanel } from './panels/CarePanel';
import { FinancePanel } from './panels/FinancePanel';
import { LogsPanel } from './panels/LogsPanel';
import { MarketPanel } from './panels/MarketPanel';
import { CornerOrnaments } from './panels/PanelPrimitives';
import { PondPanel } from './panels/PondPanel';
import { ShopPanel } from './panels/ShopPanel';

export type ManagementTabId = 'pond' | 'shop' | 'care' | 'harvest' | 'finance' | 'logs';

interface ManagementDrawerProps {
  activeTab: ManagementTabId;
  gameState: GameState;
  selectedFishId: string | null;
  onChangeTab: (tab: ManagementTabId) => void;
  onClose: () => void;
  onSelectFishInScene: (fishId: string) => void;
  onBuyFry: (speciesId: FishSpeciesId, qty: number) => void;
  onBuyFeed: (feedId: FeedTypeId, bags: number) => void;
  onFeedPond: (feedId: FeedTypeId, amountKg: number) => void;
  onAeratePond: () => void;
  onChangeWater: () => void;
  onTreatDisease: () => void;
  onExpandPond: () => void;
  onToggleAnglerOpen: () => void;
  onToggleAutoSellMature: () => void;
  onWatchAd: (adType: AdRewardType) => void;
  onToggleAutoCare: () => void;
  onToggleAutoRestock: () => void;
  onBreedPair: (speciesId: FishSpeciesId) => void;
  onSellSingleFish: (fishId: string) => void;
  onResetSave: () => void;
}

const TABS: Array<{ id: ManagementTabId; label: string; Icon: typeof Waves }> = [
  { id: 'pond', label: '鱼塘管理', Icon: Waves },
  { id: 'shop', label: '鱼苗饲料店', Icon: ShoppingBag },
  { id: 'care', label: '投喂护理', Icon: Utensils },
  { id: 'harvest', label: '售鱼行情', Icon: Coins },
  { id: 'finance', label: '财务报表', Icon: Landmark },
  { id: 'logs', label: '养殖日志', Icon: BookOpen },
];

export function ManagementDrawer({
  activeTab,
  gameState,
  selectedFishId,
  onChangeTab,
  onClose,
  onSelectFishInScene,
  onBuyFry,
  onBuyFeed,
  onFeedPond,
  onAeratePond,
  onChangeWater,
  onTreatDisease,
  onExpandPond,
  onToggleAnglerOpen,
  onToggleAutoSellMature,
  onWatchAd,
  onToggleAutoCare,
  onToggleAutoRestock,
  onBreedPair,
  onSellSingleFish,
  onResetSave,
}: ManagementDrawerProps) {
  const { pond, fishes } = gameState;
  const currentTier = getPondTier(pond.facilityLevel);
  const prizedMatureCount = fishes.filter(
    (f) => f.growthStage === '成熟期' && (f.quality === '精品' || f.quality === '极品'),
  ).length;

  return (
    <>
      {/* Mobile dim scrim for bottom-sheet ergonomics */}
      <div
        aria-hidden="true"
        onClick={onClose}
        className="pointer-events-auto fixed inset-0 z-20 bg-[#0d1a16]/35 backdrop-blur-[1px] sm:hidden"
      />

      <aside
        aria-label="水产庄园经营管理面板"
        className="manor-glass-wood animate-manor-sheet pointer-events-auto fixed inset-x-0 bottom-0 z-30 flex max-h-[85dvh] w-full flex-col overflow-hidden rounded-t-3xl sm:static sm:z-auto sm:max-h-[calc(100dvh-160px)] sm:w-[496px] lg:w-[530px] sm:rounded-2xl"
      >
        <CornerOrnaments tone="wood" />

        {/* Mobile Bottom-Sheet Drag Handle */}
        <div className="relative z-10 flex justify-center pt-2.5 pb-0.5 sm:hidden" aria-hidden="true">
          <span className="h-1 w-10 rounded-full bg-[#5e4126]/30" />
        </div>

        {/* Wood-Trimmed Header & Responsive Single-Line Tab Rail */}
        <header className="manor-wood-header relative z-10 px-3.5 pt-2 pb-2.5 sm:px-5 sm:pt-4 sm:pb-3">
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 sm:gap-2 text-[11px] font-medium text-[#8b633c] tabular-nums">
                <span>庄园经营管理</span>
                <span aria-hidden="true">·</span>
                <span>鱼塘 Lv.{currentTier.level}</span>
                <span aria-hidden="true">·</span>
                <span>{fishes.length}/{pond.maxRecommendedFish} 尾</span>
              </div>
              <h2 className="font-display mt-0.5 text-[15.5px] font-semibold tracking-tight text-[#13221d] sm:text-[17px] truncate">
                水产庄园内务司 · {currentTier.name}
              </h2>
            </div>

            <button
              type="button"
              onClick={onClose}
              aria-label="关闭管理面板"
              className="inline-flex h-10 w-10 sm:h-9 sm:w-9 shrink-0 items-center justify-center rounded-xl border border-[#5e4126]/20 bg-white/70 text-[#465951] transition-colors hover:bg-white hover:text-[#13221d] cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          <nav
            aria-label="管理面板分类导航"
            className="no-scrollbar -mx-1 mt-2.5 flex items-center gap-1.5 overflow-x-auto px-1 pb-0.5 sm:mt-3"
          >
            {TABS.map(({ id, label, Icon }) => {
              const active = activeTab === id;
              const tabSuffix =
                id === 'harvest' && prizedMatureCount > 0 ? ` (${prizedMatureCount})` : '';
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => onChangeTab(id)}
                  className={`inline-flex min-h-[38px] sm:min-h-[34px] shrink-0 items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                    active
                      ? 'bg-gradient-to-r from-[#1b5951] to-[#267367] text-white shadow-xs'
                      : 'border border-[#5e4126]/14 bg-white/65 text-[#354942] hover:bg-white/95 hover:text-[#13221d]'
                  }`}
                >
                  <Icon className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                  <span className="tabular-nums">
                    {label}
                    {tabSuffix}
                  </span>
                </button>
              );
            })}
          </nav>
        </header>

        {/* Scrollable Panel Body */}
        <div className="manor-scroll relative z-10 flex-1 overflow-y-auto overscroll-contain px-3.5 py-3.5 pb-[calc(1.25rem+env(safe-area-inset-bottom))] sm:px-5 sm:py-4 sm:pb-5">
          {activeTab === 'pond' && (
            <PondPanel
              gameState={gameState}
              selectedFishId={selectedFishId}
              onSelectFishInScene={onSelectFishInScene}
              onExpandPond={onExpandPond}
              onToggleAutoCare={onToggleAutoCare}
              onToggleAutoRestock={onToggleAutoRestock}
              onToggleAnglerOpen={onToggleAnglerOpen}
              onToggleAutoSellMature={onToggleAutoSellMature}
              onWatchAd={onWatchAd}
            />
          )}

          {activeTab === 'shop' && (
            <ShopPanel
              gameState={gameState}
              onBuyFry={onBuyFry}
              onBuyFeed={onBuyFeed}
              onToggleAutoRestock={onToggleAutoRestock}
              onWatchAd={onWatchAd}
            />
          )}

          {activeTab === 'care' && (
            <CarePanel
              gameState={gameState}
              onFeedPond={onFeedPond}
              onAeratePond={onAeratePond}
              onChangeWater={onChangeWater}
              onTreatDisease={onTreatDisease}
              onBreedPair={onBreedPair}
              onToggleAutoCare={onToggleAutoCare}
              onWatchAd={onWatchAd}
            />
          )}

          {activeTab === 'harvest' && (
            <MarketPanel
              gameState={gameState}
              onToggleAutoSellMature={onToggleAutoSellMature}
              onToggleAnglerOpen={onToggleAnglerOpen}
              onWatchAd={onWatchAd}
              onSellSingleFish={onSellSingleFish}
            />
          )}

          {activeTab === 'finance' && <FinancePanel gameState={gameState} />}

          {activeTab === 'logs' && (
            <LogsPanel gameState={gameState} onResetSave={onResetSave} />
          )}
        </div>
      </aside>
    </>
  );
}
