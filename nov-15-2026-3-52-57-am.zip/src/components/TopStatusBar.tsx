import {
  AlertTriangle,
  Bot,
  Cloud,
  CloudRain,
  FastForward,
  Pause,
  Play,
  SkipForward,
  Sparkles,
  Sun,
  ThermometerSun,
} from 'lucide-react';
import { getPondTier } from '../game/catalog';
import {
  evaluateWaterQualityStatus,
  getEffectiveSaleMultiplier,
  getManorTitle,
} from '../game/simulation';
import type { ActionFeedback, GameState, TimeSpeed, WeatherType } from '../types/pond';

interface TopStatusBarProps {
  gameState: GameState;
  timeSpeed: TimeSpeed;
  dayProgress: number; // 0..1
  feedback: ActionFeedback | null;
  onSetTimeSpeed: (speed: TimeSpeed) => void;
  onAdvanceDay: () => void;
  onOpenPondTab: () => void;
}

function WeatherIcon({ weather }: { weather: WeatherType }) {
  switch (weather) {
    case '晴朗微风':
      return <Sun className="h-3.5 w-3.5 text-[#b86d15]" aria-hidden="true" />;
    case '多云舒爽':
      return <Cloud className="h-3.5 w-3.5 text-[#556860]" aria-hidden="true" />;
    case '阵雨充氧':
      return <CloudRain className="h-3.5 w-3.5 text-[#1b5951]" aria-hidden="true" />;
    case '闷热低压':
      return <ThermometerSun className="h-3.5 w-3.5 text-[#b5482a]" aria-hidden="true" />;
  }
}

export function TopStatusBar({
  gameState,
  timeSpeed,
  dayProgress,
  feedback,
  onSetTimeSpeed,
  onAdvanceDay,
  onOpenPondTab,
}: TopStatusBarProps) {
  const waterStatus = evaluateWaterQualityStatus(gameState);
  const tier = getPondTier(gameState.pond.facilityLevel);
  const saleMult = getEffectiveSaleMultiplier(gameState);
  const saleBonusPct = Math.round((saleMult - 1) * 100);

  const waterToneClass =
    waterStatus.tone === 'success'
      ? 'text-[#1b5951]'
      : waterStatus.tone === 'info'
        ? 'text-[#235d70]'
        : waterStatus.tone === 'warning'
          ? 'text-[#9e5c14]'
          : 'text-[#a93327]';

  const isLowFishWarning = !gameState.isBankrupt && gameState.fishes.length <= 2;

  const activeFeatures = [
    gameState.autoCareEnabled ? '自动护理' : null,
    gameState.autoRestockEnabled ? '自动补购' : null,
    gameState.autoSellMature ? '自动售鱼' : null,
  ].filter(Boolean);

  return (
    <div className="pointer-events-none flex flex-col gap-1.5 sm:gap-2">
      <div className="flex flex-wrap items-center justify-between gap-1.5 sm:gap-2.5">
        {/* Left: Brand, Level, Funds & Pond Telemetry */}
        <div className="manor-surface pointer-events-auto flex w-full sm:w-auto flex-wrap items-center justify-between sm:justify-start gap-2 sm:gap-3 rounded-2xl px-3 py-1.5 sm:px-3.5 sm:py-2">
          <div className="flex items-center gap-2 sm:pr-2.5 sm:border-r sm:border-[#5e4126]/18">
            <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border border-[#8b633c]/40 bg-gradient-to-br from-[#1b5951] to-[#2a786d] font-display text-xs font-bold text-white shadow-xs">
              鱼
            </div>
            <div className="min-w-0">
              <h1 className="font-display text-[13.5px] font-semibold tracking-tight text-[#13221d] sm:text-[15px] whitespace-nowrap leading-tight">
                梦幻鱼塘：水产庄园
              </h1>
              <div className="hidden sm:block text-[11px] font-medium text-[#1b5951] tabular-nums whitespace-nowrap">
                庄园 Lv.{gameState.manorLevel} · {getManorTitle(gameState.manorLevel)}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2.5 text-xs">
            <div className="rounded-xl border border-[#8b633c]/25 bg-gradient-to-b from-[#fffaf0]/90 to-[#f9efd9]/80 px-2.5 py-1">
              <span className="hidden sm:inline text-[11px] text-[#705330]">资金 </span>
              <span className="font-display font-semibold text-[#9e5c14] tabular-nums text-[13px] sm:text-sm">
                ¥{gameState.funds.toLocaleString('zh-CN', { maximumFractionDigits: 0 })}
              </span>
            </div>

            <button
              type="button"
              onClick={onOpenPondTab}
              className="flex min-h-[34px] items-center gap-1.5 rounded-xl border border-[#5d6e67]/20 bg-white/70 px-2.5 py-1 text-left transition-colors hover:border-[#1b5951]/40 hover:bg-[#eef7f4] cursor-pointer whitespace-nowrap"
            >
              <span className="font-semibold text-[#1b5951]">Lv.{tier.level}</span>
              <span className="font-semibold text-[#13221d] tabular-nums">
                {gameState.fishes.length}/{gameState.pond.maxRecommendedFish}
              </span>
              <span aria-hidden="true" className="text-[#13221d]/25">·</span>
              <span className={`font-semibold ${waterToneClass}`}>水{waterStatus.label}</span>
              {saleBonusPct > 0 && (
                <span className="hidden md:inline font-semibold text-[#1b5951] tabular-nums">
                  · 售价+{saleBonusPct}%
                </span>
              )}
              <span
                className={`hidden md:inline ${
                  gameState.isBankrupt
                    ? 'font-medium text-[#a93327]'
                    : gameState.anglerOpen
                      ? 'font-medium text-[#235d70]'
                      : 'font-medium text-[#5c6f67]'
                }`}
              >
                ·{' '}
                {gameState.isBankrupt
                  ? '钓鱼人已离去'
                  : gameState.anglerOpen
                    ? '免费垂钓开放'
                    : gameState.anglerUnlocked
                      ? '垂钓已暂停'
                      : '垂钓待解锁'}
              </span>
            </button>

            {activeFeatures.length > 0 && (
              <div className="hidden items-center gap-1.5 rounded-xl border border-[#1b5951]/25 bg-[#eef7f4]/85 px-2.5 py-1 text-[11px] font-semibold text-[#134740] xl:inline-flex">
                <Bot className="h-3.5 w-3.5 text-[#1b5951]" />
                <span>{activeFeatures.join(' · ')}</span>
              </div>
            )}
          </div>
        </div>

        {/* Right: Weather, Day Progress & Speed Controls */}
        <div className="manor-surface pointer-events-auto flex w-full sm:w-auto items-center justify-between sm:justify-start gap-2 sm:gap-2.5 rounded-2xl px-3 py-1 sm:py-1.5">
          <div className="flex items-center gap-2 text-xs">
            <WeatherIcon weather={gameState.weather} />
            <span className="font-medium text-[#13221d] whitespace-nowrap">{gameState.weather}</span>
            <span className="text-[#5c6f67] tabular-nums whitespace-nowrap">
              {gameState.pond.temperatureC.toFixed(1)}°C
            </span>
          </div>

          <div className="h-4 w-px bg-[#5e4126]/18" aria-hidden="true" />

          <div className="flex flex-col min-w-[66px] sm:min-w-[76px]">
            <span className="text-xs font-semibold text-[#13221d] tabular-nums whitespace-nowrap">
              第 {gameState.day} 天
            </span>
            <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-[#13221d]/10">
              <div
                className="h-full rounded-full bg-gradient-to-r from-[#1b5951] to-[#2e8577] transition-all duration-150"
                style={{ width: `${Math.round(dayProgress * 100)}%` }}
              />
            </div>
          </div>

          <div className="flex items-center gap-0.5 rounded-xl border border-[#5e4126]/15 bg-[#13221d]/5 p-0.5">
            <button
              type="button"
              onClick={() => onSetTimeSpeed(0)}
              aria-label="暂停时间"
              title="暂停"
              className={`inline-flex h-8 w-8 items-center justify-center rounded-lg text-xs transition-colors cursor-pointer ${
                timeSpeed === 0
                  ? 'bg-[#1b5951] text-white shadow-xs'
                  : 'text-[#31443d] hover:bg-white/80'
              }`}
            >
              <Pause className="h-3.5 w-3.5" />
            </button>
            <button
              type="button"
              onClick={() => onSetTimeSpeed(1)}
              aria-label="正常速度"
              title="正常速度 (1x)"
              className={`inline-flex h-8 items-center gap-0.5 rounded-lg px-2 text-xs font-medium transition-colors cursor-pointer ${
                timeSpeed === 1
                  ? 'bg-[#1b5951] text-white shadow-xs'
                  : 'text-[#31443d] hover:bg-white/80'
              }`}
            >
              <Play className="h-3 w-3" />
              <span>1x</span>
            </button>
            <button
              type="button"
              onClick={() => onSetTimeSpeed(3)}
              aria-label="快速推进"
              title="快速推进 (3x)"
              className={`inline-flex h-8 items-center gap-0.5 rounded-lg px-2 text-xs font-medium transition-colors cursor-pointer ${
                timeSpeed === 3
                  ? 'bg-[#1b5951] text-white shadow-xs'
                  : 'text-[#31443d] hover:bg-white/80'
              }`}
            >
              <FastForward className="h-3 w-3" />
              <span>3x</span>
            </button>
            <button
              type="button"
              disabled={gameState.isBankrupt}
              onClick={onAdvanceDay}
              aria-label="立即推进一天"
              title="立即推进一天"
              className="inline-flex h-8 items-center gap-1 rounded-lg px-2 text-xs font-semibold text-[#184f49] transition-colors hover:bg-white/85 disabled:opacity-40 cursor-pointer whitespace-nowrap"
            >
              <SkipForward className="h-3 w-3" />
              <span>+1天</span>
            </button>
          </div>
        </div>
      </div>

      {/* Transient Feedback & Alerts */}
      <div className="flex flex-wrap items-start gap-1.5 sm:gap-2">
        {feedback && (
          <div
            role="status"
            className={`manor-surface pointer-events-auto rounded-xl px-3.5 py-2 text-xs font-medium ${
              feedback.level === 'success'
                ? 'border-[#1b5951]/35 text-[#134740]'
                : feedback.level === 'warning'
                  ? 'border-[#b86d15]/35 text-[#8a510c]'
                  : 'border-[#b5372b]/40 text-[#8f241b]'
            }`}
          >
            {feedback.message}
          </div>
        )}

        {isLowFishWarning && (
          <button
            type="button"
            onClick={onOpenPondTab}
            className="pointer-events-auto inline-flex items-center gap-1.5 rounded-xl border border-[#b5372b]/40 bg-[#fdf0ee]/95 px-3 py-1.5 text-xs font-semibold text-[#8f241b] shadow-xs cursor-pointer"
          >
            <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
            <span>警报：仅剩 {gameState.fishes.length} 尾鱼，空塘将破产！</span>
          </button>
        )}

        {gameState.diseaseDaysRemaining > 0 && !gameState.isBankrupt && (
          <button
            type="button"
            onClick={onOpenPondTab}
            className="pointer-events-auto inline-flex items-center gap-1.5 rounded-xl border border-[#b5372b]/35 bg-[#fdf0ee]/95 px-3 py-1.5 text-xs font-semibold text-[#8f241b] shadow-xs cursor-pointer"
          >
            <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
            <span>鱼病风险（剩 {gameState.diseaseDaysRemaining} 天）· 点击处理</span>
          </button>
        )}

        {gameState.lastEvent && gameState.lastEvent.day === gameState.day && (
          <div
            className={`manor-surface pointer-events-auto inline-flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-medium ${
              gameState.lastEvent.severity === 'positive'
                ? 'border-[#1b5951]/30 text-[#134740]'
                : gameState.lastEvent.severity === 'warning'
                  ? 'border-[#b86d15]/35 text-[#8a510c]'
                  : 'border-[#b5372b]/35 text-[#8f241b]'
            }`}
          >
            <Sparkles className="h-3.5 w-3.5 shrink-0" />
            <span>
              今日事件：{gameState.lastEvent.title} — {gameState.lastEvent.description}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
