import {
  BookOpen,
  ChevronDown,
  ChevronUp,
  Coins,
  Droplets,
  Landmark,
  RotateCcw,
  ShoppingBag,
  Utensils,
  Waves,
  X,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import { useEffect, useState } from 'react';
import {
  computeEdibleSinglePrice,
  evaluateWaterQualityStatus,
} from '../game/simulation';
import { CAMERA_PRESETS } from '../scene/constants';
import type {
  ActionFeedback,
  AdRewardType,
  CameraPresetId,
  FeedTypeId,
  FishSpeciesId,
  GameState,
  SceneSelection,
  TimeSpeed,
} from '../types/pond';
import { AdSponsorModal } from './AdSponsorModal';
import { BankruptcyModal } from './BankruptcyModal';
import { ManagementDrawer, type ManagementTabId } from './ManagementDrawer';
import { CornerOrnaments, SpeciesEmblem } from './panels/PanelPrimitives';
import { TopStatusBar } from './TopStatusBar';

interface SceneHUDProps {
  gameState: GameState;
  timeSpeed: TimeSpeed;
  dayProgress: number;
  feedback: ActionFeedback | null;
  selection: SceneSelection;
  activePreset: CameraPresetId;
  activeDrawerTab: ManagementTabId | null;
  pendingAdType: AdRewardType | null;
  onToggleDrawerTab: (tab: ManagementTabId | null) => void;
  onSetTimeSpeed: (speed: TimeSpeed) => void;
  onAdvanceDay: () => void;
  onSelectPreset: (presetId: CameraPresetId) => void;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onClearSelection: () => void;
  onSelectFishInScene: (fishId: string) => void;
  onBuyFry: (speciesId: FishSpeciesId, qty: number) => void;
  onBuyFeed: (feedId: FeedTypeId, bags: number) => void;
  onFeedPond: (feedId: FeedTypeId, amountKg: number) => void;
  onAeratePond: () => void;
  onChangeWater: () => void;
  onTreatDisease: () => void;
  onExpandPond: () => void;
  onToggleAnglerOpen: () => void;
  onToggleAutoSellMature: () => void;
  onWatchAd: (adType: AdRewardType) => void;
  onCompleteAd: (adType: AdRewardType) => void;
  onCancelAd: () => void;
  onToggleAutoCare: () => void;
  onToggleAutoRestock: () => void;
  onBreedPair: (speciesId: FishSpeciesId) => void;
  onSellSingleFish: (fishId: string) => void;
  onResetSave: () => void;
}

const DOCK_TABS: Array<{
  id: ManagementTabId;
  label: string;
  Icon: typeof Waves;
}> = [
  { id: 'pond', label: '鱼塘管理', Icon: Waves },
  { id: 'shop', label: '鱼苗饲料店', Icon: ShoppingBag },
  { id: 'care', label: '投喂护理', Icon: Utensils },
  { id: 'harvest', label: '售鱼行情', Icon: Coins },
  { id: 'finance', label: '财务报表', Icon: Landmark },
  { id: 'logs', label: '养殖日志', Icon: BookOpen },
];

export function SceneHUD({
  gameState,
  timeSpeed,
  dayProgress,
  feedback,
  selection,
  activePreset,
  activeDrawerTab,
  pendingAdType,
  onToggleDrawerTab,
  onSetTimeSpeed,
  onAdvanceDay,
  onSelectPreset,
  onZoomIn,
  onZoomOut,
  onClearSelection,
  onSelectFishInScene,
  onBuyFry,
  onBuyFeed,
  onFeedPond,
  onAeratePond,
  onChangeWater,
  onTreatDisease,
  onExpandPond,
  onToggleAnglerOpen,
  onToggleAutoSellMature,
  onWatchAd,
  onCompleteAd,
  onCancelAd,
  onToggleAutoCare,
  onToggleAutoRestock,
  onBreedPair,
  onSellSingleFish,
  onResetSave,
}: SceneHUDProps) {
  const [dockCollapsed, setDockCollapsed] = useState(false);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'h' || e.key === 'H') {
        setDockCollapsed((prev) => !prev);
      } else if (e.key === 'Escape') {
        if (pendingAdType) {
          onCancelAd();
        } else if (activeDrawerTab) {
          onToggleDrawerTab(null);
        } else if (selection.type !== 'none') {
          onClearSelection();
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [activeDrawerTab, onCancelAd, onClearSelection, onToggleDrawerTab, pendingAdType, selection.type]);

  const waterEval = evaluateWaterQualityStatus(gameState);
  const selectedFishId = selection.type === 'fish' ? selection.fish.fish.id : null;
  const maturePrizedCount = gameState.fishes.filter(
    (f) => f.growthStage === '成熟期' && (f.quality === '精品' || f.quality === '极品'),
  ).length;

  return (
    <div className="pointer-events-none fixed inset-0 z-10 flex flex-col justify-between p-2.5 sm:p-4">
      <TopStatusBar
        gameState={gameState}
        timeSpeed={timeSpeed}
        dayProgress={dayProgress}
        feedback={feedback}
        onSetTimeSpeed={onSetTimeSpeed}
        onAdvanceDay={onAdvanceDay}
        onOpenPondTab={() => onToggleDrawerTab('pond')}
      />

      {/* Middle Area: Management Drawer OR Selected Pond/Fish Inspector */}
      <div className="my-1.5 flex flex-1 items-end justify-end overflow-hidden sm:my-2">
        {activeDrawerTab ? (
          <ManagementDrawer
            activeTab={activeDrawerTab}
            gameState={gameState}
            selectedFishId={selectedFishId}
            onChangeTab={(tab) => onToggleDrawerTab(tab)}
            onClose={() => onToggleDrawerTab(null)}
            onSelectFishInScene={onSelectFishInScene}
            onBuyFry={onBuyFry}
            onBuyFeed={onBuyFeed}
            onFeedPond={onFeedPond}
            onAeratePond={onAeratePond}
            onChangeWater={onChangeWater}
            onTreatDisease={onTreatDisease}
            onExpandPond={onExpandPond}
            onToggleAnglerOpen={onToggleAnglerOpen}
            onToggleAutoSellMature={onToggleAutoSellMature}
            onWatchAd={onWatchAd}
            onToggleAutoCare={onToggleAutoCare}
            onToggleAutoRestock={onToggleAutoRestock}
            onBreedPair={onBreedPair}
            onSellSingleFish={onSellSingleFish}
            onResetSave={onResetSave}
          />
        ) : (
          selection.type !== 'none' && (
            <div className="manor-glass-wood manor-scroll animate-manor-sheet pointer-events-auto relative max-h-[58dvh] sm:max-h-full w-full max-w-[400px] overflow-y-auto overscroll-contain rounded-2xl p-3.5 sm:p-4">
              <CornerOrnaments tone="wood" />

              {selection.type === 'pond' ? (
                <div className="relative z-10">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-[11px] font-medium text-[#8b633c]">
                        生态鱼塘 · 设施 Lv.{gameState.pond.facilityLevel} · 水质{waterEval.label}
                      </p>
                      <h2 className="font-display mt-0.5 text-lg font-semibold text-[#13221d]">
                        {gameState.pond.name}
                      </h2>
                    </div>
                    <button
                      type="button"
                      onClick={onClearSelection}
                      aria-label="关闭鱼塘信息"
                      className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-[#5e4126]/20 bg-white/65 text-[#465951] transition-colors hover:bg-white hover:text-[#13221d] cursor-pointer"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>

                  <div className="manor-stone-card mt-3 grid grid-cols-3 gap-x-3 gap-y-2.5 rounded-xl p-3 text-xs tabular-nums">
                    <div>
                      <div className="text-[11px] text-[#5c6f67]">当前密度</div>
                      <div className="mt-0.5 font-semibold text-[#13221d]">
                        {gameState.fishes.length} / {gameState.pond.maxRecommendedFish} 尾
                      </div>
                    </div>
                    <div>
                      <div className="text-[11px] text-[#5c6f67]">水体容量</div>
                      <div className="mt-0.5 font-semibold text-[#13221d]">
                        {gameState.pond.waterVolumeM3} m³
                      </div>
                    </div>
                    <div>
                      <div className="text-[11px] text-[#5c6f67]">水深</div>
                      <div className="mt-0.5 font-semibold text-[#13221d]">
                        {gameState.pond.waterDepthM.toFixed(2)} m
                      </div>
                    </div>
                    <div>
                      <div className="text-[11px] text-[#5c6f67]">实时水温</div>
                      <div className="mt-0.5 font-semibold text-[#13221d]">
                        {gameState.pond.temperatureC.toFixed(1)} °C
                      </div>
                    </div>
                    <div>
                      <div className="text-[11px] text-[#5c6f67]">溶氧量</div>
                      <div className="mt-0.5 font-semibold text-[#13221d]">
                        {gameState.pond.dissolvedOxygenMgL.toFixed(1)} mg/L
                      </div>
                    </div>
                    <div>
                      <div className="text-[11px] text-[#5c6f67]">pH 值</div>
                      <div className="mt-0.5 font-semibold text-[#13221d]">
                        {gameState.pond.ph.toFixed(2)}
                      </div>
                    </div>
                    <div>
                      <div className="text-[11px] text-[#5c6f67]">氨氮</div>
                      <div className="mt-0.5 font-semibold text-[#13221d]">
                        {gameState.pond.ammoniaMgL.toFixed(2)} mg/L
                      </div>
                    </div>
                    <div>
                      <div className="text-[11px] text-[#5c6f67]">亚硝酸盐</div>
                      <div className="mt-0.5 font-semibold text-[#13221d]">
                        {gameState.pond.nitriteMgL.toFixed(2)} mg/L
                      </div>
                    </div>
                    <div>
                      <div className="text-[11px] text-[#5c6f67]">池底残饵</div>
                      <div className="mt-0.5 font-semibold text-[#13221d]">
                        {gameState.pond.leftoverFeedKg.toFixed(2)} kg
                      </div>
                    </div>
                  </div>

                  <div className="mt-2.5 text-[11.5px] text-[#465951] tabular-nums">
                    <span>生态食用鱼 {gameState.fishes.length} 尾</span>
                    <span className="mx-1.5" aria-hidden="true">·</span>
                    <span>待售成熟精品/极品 {maturePrizedCount} 尾</span>
                  </div>

                  <div className="mt-3 flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => onToggleDrawerTab('pond')}
                      className="inline-flex min-h-[40px] flex-1 items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-[#1b5951] to-[#267367] px-3 py-2 text-xs font-semibold text-white transition-all hover:brightness-105 cursor-pointer"
                    >
                      <Waves className="h-3.5 w-3.5" />
                      <span>进入鱼塘管理</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onToggleDrawerTab('care')}
                      className="inline-flex min-h-[40px] flex-1 items-center justify-center gap-1.5 rounded-xl border border-[#1b5951]/25 bg-[#eef7f4]/85 px-3 py-2 text-xs font-semibold text-[#134740] transition-colors hover:bg-[#dfeee9] cursor-pointer"
                    >
                      <Droplets className="h-3.5 w-3.5" />
                      <span>投喂与增氧</span>
                    </button>
                  </div>
                </div>
              ) : (
                (() => {
                  const live = selection.fish;
                  const fish = live.fish;
                  const sellPrice = computeEdibleSinglePrice(fish, gameState);

                  return (
                    <div className="relative z-10">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-start gap-2.5 min-w-0">
                          <SpeciesEmblem speciesId={fish.speciesId} />
                          <div className="min-w-0">
                            <p className="text-[11px] font-medium text-[#1b5951]">
                              生态食用鱼 · {live.activity}
                            </p>
                            <h2 className="font-display mt-0.5 text-lg font-semibold text-[#13221d] truncate">
                              {fish.name}
                            </h2>
                            <p className="text-[11px] text-[#556860] tabular-nums truncate">
                              {fish.variety} · {fish.id}
                            </p>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={onClearSelection}
                          aria-label="关闭鱼类信息"
                          className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-[#5e4126]/20 bg-white/65 text-[#465951] transition-colors hover:bg-white hover:text-[#13221d] cursor-pointer"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>

                      <div className="manor-stone-card mt-3 grid grid-cols-3 gap-x-3 gap-y-2 rounded-xl p-3 text-xs tabular-nums">
                        <div>
                          <div className="text-[11px] text-[#5c6f67]">成长阶段</div>
                          <div className="mt-0.5 font-semibold text-[#1b5951]">{fish.growthStage}</div>
                        </div>
                        <div>
                          <div className="text-[11px] text-[#5c6f67]">品质</div>
                          <div className="mt-0.5 font-semibold text-[#9e5c14]">{fish.quality}</div>
                        </div>
                        <div>
                          <div className="text-[11px] text-[#5c6f67]">年龄</div>
                          <div className="mt-0.5 font-semibold text-[#13221d]">{fish.ageDays} 天</div>
                        </div>
                        <div>
                          <div className="text-[11px] text-[#5c6f67]">体重</div>
                          <div className="mt-0.5 font-semibold text-[#13221d]">
                            {fish.weightKg.toFixed(2)} kg
                          </div>
                        </div>
                        <div>
                          <div className="text-[11px] text-[#5c6f67]">体长</div>
                          <div className="mt-0.5 font-semibold text-[#13221d]">
                            {fish.lengthCm.toFixed(1)} cm
                          </div>
                        </div>
                        <div>
                          <div className="text-[11px] text-[#5c6f67]">购买价格</div>
                          <div className="mt-0.5 font-semibold text-[#13221d]">¥{fish.purchasePrice}</div>
                        </div>
                        <div>
                          <div className="text-[11px] text-[#5c6f67]">健康值</div>
                          <div
                            className={`mt-0.5 font-semibold ${
                              fish.health < 65 ? 'text-[#a93327]' : 'text-[#1b5951]'
                            }`}
                          >
                            {Math.round(fish.health)} / 100
                          </div>
                        </div>
                        <div>
                          <div className="text-[11px] text-[#5c6f67]">饥饿值</div>
                          <div
                            className={`mt-0.5 font-semibold ${
                              fish.hunger > 70 ? 'text-[#9e5c14]' : 'text-[#13221d]'
                            }`}
                          >
                            {Math.round(fish.hunger)} / 100
                          </div>
                        </div>
                        <div>
                          <div className="text-[11px] text-[#5c6f67]">当前水深</div>
                          <div className="mt-0.5 font-semibold text-[#13221d]">
                            {live.depthMeters.toFixed(2)} m
                          </div>
                        </div>
                      </div>

                      <div className="mt-3 flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => onToggleDrawerTab('care')}
                          className="inline-flex min-h-[40px] flex-1 items-center justify-center gap-1.5 rounded-xl border border-[#1b5951]/25 bg-[#eef7f4]/85 px-3 py-2 text-xs font-semibold text-[#134740] transition-colors hover:bg-[#dfeee9] cursor-pointer"
                        >
                          <Utensils className="h-3.5 w-3.5" />
                          <span>投喂护理</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onSellSingleFish(fish.id)}
                          className="inline-flex min-h-[40px] flex-1 items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-[#9e5c14] via-[#b86d15] to-[#ca7f22] px-3 py-2 text-xs font-semibold text-white transition-all hover:brightness-105 tabular-nums cursor-pointer"
                        >
                          <Coins className="h-3.5 w-3.5" />
                          <span>单条出售 (¥{sellPrice})</span>
                        </button>
                      </div>
                    </div>
                  );
                })()
              )}
            </div>
          )
        )}
      </div>

      {/* Bottom Center Navigation & Camera Dock */}
      <div className="flex flex-col items-center">
        <button
          type="button"
          onClick={() => setDockCollapsed((prev) => !prev)}
          className="manor-surface pointer-events-auto mb-1.5 inline-flex min-h-[30px] items-center gap-1.5 rounded-xl px-3 py-1 text-xs font-medium text-[#2c3e37] transition-colors hover:bg-white cursor-pointer"
        >
          {dockCollapsed ? (
            <>
              <ChevronUp className="h-3.5 w-3.5" aria-hidden="true" />
              <span>展开庄园操作栏</span>
            </>
          ) : (
            <>
              <ChevronDown className="h-3.5 w-3.5" aria-hidden="true" />
              <span>收起操作栏</span>
            </>
          )}
        </button>

        {!dockCollapsed && (
          <div className="manor-surface pointer-events-auto flex w-full max-w-[96vw] sm:w-auto flex-col items-center justify-center gap-1.5 rounded-2xl px-2.5 py-2 sm:flex-row sm:flex-wrap sm:gap-2 sm:px-3">
            {/* Horizontal scroll on mobile so all 6 tabs remain single-line & touch-friendly */}
            <div className="no-scrollbar flex w-full sm:w-auto items-center justify-start sm:justify-center gap-1 overflow-x-auto pb-0.5 sm:pb-0">
              {DOCK_TABS.map(({ id, label, Icon }) => {
                const active = activeDrawerTab === id;
                return (
                  <button
                    key={id}
                    type="button"
                    onClick={() => onToggleDrawerTab(active ? null : id)}
                    className={`inline-flex min-h-[40px] sm:min-h-[36px] items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-semibold transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                      active
                        ? 'bg-gradient-to-r from-[#1b5951] to-[#267367] text-white shadow-xs'
                        : 'border border-[#5e4126]/12 bg-white/60 text-[#283c35] hover:bg-white hover:text-[#13221d]'
                    }`}
                  >
                    <Icon className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                    <span>{label}</span>
                  </button>
                );
              })}
            </div>

            <div className="hidden h-6 w-px bg-[#5e4126]/18 xl:block" aria-hidden="true" />

            <div className="flex w-full sm:w-auto items-center justify-between sm:justify-center gap-1.5 border-t border-[#5e4126]/12 pt-1.5 sm:border-t-0 sm:pt-0">
              <div className="no-scrollbar flex min-w-0 flex-1 sm:flex-initial items-center gap-0.5 overflow-x-auto rounded-xl border border-[#5e4126]/15 bg-[#13221d]/5 p-0.5">
                {CAMERA_PRESETS.map((preset) => {
                  const isActive = activePreset === preset.id;
                  return (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => onSelectPreset(preset.id)}
                      className={`min-h-[32px] rounded-lg px-2 py-1 text-[11.5px] font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                        isActive
                          ? 'bg-white text-[#13221d] shadow-xs'
                          : 'text-[#465951] hover:text-[#13221d]'
                      }`}
                    >
                      {preset.label}
                    </button>
                  );
                })}
              </div>

              <div className="flex items-center gap-0.5">
                <button
                  type="button"
                  onClick={onZoomIn}
                  aria-label="放大画面"
                  title="放大"
                  className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-[#31443d] transition-colors hover:bg-white/80 hover:text-[#13221d] cursor-pointer"
                >
                  <ZoomIn className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  onClick={onZoomOut}
                  aria-label="缩小画面"
                  title="缩小"
                  className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-[#31443d] transition-colors hover:bg-white/80 hover:text-[#13221d] cursor-pointer"
                >
                  <ZoomOut className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  onClick={() => onSelectPreset('isometric')}
                  aria-label="重置等距视角"
                  title="重置视角"
                  className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-[#31443d] transition-colors hover:bg-white/80 hover:text-[#13221d] cursor-pointer"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {pendingAdType && (
        <AdSponsorModal
          adType={pendingAdType}
          onComplete={onCompleteAd}
          onCancel={onCancelAd}
        />
      )}

      {gameState.isBankrupt && (
        <BankruptcyModal gameState={gameState} onRestart={onResetSave} />
      )}
    </div>
  );
}
