import { AlertOctagon, RotateCcw } from 'lucide-react';
import { getPondTier } from '../game/catalog';
import type { GameState } from '../types/pond';
import { CornerOrnaments } from './panels/PanelPrimitives';

interface BankruptcyModalProps {
  gameState: GameState;
  onRestart: () => void;
}

export function BankruptcyModal({ gameState, onRestart }: BankruptcyModalProps) {
  const tier = getPondTier(gameState.pond.facilityLevel);
  const netProfit = gameState.totalRevenue - gameState.totalExpense;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="bankrupt-modal-title"
      className="pointer-events-auto fixed inset-0 z-50 flex items-center justify-center bg-[#181210]/65 p-4 backdrop-blur-[3px]"
    >
      <div className="manor-glass-wood animate-manor-sheet relative w-full max-w-md overflow-hidden rounded-2xl border-[#b5372b]/45">
        <CornerOrnaments tone="danger" />

        <div className="relative z-10 bg-gradient-to-r from-[#8f241b] via-[#b5372b] to-[#c84d37] px-5 py-4 text-white">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/15">
              <AlertOctagon className="h-5 w-5" />
            </div>
            <div>
              <div className="text-[11px] font-medium text-white/85">庄园经营失败提示</div>
              <h2 id="bankrupt-modal-title" className="font-display text-lg font-semibold">
                鱼塘荒废 · 庄园破产失败
              </h2>
            </div>
          </div>
        </div>

        <div className="relative z-10 space-y-4 p-5">
          <div className="rounded-xl border border-[#b5372b]/25 bg-[#fdf0ee]/90 p-3.5 text-xs leading-relaxed text-[#7c1f17]">
            {gameState.bankruptReason ??
              '鱼塘内已没有任何鱼类，钓鱼人纷纷散去，水产庄园荒废破产。'}
          </div>

          <div className="grid grid-cols-2 gap-2.5 text-xs tabular-nums">
            <div className="manor-stone-card rounded-xl p-3">
              <div className="text-[11px] text-[#556860]">累计经营天数</div>
              <div className="mt-1 font-display text-base font-semibold text-[#13221d]">
                第 {gameState.day} 天
              </div>
            </div>
            <div className="manor-stone-card rounded-xl p-3">
              <div className="text-[11px] text-[#556860]">鱼塘最高规模</div>
              <div className="mt-1 font-display text-base font-semibold text-[#13221d]">
                Lv.{tier.level} · {tier.capacity} 尾级
              </div>
            </div>
            <div className="manor-stone-card rounded-xl p-3">
              <div className="text-[11px] text-[#556860]">累计营业收入</div>
              <div className="mt-1 font-display text-base font-semibold text-[#1b5951]">
                ¥{gameState.totalRevenue.toLocaleString('zh-CN')}
              </div>
            </div>
            <div className="manor-stone-card rounded-xl p-3">
              <div className="text-[11px] text-[#556860]">经营净收益</div>
              <div
                className={`mt-1 font-display text-base font-semibold ${
                  netProfit >= 0 ? 'text-[#1b5951]' : 'text-[#a93327]'
                }`}
              >
                {netProfit >= 0 ? '+' : ''}¥{netProfit.toLocaleString('zh-CN')}
              </div>
            </div>
            <div className="manor-stone-card rounded-xl p-3">
              <div className="text-[11px] text-[#556860]">累计出栏 / 钓获</div>
              <div className="mt-1 font-display text-base font-semibold text-[#13221d]">
                {gameState.totalHarvestedCount} 尾
              </div>
            </div>
            <div className="manor-stone-card rounded-xl p-3">
              <div className="text-[11px] text-[#556860]">接待钓鱼客</div>
              <div className="mt-1 font-display text-base font-semibold text-[#13221d]">
                {gameState.totalAnglerVisits} 人次
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={onRestart}
            className="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#1b5951] to-[#267367] px-4 py-3 text-sm font-semibold text-white shadow-sm transition-all hover:brightness-105 cursor-pointer"
          >
            <RotateCcw className="h-4 w-4" />
            <span>重整庄园 · 重新开始第 1 天</span>
          </button>
        </div>
      </div>
    </div>
  );
}
