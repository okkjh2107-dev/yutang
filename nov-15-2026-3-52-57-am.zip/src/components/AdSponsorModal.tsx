import { CheckCircle2, Coins, Fish, Play, ShoppingBag, Sparkles, Utensils, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { AdRewardType } from '../types/pond';
import { CornerOrnaments } from './panels/PanelPrimitives';

interface AdSponsorModalProps {
  adType: AdRewardType;
  onComplete: (adType: AdRewardType) => void;
  onCancel: () => void;
}

const AD_DURATION_SEC = 4;

const AD_META: Record<
  AdRewardType,
  {
    title: string;
    sponsorTitle: string;
    description: string;
    buttonLabel: string;
    Icon: typeof Utensils;
  }
> = {
  auto_care: {
    title: '解锁「自动投喂与水质护理」',
    sponsorTitle: '《生态智慧渔业农博会》智能养护补贴',
    description:
      '赞助商补贴全自动水车增氧与生态调水系统：当溶氧、氨氮、亚硝酸盐、pH、残饵或鱼病偏离「优」或接近警戒时自动处理，全指标保持优质。',
    buttonLabel: '立即开启自动投喂护理',
    Icon: Utensils,
  },
  auto_restock: {
    title: '解锁「自动买鱼苗与鱼饲料」',
    sponsorTitle: '《生态智慧渔业农博会》冷链补给赞助',
    description:
      '赞助商直供鲜活鱼苗与精选饵料：当鱼塘在池数量未过半或饲料库存未过半（<10kg）时，自动为您下单补购并投放到位。',
    buttonLabel: '立即开启自动买苗买料',
    Icon: ShoppingBag,
  },
  angler_open: {
    title: '解锁「钓鱼人免费入场」',
    sponsorTitle: '《全域乡村文旅垂钓节》客源扶持',
    description:
      '解锁后每日迎来免费入场的钓鱼客在岸边垂钓，钓鱼客钓起的食用鱼将直接按成熟鱼市价为您结算资金入账。',
    buttonLabel: '立即开放钓鱼人免费入场',
    Icon: Fish,
  },
  auto_sell: {
    title: '解锁「成熟鱼自动售出」',
    sponsorTitle: '《鲜活水产直供平台》产销一体补贴',
    description:
      '解锁后，池内普通与良种食用鱼一经达到成熟期即按实时市价自动出栏结算资金，精品与极品成鱼则保留供您单独高价出售。',
    buttonLabel: '立即开启成熟鱼自动售出',
    Icon: Coins,
  },
};

export function AdSponsorModal({ adType, onComplete, onCancel }: AdSponsorModalProps) {
  const [secondsLeft, setSecondsLeft] = useState(AD_DURATION_SEC);

  useEffect(() => {
    setSecondsLeft(AD_DURATION_SEC);
    const timer = window.setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          window.clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => window.clearInterval(timer);
  }, [adType]);

  const progressPct = ((AD_DURATION_SEC - secondsLeft) / AD_DURATION_SEC) * 100;
  const meta = AD_META[adType];
  const Icon = meta.Icon;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="ad-sponsor-title"
      className="pointer-events-auto fixed inset-0 z-40 flex items-center justify-center bg-[#0d1a16]/55 p-4 backdrop-blur-[3px]"
    >
      <div className="manor-glass-wood animate-manor-sheet relative w-full max-w-md overflow-hidden rounded-2xl">
        <CornerOrnaments tone="wood" />

        <div className="relative z-10 bg-gradient-to-br from-[#14443e] via-[#1b5951] to-[#267367] px-5 py-4 text-white">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="inline-flex items-center gap-1.5 text-[11px] font-medium text-[#d7efe8]">
                <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
                <span>庄园赞助商激励短片</span>
              </div>
              <h2 id="ad-sponsor-title" className="font-display mt-1 text-lg font-semibold">
                {meta.title}
              </h2>
            </div>
            <button
              type="button"
              onClick={onCancel}
              aria-label="关闭赞助短片"
              className="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-white/12 text-white/90 transition-colors hover:bg-white/22 hover:text-white cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div className="relative z-10 space-y-4 p-5">
          <div className="manor-wood-card rounded-2xl p-4">
            <div className="flex items-start gap-3">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-[#8b633c]/25 bg-white/75 text-[#9e5c14]">
                <Icon className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xs font-semibold text-[#705330]">{meta.sponsorTitle}</div>
                <p className="mt-1 text-xs leading-relaxed text-[#4f4335]">{meta.description}</p>
              </div>
            </div>
          </div>

          <div className="manor-stone-card rounded-xl p-3 space-y-2">
            <div className="flex items-center justify-between text-xs tabular-nums">
              <span className="inline-flex items-center gap-1.5 font-medium text-[#2c3e37]">
                {secondsLeft > 0 ? (
                  <>
                    <Play className="h-3.5 w-3.5 text-[#1b5951]" />
                    <span>赞助短片播放中，请稍候…</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="h-3.5 w-3.5 text-[#1b5951]" />
                    <span className="font-semibold text-[#1b5951]">奖励已就绪，点击下方按钮立即生效</span>
                  </>
                )}
              </span>
              <span className="font-semibold text-[#13221d]">
                {secondsLeft > 0 ? `剩余 ${secondsLeft} 秒` : '已完成'}
              </span>
            </div>
            <div className="h-2 w-full overflow-hidden rounded-full bg-[#13221d]/10">
              <div
                className="h-full rounded-full bg-gradient-to-r from-[#1b5951] to-[#2e8577] transition-all duration-500"
                style={{ width: `${progressPct}%` }}
              />
            </div>
          </div>

          <div className="flex items-center gap-2.5 pt-1">
            <button
              type="button"
              onClick={onCancel}
              className="inline-flex min-h-[42px] flex-1 items-center justify-center rounded-xl border border-[#5d6e67]/25 bg-white/75 px-4 py-2.5 text-xs font-semibold text-[#465951] transition-colors hover:bg-white cursor-pointer"
            >
              取消观看
            </button>
            <button
              type="button"
              disabled={secondsLeft > 0}
              onClick={() => onComplete(adType)}
              className="inline-flex min-h-[42px] flex-[1.6] items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-[#1b5951] to-[#267367] px-4 py-2.5 text-xs font-semibold text-white shadow-sm transition-all hover:brightness-105 disabled:cursor-not-allowed disabled:from-[#13221d]/18 disabled:to-[#13221d]/18 disabled:text-[#5c6f67] cursor-pointer"
            >
              <CheckCircle2 className="h-4 w-4 shrink-0" />
              <span>
                {secondsLeft > 0 ? `等待短片结束 (${secondsLeft}s)` : meta.buttonLabel}
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
