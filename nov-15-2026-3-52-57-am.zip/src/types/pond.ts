export type FishCategory = 'edible';

export type FishPatternId =
  | 'koi_kohaku'
  | 'koi_showa'
  | 'koi_ogon'
  | 'koi_black'
  | 'koi_tancho'
  | 'koi_asagi'
  | 'food_grass_carp'
  | 'food_carp'
  | 'food_tilapia'
  | 'food_mandarin'
  | 'food_crucian';

export type FishSpeciesId = 'grass_carp' | 'common_carp' | 'tilapia';

export type GrowthStage = '鱼苗期' | '幼鱼期' | '成长期' | '成熟期';
export type FishQuality = '普通' | '良种' | '精品' | '极品';
export type FeedTypeId = 'standard' | 'high_protein';
export type WeatherType = '晴朗微风' | '多云舒爽' | '阵雨充氧' | '闷热低压';
export type TimeSpeed = 0 | 1 | 3;

export interface FishSpeciesSpec {
  id: FishSpeciesId;
  name: string;
  englishName: string;
  category: FishCategory;
  patternId: FishPatternId;
  fryPrice: number;
  initialWeightKg: number;
  initialLengthCm: number;
  marketWeightKg: number;
  maxWeightKg: number;
  maxLengthCm: number;
  dailyGrowthKg: number;
  marketPricePerKg: number;
  preferredFeed: FeedTypeId;
  preferredDepth: number;
  baseSpeed: number;
  temperament: string;
  description: string;
}

export interface ManagedFish {
  id: string;
  name: string;
  speciesId: FishSpeciesId;
  variety: string;
  category: FishCategory;
  patternId: FishPatternId;
  ageDays: number;
  weightKg: number;
  lengthCm: number;
  health: number; // 0..100
  hunger: number; // 0 = 饱腹, 100 = 极度饥饿
  growthStage: GrowthStage;
  quality: FishQuality;
  purchasePrice: number;
  feedCostAccumulated: number;
  pondId: string;
  preferredDepth: number;
  baseSpeed: number;
  temperament: string;
  description: string;
}

export interface FishLiveState {
  fish: ManagedFish;
  activity: '悠然巡游' | '浅滩觅食' | '中层洄游' | '敏捷转向';
  speedCmPerSec: number;
  depthMeters: number;
}

export interface FeedSpec {
  id: FeedTypeId;
  name: string;
  bagWeightKg: number;
  standardCapacityKg: number;
  pricePerBag: number;
  growthMultiplier: number;
  waterPollutionFactor: number;
  suitableFor: string;
  description: string;
}

export type PondLevel = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9;

export interface PondExpansionTier {
  level: PondLevel;
  name: string;
  upgradeCost: number;
  capacity: number;
  areaSqm: number;
  waterVolumeM3: number;
  visualScale: number;
  salePriceMultiplier: number;
  purchaseCostMultiplier: number;
  consumptionMultiplier: number;
  facilityName: string;
  summary: string;
}

export interface PondState {
  id: string;
  name: string;
  areaSqm: number;
  waterVolumeM3: number;
  waterDepthM: number;
  temperatureC: number;
  ph: number;
  dissolvedOxygenMgL: number;
  ammoniaMgL: number;
  nitriteMgL: number;
  leftoverFeedKg: number;
  maxRecommendedFish: number;
  facilityLevel: number;
  facilities: string[];
}

export type RandomEventCategory = 'weather' | 'disease' | 'pollution' | 'market';

export interface RandomEventRecord {
  id: string;
  day: number;
  category: RandomEventCategory;
  title: string;
  description: string;
  severity: 'positive' | 'warning' | 'danger';
}

export interface RiskProbabilities {
  weatherEventPct: number;
  diseaseRiskPct: number;
  pollutionRiskPct: number;
  marketBoomPct: number;
}

export interface FinanceTransaction {
  id: string;
  day: number;
  type: 'income' | 'expense';
  category:
    | '鱼苗采购'
    | '饲料采购'
    | '养殖护理'
    | '设施升级'
    | '鱼类销售'
    | '垂钓收入'
    | '自动售鱼'
    | '日常维护';
  description: string;
  amount: number;
}

export interface DailyLogEntry {
  id: string;
  day: number;
  level: 'info' | 'success' | 'warning' | 'danger';
  message: string;
}

export type AdRewardType = 'auto_care' | 'auto_restock' | 'angler_open' | 'auto_sell';

export interface GameState {
  version: number;
  funds: number;
  day: number;
  weather: WeatherType;
  manorLevel: number;
  totalRevenue: number;
  totalExpense: number;
  totalHarvestedCount: number;
  anglerUnlocked: boolean;
  anglerOpen: boolean;
  autoSellUnlocked: boolean;
  autoSellMature: boolean;
  autoCareUnlocked: boolean;
  autoCareEnabled: boolean;
  autoRestockUnlocked: boolean;
  autoRestockEnabled: boolean;
  isBankrupt: boolean;
  bankruptReason: string | null;
  totalAnglerVisits: number;
  totalAnglerCaught: number;
  totalAnglerRevenue: number;
  diseaseDaysRemaining: number;
  marketBonusDaysRemaining: number;
  marketBonusMultiplier: number;
  lastEvent: RandomEventRecord | null;
  pond: PondState;
  fishes: ManagedFish[];
  feedInventory: Record<FeedTypeId, number>;
  transactions: FinanceTransaction[];
  logs: DailyLogEntry[];
  nextFishSeq: number;
}

export interface ActionFeedback {
  ok: boolean;
  level: 'success' | 'warning' | 'error';
  message: string;
}

export type CameraPresetId = 'isometric' | 'water_close' | 'bridge_view' | 'dock_view';

export interface CameraPreset {
  id: CameraPresetId;
  label: string;
  position: [number, number, number];
  target: [number, number, number];
  zoom: number;
}

export type SceneSelection =
  | { type: 'none' }
  | { type: 'pond' }
  | { type: 'fish'; fish: FishLiveState };
