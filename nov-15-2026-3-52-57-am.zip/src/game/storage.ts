import type { FishSpeciesId, GameState } from '../types/pond';
import { createInitialGameState, getPondTier } from './catalog';

const STORAGE_KEY = 'dreamy_fish_pond_manor_save_v1';
const VALID_SPECIES = new Set<FishSpeciesId>(['grass_carp', 'common_carp', 'tilapia']);

export function loadGameState(): GameState {
  try {
    const raw = globalThis.localStorage.getItem(STORAGE_KEY);
    if (!raw) return createInitialGameState();
    const parsed = JSON.parse(raw) as Partial<GameState>;
    if (
      !parsed ||
      (parsed.version !== 1 && parsed.version !== 2 && parsed.version !== 3) ||
      typeof parsed.funds !== 'number' ||
      typeof parsed.day !== 'number' ||
      !parsed.pond ||
      !Array.isArray(parsed.fishes) ||
      !parsed.feedInventory
    ) {
      return createInitialGameState();
    }

    const defaults = createInitialGameState();
    const tier = getPondTier(parsed.pond.facilityLevel ?? 1);

    // Filter out any legacy ornamental species from older saves
    const filteredFishes = parsed.fishes.filter((f) =>
      VALID_SPECIES.has(f.speciesId as FishSpeciesId),
    );
    const finalFishes = filteredFishes.length > 0 ? filteredFishes : defaults.fishes;

    const savedFeed = parsed.feedInventory as Record<string, number>;
    const standardKg = typeof savedFeed.standard === 'number' ? savedFeed.standard : defaults.feedInventory.standard;
    const highProteinKg =
      typeof savedFeed.high_protein === 'number'
        ? savedFeed.high_protein
        : defaults.feedInventory.high_protein;

    const isV2OrLater = parsed.version >= 2;

    return {
      ...defaults,
      ...parsed,
      version: 3,
      manorLevel: tier.level,
      anglerUnlocked:
        isV2OrLater && typeof parsed.anglerUnlocked === 'boolean' ? parsed.anglerUnlocked : false,
      anglerOpen:
        isV2OrLater && typeof parsed.anglerOpen === 'boolean' && parsed.anglerUnlocked
          ? parsed.anglerOpen
          : false,
      autoSellUnlocked:
        isV2OrLater && typeof parsed.autoSellUnlocked === 'boolean' ? parsed.autoSellUnlocked : false,
      autoSellMature:
        isV2OrLater && typeof parsed.autoSellMature === 'boolean' && parsed.autoSellUnlocked
          ? parsed.autoSellMature
          : false,
      autoCareUnlocked:
        typeof parsed.autoCareUnlocked === 'boolean' ? parsed.autoCareUnlocked : false,
      autoCareEnabled:
        typeof parsed.autoCareEnabled === 'boolean' ? parsed.autoCareEnabled : false,
      autoRestockUnlocked:
        typeof parsed.autoRestockUnlocked === 'boolean' ? parsed.autoRestockUnlocked : false,
      autoRestockEnabled:
        typeof parsed.autoRestockEnabled === 'boolean' ? parsed.autoRestockEnabled : false,
      isBankrupt: typeof parsed.isBankrupt === 'boolean' ? parsed.isBankrupt : false,
      bankruptReason: parsed.bankruptReason ?? null,
      totalAnglerVisits:
        typeof parsed.totalAnglerVisits === 'number' ? parsed.totalAnglerVisits : 0,
      totalAnglerCaught:
        typeof parsed.totalAnglerCaught === 'number' ? parsed.totalAnglerCaught : 0,
      totalAnglerRevenue:
        typeof parsed.totalAnglerRevenue === 'number' ? parsed.totalAnglerRevenue : 0,
      diseaseDaysRemaining:
        typeof parsed.diseaseDaysRemaining === 'number' ? parsed.diseaseDaysRemaining : 0,
      marketBonusDaysRemaining:
        typeof parsed.marketBonusDaysRemaining === 'number' ? parsed.marketBonusDaysRemaining : 0,
      marketBonusMultiplier:
        typeof parsed.marketBonusMultiplier === 'number' ? parsed.marketBonusMultiplier : 1.0,
      lastEvent: parsed.lastEvent ?? null,
      pond: {
        ...defaults.pond,
        ...parsed.pond,
        facilityLevel: tier.level,
        maxRecommendedFish: tier.capacity,
        areaSqm: tier.areaSqm,
        waterVolumeM3: tier.waterVolumeM3,
      },
      fishes: finalFishes,
      feedInventory: {
        standard: standardKg,
        high_protein: highProteinKg,
      },
      transactions: Array.isArray(parsed.transactions) ? parsed.transactions.slice(0, 20) : [],
      logs: Array.isArray(parsed.logs) ? parsed.logs.slice(0, 20) : defaults.logs,
    };
  } catch {
    return createInitialGameState();
  }
}

export function saveGameState(state: GameState): void {
  try {
    globalThis.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Ignore storage quota errors cleanly
  }
}

export function resetGameState(): GameState {
  const fresh = createInitialGameState();
  saveGameState(fresh);
  return fresh;
}
