import type {
  ActionFeedback,
  DailyLogEntry,
  FeedSpec,
  FeedTypeId,
  FinanceTransaction,
  FishQuality,
  FishSpeciesId,
  FishSpeciesSpec,
  GameState,
  GrowthStage,
  ManagedFish,
  PondLevel,
  RandomEventRecord,
  RiskProbabilities,
  WeatherType,
} from '../types/pond';
import {
  FEED_CATALOG,
  FEED_STANDARD_CAPACITY_KG,
  FISH_SPECIES_CATALOG,
  MAX_POND_LEVEL,
  POND_EXPANSION_TIERS,
  WEATHER_MODIFIERS,
  createManagedFishFromSpec,
  getPondTier,
} from './catalog';

const QUALITY_MULTIPLIER: Record<FishQuality, number> = {
  普通: 1.0,
  良种: 1.35,
  精品: 1.85,
  极品: 2.65,
};

function clamp(v: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, v));
}

function round2(v: number): number {
  return Math.round(v * 100) / 100;
}

function makeId(prefix: string): string {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
}

export function getEffectiveSaleMultiplier(state?: GameState): number {
  if (!state) return 1.0;
  const tier = getPondTier(state.pond.facilityLevel);
  const eventMult = state.marketBonusDaysRemaining > 0 ? state.marketBonusMultiplier : 1.0;
  return round2(tier.salePriceMultiplier * eventMult);
}

export function getEffectivePurchaseMultiplier(state?: GameState): number {
  if (!state) return 1.0;
  return getPondTier(state.pond.facilityLevel).purchaseCostMultiplier;
}

export function getEffectiveConsumptionMultiplier(state?: GameState): number {
  if (!state) return 1.0;
  return getPondTier(state.pond.facilityLevel).consumptionMultiplier;
}

export function getEffectiveFryPrice(spec: FishSpeciesSpec, state?: GameState): number {
  return Math.max(1, Math.round(spec.fryPrice * getEffectivePurchaseMultiplier(state)));
}

export function getEffectiveFeedBagPrice(feedSpec: FeedSpec, state?: GameState): number {
  return Math.max(1, Math.round(feedSpec.pricePerBag * getEffectivePurchaseMultiplier(state)));
}

export function getEffectiveCareCost(baseCost: number, state?: GameState): number {
  return Math.max(1, Math.round(baseCost * getEffectivePurchaseMultiplier(state)));
}

export function computeGrowthStage(fish: ManagedFish): GrowthStage {
  const spec = FISH_SPECIES_CATALOG[fish.speciesId];
  const ratio = fish.weightKg / spec.marketWeightKg;
  if (ratio < 0.25) return '鱼苗期';
  if (ratio < 0.6) return '幼鱼期';
  if (ratio < 1.0) return '成长期';
  return '成熟期';
}

export function computeFishScaleFactor(fish: ManagedFish): number {
  const spec = FISH_SPECIES_CATALOG[fish.speciesId];
  const ratio = clamp(fish.weightKg / spec.maxWeightKg, 0.03, 1.0);
  return 0.46 + Math.pow(ratio, 0.42) * 0.68;
}

export function computeEdibleSinglePrice(fish: ManagedFish, state?: GameState): number {
  const spec = FISH_SPECIES_CATALOG[fish.speciesId];
  const healthFactor = 0.72 + (fish.health / 100) * 0.35;
  const qMult = QUALITY_MULTIPLIER[fish.quality];
  const saleMult = getEffectiveSaleMultiplier(state);
  return Math.round(fish.weightKg * spec.marketPricePerKg * healthFactor * qMult * saleMult);
}

export function computeMatureFishPrice(fish: ManagedFish, state?: GameState): number {
  const spec = FISH_SPECIES_CATALOG[fish.speciesId];
  const matureWeight = Math.max(fish.weightKg, spec.marketWeightKg);
  const matureHealth = Math.max(fish.health, 88);
  const saleMult = getEffectiveSaleMultiplier(state);
  const healthFactor = 0.72 + (matureHealth / 100) * 0.35;
  const qMult = QUALITY_MULTIPLIER[fish.quality];
  return Math.round(matureWeight * spec.marketPricePerKg * healthFactor * qMult * saleMult);
}

export function computeRecommendedDailyFeedKg(
  fishes: ManagedFish[],
  facilityLevel = 1,
): number {
  if (fishes.length === 0) return 0;
  const totalBiomass = fishes.reduce((sum, f) => sum + f.weightKg, 0);
  const consMult = getPondTier(facilityLevel).consumptionMultiplier;
  return Math.max(0.1, round2((totalBiomass * 0.032 + fishes.length * 0.04) * consMult));
}

export function getManorTitle(level: number): string {
  return getPondTier(level).name;
}

export function evaluateWaterQualityStatus(state: GameState): {
  label: '优' | '良' | '警戒' | '恶化';
  tone: 'success' | 'info' | 'warning' | 'danger';
  issues: string[];
} {
  const { pond, fishes } = state;
  const issues: string[] = [];

  if (fishes.length > pond.maxRecommendedFish) {
    issues.push(`养殖密度超载 (${fishes.length}/${pond.maxRecommendedFish} 尾)`);
  }
  if (pond.dissolvedOxygenMgL < 5.2) {
    issues.push(`溶氧偏低 (${pond.dissolvedOxygenMgL.toFixed(1)} mg/L)`);
  }
  if (pond.ammoniaMgL > 0.18) {
    issues.push(`氨氮偏高 (${pond.ammoniaMgL.toFixed(2)} mg/L)`);
  }
  if (pond.nitriteMgL > 0.1) {
    issues.push(`亚硝酸盐偏高 (${pond.nitriteMgL.toFixed(2)} mg/L)`);
  }
  if (pond.ph < 6.6 || pond.ph > 8.1) {
    issues.push(`pH 失衡 (${pond.ph.toFixed(1)})`);
  }
  if (pond.leftoverFeedKg > 0.8) {
    issues.push(`池底残饵过多 (${pond.leftoverFeedKg.toFixed(1)} kg)`);
  }
  if (state.diseaseDaysRemaining > 0) {
    issues.push(`鱼病活跃中（剩余 ${state.diseaseDaysRemaining} 天）`);
  }

  if (issues.length >= 3 || pond.dissolvedOxygenMgL < 4.0 || pond.ammoniaMgL > 0.35) {
    return { label: '恶化', tone: 'danger', issues };
  }
  if (issues.length >= 1) {
    return { label: '警戒', tone: 'warning', issues };
  }
  if (
    pond.dissolvedOxygenMgL >= 7.5 &&
    pond.ammoniaMgL <= 0.08 &&
    pond.nitriteMgL <= 0.04 &&
    pond.ph >= 6.8 &&
    pond.ph <= 7.8 &&
    pond.leftoverFeedKg <= 0.3
  ) {
    return { label: '优', tone: 'success', issues: [] };
  }
  return { label: '良', tone: 'info', issues: [] };
}

export function computeEventProbabilities(state: GameState): RiskProbabilities {
  const { pond, fishes } = state;
  const densityRatio = fishes.length / Math.max(1, pond.maxRecommendedFish);
  const facilityMitigation = Math.max(0.45, 1 - (pond.facilityLevel - 1) * 0.15);

  const rawPollution =
    7 +
    (pond.leftoverFeedKg > 0.4 ? pond.leftoverFeedKg * 10 : 0) +
    (densityRatio > 0.85 ? (densityRatio - 0.85) * 28 : 0) +
    (pond.ammoniaMgL > 0.14 ? 8 : 0);
  const pollutionRiskPct = Math.round(clamp(rawPollution * facilityMitigation, 4, 42));

  const rawDisease =
    fishes.length === 0
      ? 0
      : 4 +
        (pond.dissolvedOxygenMgL < 5.6 ? (5.6 - pond.dissolvedOxygenMgL) * 7 : 0) +
        (pond.ammoniaMgL > 0.14 ? (pond.ammoniaMgL - 0.14) * 55 : 0) +
        (pond.nitriteMgL > 0.08 ? (pond.nitriteMgL - 0.08) * 65 : 0) +
        (densityRatio > 0.9 ? 7 : 0);
  const diseaseRiskPct = Math.round(
    clamp(rawDisease * facilityMitigation, fishes.length === 0 ? 0 : 3, 45),
  );

  const weatherEventPct = 15;
  const marketBoomPct = Math.round(clamp(8 + (pond.facilityLevel - 1) * 2.5, 8, 18));

  return {
    weatherEventPct,
    diseaseRiskPct,
    pollutionRiskPct,
    marketBoomPct,
  };
}

function appendLog(
  logs: DailyLogEntry[],
  day: number,
  level: DailyLogEntry['level'],
  message: string,
): DailyLogEntry[] {
  return [{ id: makeId('log'), day, level, message }, ...logs].slice(0, 20);
}

function appendTx(
  txs: FinanceTransaction[],
  day: number,
  type: FinanceTransaction['type'],
  category: FinanceTransaction['category'],
  description: string,
  amount: number,
): FinanceTransaction[] {
  return [{ id: makeId('tx'), day, type, category, description, amount }, ...txs].slice(0, 20);
}

export function checkBankruptcyState(state: GameState): GameState {
  if (state.isBankrupt || state.fishes.length > 0) return state;

  const reason = state.anglerOpen
    ? '鱼塘内已无任何鱼群，钓鱼人纷纷散去，水塘逐渐荒废，水产庄园宣告破产！'
    : '鱼塘内已无任何鱼群，水塘逐渐荒废，水产庄园宣告破产！';

  return {
    ...state,
    anglerOpen: false,
    isBankrupt: true,
    bankruptReason: reason,
    logs: appendLog(state.logs, state.day, 'danger', `破产失败：${reason}`),
  };
}

export function buyFryAndStock(
  state: GameState,
  speciesId: FishSpeciesId,
  quantity: number,
): { nextState: GameState; feedback: ActionFeedback; spawnedFishes: ManagedFish[] } {
  if (state.isBankrupt) {
    return {
      nextState: state,
      feedback: { ok: false, level: 'error', message: '鱼塘已荒废破产，请重新开局。' },
      spawnedFishes: [],
    };
  }

  const qty = Math.floor(quantity);
  if (qty <= 0) {
    return {
      nextState: state,
      feedback: { ok: false, level: 'error', message: '购买数量必须大于 0。' },
      spawnedFishes: [],
    };
  }

  const spec = FISH_SPECIES_CATALOG[speciesId];
  const remainingSlots = state.pond.maxRecommendedFish - state.fishes.length;
  if (qty > remainingSlots) {
    return {
      nextState: state,
      feedback: {
        ok: false,
        level: 'error',
        message: `鱼塘容量不足！当前剩余建议容量仅 ${Math.max(0, remainingSlots)} 尾，无法投放 ${qty} 尾鱼苗。请先扩建鱼塘。`,
      },
      spawnedFishes: [],
    };
  }

  const unitPrice = getEffectiveFryPrice(spec, state);
  const totalCost = unitPrice * qty;
  if (state.funds < totalCost) {
    return {
      nextState: state,
      feedback: {
        ok: false,
        level: 'error',
        message: `资金不足！采购 ${qty} 尾${spec.name}需要 ¥${totalCost}，当前可用资金 ¥${state.funds.toFixed(0)}。`,
      },
      spawnedFishes: [],
    };
  }

  let seq = state.nextFishSeq;
  const spawnedFishes: ManagedFish[] = [];
  for (let i = 0; i < qty; i++) {
    const id = `FISH-${String(seq).padStart(4, '0')}`;
    seq += 1;
    const roll = ((seq * 41 + state.day * 17 + i * 29) % 100) / 100;
    const quality: FishQuality =
      roll >= 0.92 ? '极品' : roll >= 0.76 ? '精品' : roll >= 0.48 ? '良种' : '普通';
    spawnedFishes.push(
      createManagedFishFromSpec(id, speciesId, {
        quality,
        purchasePrice: unitPrice,
        hunger: 18,
        health: 96,
      }),
    );
  }

  const nextState: GameState = {
    ...state,
    funds: round2(state.funds - totalCost),
    totalExpense: round2(state.totalExpense + totalCost),
    fishes: [...state.fishes, ...spawnedFishes],
    nextFishSeq: seq,
    transactions: appendTx(
      state.transactions,
      state.day,
      'expense',
      '鱼苗采购',
      `采购并投放 ${spec.name} 鱼苗 × ${qty}`,
      totalCost,
    ),
    logs: appendLog(
      state.logs,
      state.day,
      'success',
      `购入 ${qty} 尾${spec.name}鱼苗（单价 ¥${unitPrice}）并投放入「${state.pond.name}」，支出 ¥${totalCost}。`,
    ),
  };

  return {
    nextState,
    feedback: {
      ok: true,
      level: 'success',
      message: `已采购并投放 ${qty} 尾${spec.name}至鱼塘（支出 ¥${totalCost}）。`,
    },
    spawnedFishes,
  };
}

export function buyFeed(
  state: GameState,
  feedId: FeedTypeId,
  bags: number,
): { nextState: GameState; feedback: ActionFeedback } {
  if (state.isBankrupt) {
    return {
      nextState: state,
      feedback: { ok: false, level: 'error', message: '鱼塘已荒废破产，请重新开局。' },
    };
  }

  const count = Math.floor(bags);
  if (count <= 0) {
    return {
      nextState: state,
      feedback: { ok: false, level: 'error', message: '购买袋数必须大于 0。' },
    };
  }

  const spec = FEED_CATALOG[feedId];
  const bagPrice = getEffectiveFeedBagPrice(spec, state);
  const cost = bagPrice * count;
  if (state.funds < cost) {
    return {
      nextState: state,
      feedback: {
        ok: false,
        level: 'error',
        message: `资金不足！购买 ${count} 袋${spec.name}需 ¥${cost}，当前资金 ¥${state.funds.toFixed(0)}。`,
      },
    };
  }

  const addedKg = spec.bagWeightKg * count;
  const nextState: GameState = {
    ...state,
    funds: round2(state.funds - cost),
    totalExpense: round2(state.totalExpense + cost),
    feedInventory: {
      ...state.feedInventory,
      [feedId]: round2(state.feedInventory[feedId] + addedKg),
    },
    transactions: appendTx(
      state.transactions,
      state.day,
      'expense',
      '饲料采购',
      `购买 ${spec.name} ${count} 袋 (${addedKg} kg)`,
      cost,
    ),
    logs: appendLog(
      state.logs,
      state.day,
      'info',
      `采购 ${spec.name} ${addedKg} kg（${count} 袋 · ¥${bagPrice}/袋），支出 ¥${cost}。`,
    ),
  };

  return {
    nextState,
    feedback: {
      ok: true,
      level: 'success',
      message: `已购入 ${spec.name} ${addedKg} kg（支出 ¥${cost}）。`,
    },
  };
}

export function feedPond(
  state: GameState,
  feedId: FeedTypeId,
  amountKg: number,
): { nextState: GameState; feedback: ActionFeedback } {
  if (state.fishes.length === 0) {
    return {
      nextState: state,
      feedback: { ok: false, level: 'error', message: '鱼塘中暂无鱼类，无需投喂。' },
    };
  }

  const reqKg = round2(amountKg);
  if (reqKg <= 0) {
    return {
      nextState: state,
      feedback: { ok: false, level: 'error', message: '投喂量必须大于 0。' },
    };
  }

  const stock = state.feedInventory[feedId];
  if (stock < reqKg) {
    return {
      nextState: state,
      feedback: {
        ok: false,
        level: 'error',
        message: `${FEED_CATALOG[feedId].name}库存不足（剩余 ${stock.toFixed(1)} kg），请先在商店补货。`,
      },
    };
  }

  const feedSpec = FEED_CATALOG[feedId];
  const consMult = getEffectiveConsumptionMultiplier(state);
  const recommendedKg = computeRecommendedDailyFeedKg(state.fishes, state.pond.facilityLevel);
  const avgHunger =
    state.fishes.reduce((acc, f) => acc + f.hunger, 0) / Math.max(1, state.fishes.length);

  const appetiteCapacityKg = Math.max(0.25, recommendedKg * (0.45 + (avgHunger / 100) * 0.95));
  const eatenKg = Math.min(reqKg, appetiteCapacityKg);
  const leftoverAdded = Math.max(0, round2(reqKg - eatenKg));
  const overfed = leftoverAdded > 0.15;

  const bagPrice = getEffectiveFeedBagPrice(feedSpec, state);
  const costPerKg = bagPrice / feedSpec.bagWeightKg;
  const totalFeedCost = reqKg * costPerKg;
  const perFishCost = totalFeedCost / state.fishes.length;

  const satiationRatio = clamp(eatenKg / Math.max(0.2, recommendedKg), 0.15, 1.35);

  const updatedFishes = state.fishes.map((fish) => {
    const spec = FISH_SPECIES_CATALOG[fish.speciesId];
    const isPreferred = spec.preferredFeed === feedId;
    const matchBonus = isPreferred ? 1.18 : 0.96;
    const hungerDrop = (32 + 28 * satiationRatio) * matchBonus;
    const nextHunger = round2(clamp(fish.hunger - hungerDrop, 0, 100));

    let nextHealth = fish.health;
    let nextQuality = fish.quality;
    if (feedId === 'high_protein') {
      nextHealth = clamp(nextHealth + 1.4, 0, 100);
      if (fish.health >= 93 && fish.quality === '普通' && (fish.ageDays + state.day) % 4 === 0) {
        nextQuality = '良种';
      } else if (fish.health >= 95 && fish.quality === '良种' && (fish.ageDays + state.day) % 6 === 0) {
        nextQuality = '精品';
      } else if (fish.health >= 97 && fish.quality === '精品' && (fish.ageDays + state.day) % 8 === 0) {
        nextQuality = '极品';
      }
    } else if (isPreferred) {
      nextHealth = clamp(nextHealth + 0.9, 0, 100);
    }

    const microGrowth =
      spec.dailyGrowthKg * 0.16 * feedSpec.growthMultiplier * (isPreferred ? 1.15 : 0.95);
    const nextWeight = round2(Math.min(spec.maxWeightKg, fish.weightKg + microGrowth));
    const lenRatio = Math.pow(nextWeight / spec.maxWeightKg, 0.36);
    const nextLength = round2(
      Math.max(fish.lengthCm, spec.initialLengthCm + (spec.maxLengthCm - spec.initialLengthCm) * lenRatio),
    );

    const updated: ManagedFish = {
      ...fish,
      hunger: nextHunger,
      health: round2(nextHealth),
      quality: nextQuality,
      weightKg: nextWeight,
      lengthCm: nextLength,
      feedCostAccumulated: round2(fish.feedCostAccumulated + perFishCost),
    };
    updated.growthStage = computeGrowthStage(updated);
    return updated;
  });

  const nextLeftover = round2(state.pond.leftoverFeedKg + leftoverAdded * consMult);
  const immediateAmmonia = round2(
    state.pond.ammoniaMgL + leftoverAdded * 0.035 * feedSpec.waterPollutionFactor * consMult,
  );
  const immediateDO = round2(
    clamp(state.pond.dissolvedOxygenMgL - leftoverAdded * 0.25 * consMult, 1.5, 11.0),
  );

  const logMsg = overfed
    ? `投喂 ${feedSpec.name} ${reqKg.toFixed(1)} kg（偏多！产生 ${leftoverAdded.toFixed(1)} kg 残饵，氨氮略升）。`
    : `向鱼塘投喂 ${feedSpec.name} ${reqKg.toFixed(1)} kg，鱼群进食积极。`;

  let nextState: GameState = {
    ...state,
    fishes: updatedFishes,
    feedInventory: {
      ...state.feedInventory,
      [feedId]: round2(stock - reqKg),
    },
    pond: {
      ...state.pond,
      leftoverFeedKg: nextLeftover,
      ammoniaMgL: immediateAmmonia,
      dissolvedOxygenMgL: immediateDO,
    },
    logs: appendLog(state.logs, state.day, overfed ? 'warning' : 'success', logMsg),
  };

  if (nextState.autoSellMature) {
    nextState = settleMatureFishesAutomatically(nextState);
  }
  nextState = checkBankruptcyState(nextState);

  return {
    nextState,
    feedback: {
      ok: true,
      level: overfed ? 'warning' : 'success',
      message: overfed
        ? `已投喂 ${reqKg.toFixed(1)} kg，但超出鱼群摄食量，产生 ${leftoverAdded.toFixed(1)} kg 残饵，注意水质恶化！`
        : `投喂 ${feedSpec.name} ${reqKg.toFixed(1)} kg 成功，鱼群饥饿值已大幅降低。`,
    },
  };
}

export function aeratePond(state: GameState): { nextState: GameState; feedback: ActionFeedback } {
  const cost = getEffectiveCareCost(25, state);
  if (state.funds < cost) {
    return {
      nextState: state,
      feedback: { ok: false, level: 'error', message: `资金不足！开启强力增氧需 ¥${cost}。` },
    };
  }

  const nextDO = round2(clamp(state.pond.dissolvedOxygenMgL + 2.2, 1.5, 10.6));
  const nextAmmonia = round2(Math.max(0.01, state.pond.ammoniaMgL - 0.03));

  const nextState: GameState = {
    ...state,
    funds: round2(state.funds - cost),
    totalExpense: round2(state.totalExpense + cost),
    pond: {
      ...state.pond,
      dissolvedOxygenMgL: nextDO,
      ammoniaMgL: nextAmmonia,
    },
    transactions: appendTx(state.transactions, state.day, 'expense', '养殖护理', '强力水车增氧作业', cost),
    logs: appendLog(
      state.logs,
      state.day,
      'success',
      `开启水车强力增氧（支出 ¥${cost}），溶氧提升至 ${nextDO.toFixed(1)} mg/L。`,
    ),
  };

  return {
    nextState,
    feedback: {
      ok: true,
      level: 'success',
      message: `强力增氧完成！池水溶氧提升至 ${nextDO.toFixed(1)} mg/L。`,
    },
  };
}

export function changePondWater(state: GameState): { nextState: GameState; feedback: ActionFeedback } {
  const cost = getEffectiveCareCost(45, state);
  if (state.funds < cost) {
    return {
      nextState: state,
      feedback: { ok: false, level: 'error', message: `资金不足！生态换水需 ¥${cost}。` },
    };
  }

  const nextAmmonia = round2(Math.max(0.02, state.pond.ammoniaMgL * 0.42));
  const nextNitrite = round2(Math.max(0.01, state.pond.nitriteMgL * 0.45));
  const nextLeftover = round2(state.pond.leftoverFeedKg * 0.25);
  const nextPh = round2(state.pond.ph + (7.3 - state.pond.ph) * 0.65);
  const nextDO = round2(clamp(state.pond.dissolvedOxygenMgL + 0.9, 1.5, 10.6));

  const nextState: GameState = {
    ...state,
    funds: round2(state.funds - cost),
    totalExpense: round2(state.totalExpense + cost),
    pond: {
      ...state.pond,
      ammoniaMgL: nextAmmonia,
      nitriteMgL: nextNitrite,
      leftoverFeedKg: nextLeftover,
      ph: nextPh,
      dissolvedOxygenMgL: nextDO,
    },
    transactions: appendTx(
      state.transactions,
      state.day,
      'expense',
      '养殖护理',
      '山泉活水生态换水 35%',
      cost,
    ),
    logs: appendLog(
      state.logs,
      state.day,
      'success',
      `完成 35% 生态换水（支出 ¥${cost}），氨氮降至 ${nextAmmonia.toFixed(2)} mg/L，pH 回归 ${nextPh.toFixed(1)}。`,
    ),
  };

  return {
    nextState,
    feedback: {
      ok: true,
      level: 'success',
      message: `生态换水完成！氨氮与亚硝酸盐显著下降，水体清澈度恢复。`,
    },
  };
}

export function treatPondDisease(state: GameState): { nextState: GameState; feedback: ActionFeedback } {
  const cost = getEffectiveCareCost(65, state);
  if (state.funds < cost) {
    return {
      nextState: state,
      feedback: { ok: false, level: 'error', message: `资金不足！投放鱼病防治与益生菌制剂需 ¥${cost}。` },
    };
  }

  const healedFishes = state.fishes.map((f) => ({
    ...f,
    health: round2(clamp(f.health + 18, 10, 100)),
  }));
  const nextAmmonia = round2(Math.max(0.02, state.pond.ammoniaMgL - 0.04));

  const nextState: GameState = {
    ...state,
    funds: round2(state.funds - cost),
    totalExpense: round2(state.totalExpense + cost),
    diseaseDaysRemaining: 0,
    fishes: healedFishes,
    pond: {
      ...state.pond,
      ammoniaMgL: nextAmmonia,
    },
    transactions: appendTx(
      state.transactions,
      state.day,
      'expense',
      '养殖护理',
      '生态鱼病防治与益生菌调水',
      cost,
    ),
    logs: appendLog(
      state.logs,
      state.day,
      'success',
      `投放生态益生菌与渔用制剂（支出 ¥${cost}），已控制鱼病风险并提升鱼群健康度！`,
    ),
  };

  return {
    nextState,
    feedback: {
      ok: true,
      level: 'success',
      message: `鱼病防治与益生菌调水完成！全池鱼群健康度恢复，病害风险已消除。`,
    },
  };
}

export function expandPondFacility(state: GameState): { nextState: GameState; feedback: ActionFeedback } {
  if (state.pond.facilityLevel >= MAX_POND_LEVEL) {
    return {
      nextState: state,
      feedback: {
        ok: false,
        level: 'warning',
        message: `鱼塘已扩建至最高等级（Lv.${MAX_POND_LEVEL} 封顶 ${POND_EXPANSION_TIERS[MAX_POND_LEVEL].capacity.toLocaleString('zh-CN')} 尾容量）。`,
      },
    };
  }

  const nextLvl = (state.pond.facilityLevel + 1) as PondLevel;
  const nextTier = POND_EXPANSION_TIERS[nextLvl];
  const upgradeCost = nextTier.upgradeCost;

  if (state.funds < upgradeCost) {
    return {
      nextState: state,
      feedback: {
        ok: false,
        level: 'error',
        message: `资金不足！升级至 Lv.${nextLvl}「${nextTier.name}」需要 ¥${upgradeCost.toLocaleString('zh-CN')}，当前资金 ¥${state.funds.toFixed(0)}。`,
      },
    };
  }

  const nextState: GameState = {
    ...state,
    funds: round2(state.funds - upgradeCost),
    totalExpense: round2(state.totalExpense + upgradeCost),
    manorLevel: nextLvl,
    pond: {
      ...state.pond,
      facilityLevel: nextLvl,
      areaSqm: nextTier.areaSqm,
      waterVolumeM3: nextTier.waterVolumeM3,
      maxRecommendedFish: nextTier.capacity,
      facilities: [...state.pond.facilities, nextTier.facilityName],
    },
    transactions: appendTx(
      state.transactions,
      state.day,
      'expense',
      '设施升级',
      `鱼塘扩建装修至 Lv.${nextLvl}「${nextTier.name}」`,
      upgradeCost,
    ),
    logs: appendLog(
      state.logs,
      state.day,
      'success',
      `鱼塘装修扩建至 Lv.${nextLvl}「${nextTier.name}」（支出 ¥${upgradeCost.toLocaleString('zh-CN')}）！${nextTier.summary}`,
    ),
  };

  return {
    nextState,
    feedback: {
      ok: true,
      level: 'success',
      message: `装修扩建完成！庄园已升至 Lv.${nextLvl}「${nextTier.name}」：${nextTier.summary}`,
    },
  };
}

/**
 * 看广告解锁 & 切换「钓鱼人免费入场」
 */
export function activateAnglerFromAd(state: GameState): {
  nextState: GameState;
  feedback: ActionFeedback;
} {
  if (state.isBankrupt) {
    return {
      nextState: state,
      feedback: { ok: false, level: 'error', message: '鱼塘已荒废破产，请重开庄园。' },
    };
  }
  const nextState: GameState = {
    ...state,
    anglerUnlocked: true,
    anglerOpen: true,
    logs: appendLog(
      state.logs,
      state.day,
      'success',
      '观看激励短片成功：已解锁并开放「钓鱼人免费入场」！钓鱼客将免费进场垂钓，钓起的鱼按成熟鱼价自动售出。',
    ),
  };
  return {
    nextState,
    feedback: {
      ok: true,
      level: 'success',
      message: '已解锁并开放「钓鱼人免费入场」！钓鱼客已来到岸边垂钓。',
    },
  };
}

export function toggleAnglerOpen(state: GameState): { nextState: GameState; feedback: ActionFeedback } {
  if (state.isBankrupt) {
    return {
      nextState: state,
      feedback: { ok: false, level: 'error', message: '鱼塘已荒废破产，无法开放垂钓。' },
    };
  }
  if (!state.anglerUnlocked) {
    return {
      nextState: state,
      feedback: { ok: false, level: 'warning', message: '请先观看短片广告解锁钓鱼人免费入场。' },
    };
  }
  const nextOpen = !state.anglerOpen;
  const nextState: GameState = {
    ...state,
    anglerOpen: nextOpen,
    logs: appendLog(
      state.logs,
      state.day,
      'info',
      nextOpen
        ? '已开放「钓鱼人免费入场」！钓鱼客将免费进场垂钓，钓起的鱼按成熟鱼价自动结算入账。'
        : '已暂停钓鱼人入场，鱼塘转为闭园精养模式。',
    ),
  };

  return {
    nextState,
    feedback: {
      ok: true,
      level: 'success',
      message: nextOpen
        ? '已开放钓鱼人免费入场！钓获鱼类将按成熟鱼价自动售出。'
        : '已关闭钓鱼人入场。',
    },
  };
}

/**
 * 看广告解锁 & 切换「成熟鱼自动售出」
 */
export function activateAutoSellFromAd(state: GameState): {
  nextState: GameState;
  feedback: ActionFeedback;
} {
  let nextState: GameState = {
    ...state,
    autoSellUnlocked: true,
    autoSellMature: true,
    logs: appendLog(
      state.logs,
      state.day,
      'success',
      '观看激励短片成功：已解锁并开启「成熟鱼自动售出」！普通/良种成熟鱼达标即自动结算，精品/极品留池供高价单条出售。',
    ),
  };
  nextState = settleMatureFishesAutomatically(nextState);
  nextState = checkBankruptcyState(nextState);
  return {
    nextState,
    feedback: {
      ok: true,
      level: 'success',
      message: '已解锁并开启「成熟鱼自动售出」，普通与良种成熟鱼将自动出栏售出！',
    },
  };
}

export function toggleAutoSellMature(state: GameState): {
  nextState: GameState;
  feedback: ActionFeedback;
} {
  if (!state.autoSellUnlocked) {
    return {
      nextState: state,
      feedback: { ok: false, level: 'warning', message: '请先观看短片广告解锁成熟鱼自动售出。' },
    };
  }
  const nextVal = !state.autoSellMature;
  let nextState: GameState = { ...state, autoSellMature: nextVal };
  if (nextVal) {
    nextState = settleMatureFishesAutomatically(nextState);
    nextState = checkBankruptcyState(nextState);
  }
  return {
    nextState,
    feedback: {
      ok: true,
      level: 'success',
      message: nextVal ? '已开启成熟鱼自动售出。' : '已暂停成熟鱼自动售出。',
    },
  };
}

/**
 * 自动投喂与水质护理单步执行：
 * 一旦任意水质或健康/饥饿指标接近警戒或低于「优」标准，立即自动处理，保持所有数值达到优质。
 */
export function runAutoCareStep(state: GameState): GameState {
  if (state.isBankrupt || state.fishes.length === 0) return state;
  let curr = state;

  // 1. 鱼病与健康维护（保持健康优秀）
  const minHealth = curr.fishes.reduce((min, f) => Math.min(min, f.health), 100);
  if ((curr.diseaseDaysRemaining > 0 || minHealth < 88) && curr.funds >= getEffectiveCareCost(65, curr)) {
    curr = treatPondDisease(curr).nextState;
  }

  // 2. 氨氮、亚硝酸盐、pH、池底残饵保持在「优」阈值内
  let waterLoops = 0;
  while (
    waterLoops < 3 &&
    (curr.pond.ammoniaMgL > 0.08 ||
      curr.pond.nitriteMgL > 0.04 ||
      curr.pond.ph < 6.8 ||
      curr.pond.ph > 7.8 ||
      curr.pond.leftoverFeedKg > 0.3) &&
    curr.funds >= getEffectiveCareCost(45, curr)
  ) {
    curr = changePondWater(curr).nextState;
    waterLoops++;
  }

  // 3. 溶氧保持在「优」阈值（>= 7.5 mg/L）
  let aerateLoops = 0;
  while (
    aerateLoops < 3 &&
    curr.pond.dissolvedOxygenMgL < 7.5 &&
    curr.funds >= getEffectiveCareCost(25, curr)
  ) {
    curr = aeratePond(curr).nextState;
    aerateLoops++;
  }

  // 4. 精准自动投喂（保持饱腹且不产生残饵）
  const avgHunger =
    curr.fishes.reduce((acc, f) => acc + f.hunger, 0) / Math.max(1, curr.fishes.length);
  if (avgHunger >= 26) {
    const recKg = computeRecommendedDailyFeedKg(curr.fishes, curr.pond.facilityLevel);
    const appetiteCapKg = Math.max(0.1, round2(recKg * (0.45 + (avgHunger / 100) * 0.9)));
    const safeFeedTarget = Math.min(recKg, appetiteCapKg);
    const prefOrder: FeedTypeId[] = ['high_protein', 'standard'];

    for (const fId of prefOrder) {
      const avail = curr.feedInventory[fId];
      if (avail >= 0.1) {
        const feedAmt = round2(Math.min(avail, safeFeedTarget));
        curr = feedPond(curr, fId, feedAmt).nextState;
        break;
      }
    }
  }

  return curr;
}

/**
 * 自动买鱼苗与鱼饲料单步执行：
 * - 鱼饲料库存未过半（< 10 kg）时自动购买补足
 * - 鱼塘鱼数未过半（< maxRecommendedFish / 2，如 80 尾只有 39 尾时）必须自动购买鱼苗
 */
export function runAutoRestockStep(state: GameState): GameState {
  if (state.isBankrupt) return state;
  let curr = state;

  // 1. 饲料库存未过半自动购买（标准仓容 20kg，未过半即 < 10kg）
  const feedHalfKg = FEED_STANDARD_CAPACITY_KG / 2;
  const feedPriority: FeedTypeId[] = ['standard', 'high_protein'];
  for (const fId of feedPriority) {
    while (curr.feedInventory[fId] < feedHalfKg) {
      const bagCost = getEffectiveFeedBagPrice(FEED_CATALOG[fId], curr);
      if (curr.funds < bagCost) break;
      const before = curr.feedInventory[fId];
      curr = buyFeed(curr, fId, 1).nextState;
      if (curr.feedInventory[fId] <= before) break;
    }
  }

  // 2. 鱼塘数量未过半必须自动购买鱼苗（如 2 级 100 尾只有 49 尾时 < 50 立即触发）
  const fishHalfThreshold = Math.floor(curr.pond.maxRecommendedFish / 2);
  if (curr.fishes.length < fishHalfThreshold) {
    const targetCount = Math.min(curr.pond.maxRecommendedFish, fishHalfThreshold + 4);
    const speciesRotation: FishSpeciesId[] = ['grass_carp', 'tilapia', 'common_carp'];
    let rotIdx = 0;

    while (curr.fishes.length < targetCount && rotIdx < 72) {
      const freeSlots = curr.pond.maxRecommendedFish - curr.fishes.length;
      if (freeSlots <= 0) break;

      const spId = speciesRotation[rotIdx % speciesRotation.length];
      rotIdx++;
      const unitPrice = getEffectiveFryPrice(FISH_SPECIES_CATALOG[spId], curr);
      const needed = targetCount - curr.fishes.length;
      const maxAffordable = Math.floor(curr.funds / unitPrice);
      const buyQty = Math.min(needed, freeSlots, maxAffordable, 100);

      if (buyQty >= 1) {
        curr = buyFryAndStock(curr, spId, buyQty).nextState;
      } else {
        const cheapest = FISH_SPECIES_CATALOG.grass_carp;
        const cheapPrice = getEffectiveFryPrice(cheapest, curr);
        const cheapQty = Math.min(needed, freeSlots, Math.floor(curr.funds / cheapPrice), 100);
        if (cheapQty >= 1) {
          curr = buyFryAndStock(curr, 'grass_carp', cheapQty).nextState;
        } else {
          break;
        }
      }
    }
  }

  return curr;
}

export function activateAutoCareFromAd(state: GameState): {
  nextState: GameState;
  feedback: ActionFeedback;
} {
  let nextState: GameState = {
    ...state,
    autoCareUnlocked: true,
    autoCareEnabled: true,
    logs: appendLog(
      state.logs,
      state.day,
      'success',
      '观看激励短片成功：已解锁并开启「自动投喂护理管家」！随时将水质、溶氧、氨氮与饥饿维护至优质水平。',
    ),
  };
  nextState = runAutoCareStep(nextState);
  return {
    nextState,
    feedback: {
      ok: true,
      level: 'success',
      message: '已解锁并启动「自动投喂护理」，庄园管家已将水质与鱼群养护至优质状态！',
    },
  };
}

export function toggleAutoCareEnabled(state: GameState): {
  nextState: GameState;
  feedback: ActionFeedback;
} {
  if (!state.autoCareUnlocked) {
    return {
      nextState: state,
      feedback: { ok: false, level: 'warning', message: '请先观看短片广告解锁自动投喂护理。' },
    };
  }
  const nextVal = !state.autoCareEnabled;
  let nextState: GameState = { ...state, autoCareEnabled: nextVal };
  if (nextVal) nextState = runAutoCareStep(nextState);
  return {
    nextState,
    feedback: {
      ok: true,
      level: 'success',
      message: nextVal ? '已开启自动投喂护理。' : '已暂停自动投喂护理。',
    },
  };
}

export function activateAutoRestockFromAd(state: GameState): {
  nextState: GameState;
  feedback: ActionFeedback;
} {
  let nextState: GameState = {
    ...state,
    autoRestockUnlocked: true,
    autoRestockEnabled: true,
    logs: appendLog(
      state.logs,
      state.day,
      'success',
      '观看激励短片成功：已解锁并开启「自动买鱼苗与鱼饲料」！鱼数或饲料未过半时将自动补购。',
    ),
  };
  nextState = runAutoRestockStep(nextState);
  return {
    nextState,
    feedback: {
      ok: true,
      level: 'success',
      message: '已解锁并启动「自动买鱼苗与鱼饲料」，未过半项目已自动补货！',
    },
  };
}

export function toggleAutoRestockEnabled(state: GameState): {
  nextState: GameState;
  feedback: ActionFeedback;
} {
  if (!state.autoRestockUnlocked) {
    return {
      nextState: state,
      feedback: { ok: false, level: 'warning', message: '请先观看短片广告解锁自动买鱼苗与鱼饲料。' },
    };
  }
  const nextVal = !state.autoRestockEnabled;
  let nextState: GameState = { ...state, autoRestockEnabled: nextVal };
  if (nextVal) nextState = runAutoRestockStep(nextState);
  return {
    nextState,
    feedback: {
      ok: true,
      level: 'success',
      message: nextVal ? '已开启自动买鱼苗与鱼饲料。' : '已暂停自动买鱼苗与鱼饲料。',
    },
  };
}

export function breedFishPair(
  state: GameState,
  speciesId: FishSpeciesId,
): { nextState: GameState; feedback: ActionFeedback; spawnedFishes: ManagedFish[] } {
  const breedCount = 2;
  const freeSlots = state.pond.maxRecommendedFish - state.fishes.length;
  if (freeSlots < breedCount) {
    return {
      nextState: state,
      feedback: {
        ok: false,
        level: 'error',
        message: `鱼塘剩余容量不足 ${breedCount} 尾，无法进行繁育。请先扩建鱼塘。`,
      },
      spawnedFishes: [],
    };
  }

  const matureParents = state.fishes.filter(
    (f) => f.speciesId === speciesId && f.growthStage === '成熟期' && f.health >= 70,
  );
  if (matureParents.length < 2) {
    return {
      nextState: state,
      feedback: {
        ok: false,
        level: 'error',
        message: `需要至少 2 尾同品种且健康度 ≥ 70 的成熟期亲鱼才可进行生态繁育。`,
      },
      spawnedFishes: [],
    };
  }

  const careFee = getEffectiveCareCost(60, state);
  if (state.funds < careFee) {
    return {
      nextState: state,
      feedback: { ok: false, level: 'error', message: `资金不足！繁育育苗护理费需 ¥${careFee}。` },
      spawnedFishes: [],
    };
  }

  let seq = state.nextFishSeq;
  const spec = FISH_SPECIES_CATALOG[speciesId];
  const spawnedFishes: ManagedFish[] = [];
  for (let i = 0; i < breedCount; i++) {
    const id = `FISH-${String(seq).padStart(4, '0')}`;
    seq += 1;
    spawnedFishes.push(
      createManagedFishFromSpec(id, speciesId, {
        quality: i === 0 ? '极品' : '精品',
        purchasePrice: 0,
        feedCostAccumulated: careFee / breedCount,
      }),
    );
  }

  const nextState: GameState = {
    ...state,
    funds: round2(state.funds - careFee),
    totalExpense: round2(state.totalExpense + careFee),
    fishes: [...state.fishes, ...spawnedFishes],
    nextFishSeq: seq,
    transactions: appendTx(
      state.transactions,
      state.day,
      'expense',
      '养殖护理',
      `${spec.name}亲鱼生态繁育育苗 × ${breedCount}`,
      careFee,
    ),
    logs: appendLog(
      state.logs,
      state.day,
      'success',
      `${spec.name}亲鱼繁育成功！新增极品/精品子代鱼苗 ${breedCount} 尾游入池中。`,
    ),
  };

  return {
    nextState,
    feedback: {
      ok: true,
      level: 'success',
      message: `${spec.name}生态繁育成功！获得 ${breedCount} 尾极品/精品幼苗。`,
    },
    spawnedFishes,
  };
}

export function sellSingleFish(
  state: GameState,
  fishId: string,
): { nextState: GameState; feedback: ActionFeedback } {
  const fish = state.fishes.find((f) => f.id === fishId);
  if (!fish) {
    return {
      nextState: state,
      feedback: { ok: false, level: 'error', message: '未找到该条鱼的数据。' },
    };
  }

  const price = computeEdibleSinglePrice(fish, state);
  const cost = round2(fish.purchasePrice + fish.feedCostAccumulated);
  const profit = round2(price - cost);

  const nextRevenue = round2(state.totalRevenue + price);
  const nextHarvestCount = state.totalHarvestedCount + 1;

  let nextState: GameState = {
    ...state,
    funds: round2(state.funds + price),
    totalRevenue: nextRevenue,
    totalHarvestedCount: nextHarvestCount,
    manorLevel: state.pond.facilityLevel,
    fishes: state.fishes.filter((f) => f.id !== fishId),
    transactions: appendTx(
      state.transactions,
      state.day,
      'income',
      '鱼类销售',
      `精选出售 ${fish.name}（${fish.quality} · ${fish.weightKg.toFixed(2)} kg）`,
      price,
    ),
    logs: appendLog(
      state.logs,
      state.day,
      'success',
      `精选出售「${fish.name}」(${fish.quality}) 获得 ¥${price}（养殖成本 ¥${cost.toFixed(0)}，净利 ¥${profit.toFixed(0)}）。`,
    ),
  };

  nextState = checkBankruptcyState(nextState);

  return {
    nextState,
    feedback: {
      ok: true,
      level: nextState.isBankrupt ? 'warning' : 'success',
      message: nextState.isBankrupt
        ? `已出售「${fish.name}」获得 ¥${price}，但鱼塘已无鱼群而荒废破产！`
        : `已高价售出「${fish.name}」，获得收入 ¥${price}（净利 ¥${profit.toFixed(0)}）！`,
    },
  };
}

/**
 * 成熟鱼自动售出：自动按实时市价售出「普通」「良种」成熟鱼；
 * 「精品」「极品」成熟鱼保留至「售鱼行情」精选出售区。
 */
export function settleMatureFishesAutomatically(state: GameState): GameState {
  const matureFishes = state.fishes.filter((f) => {
    const spec = FISH_SPECIES_CATALOG[f.speciesId];
    const isMature = f.growthStage === '成熟期' || f.weightKg >= spec.marketWeightKg;
    const isPrized = f.quality === '精品' || f.quality === '极品';
    return isMature && !isPrized;
  });

  if (matureFishes.length === 0) return state;

  const soldIds = new Set(matureFishes.map((f) => f.id));
  const totalProceeds = matureFishes.reduce((sum, f) => sum + computeEdibleSinglePrice(f, state), 0);

  const nextRevenue = round2(state.totalRevenue + totalProceeds);
  const nextHarvestCount = state.totalHarvestedCount + matureFishes.length;

  return {
    ...state,
    funds: round2(state.funds + totalProceeds),
    totalRevenue: nextRevenue,
    totalHarvestedCount: nextHarvestCount,
    manorLevel: state.pond.facilityLevel,
    fishes: state.fishes.filter((f) => !soldIds.has(f.id)),
    transactions: appendTx(
      state.transactions,
      state.day,
      'income',
      '自动售鱼',
      `成熟常规鱼自动售出 × ${matureFishes.length}`,
      totalProceeds,
    ),
    logs: appendLog(
      state.logs,
      state.day,
      'success',
      `自动售鱼：${matureFishes.length} 尾普通/良种成熟鱼已自动售出，结算收入 ¥${totalProceeds}（精品/极品已保留至售鱼行情）。`,
    ),
  };
}

function pickNextWeather(day: number, current: WeatherType): WeatherType {
  const list: WeatherType[] = ['晴朗微风', '多云舒爽', '阵雨充氧', '闷热低压'];
  const idx = (day * 5 + list.indexOf(current) * 3 + 1) % 11;
  if (idx <= 3) return '晴朗微风';
  if (idx <= 6) return '多云舒爽';
  if (idx <= 8) return '阵雨充氧';
  return '闷热低压';
}

export function advanceOneDay(state: GameState, rng: () => number = Math.random): GameState {
  if (state.isBankrupt) return state;

  const nextDay = state.day + 1;
  let nextWeather = pickNextWeather(nextDay, state.weather);
  const wMod = WEATHER_MODIFIERS[nextWeather];

  const { pond, fishes } = state;
  const consMult = getEffectiveConsumptionMultiplier(state);
  const totalBiomass = fishes.reduce((sum, f) => sum + f.weightKg, 0);
  const overcrowdCount = Math.max(0, fishes.length - pond.maxRecommendedFish);

  // 1. Roll daily random events
  const probs = computeEventProbabilities(state);
  const roll = rng() * 100;
  let triggeredEvent: RandomEventRecord | null = null;

  let eventTempDelta = 0;
  let eventDODelta = 0;
  let eventAmmoniaDelta = 0;
  let eventNitriteDelta = 0;
  let eventPhDelta = 0;
  let nextDiseaseDays = Math.max(0, state.diseaseDaysRemaining - 1);
  let nextMarketDays = Math.max(0, state.marketBonusDaysRemaining - 1);
  let nextMarketMult = nextMarketDays > 0 ? state.marketBonusMultiplier : 1.0;

  if (roll < probs.pollutionRiskPct) {
    const isAlgae = rng() < 0.5;
    if (isAlgae) {
      eventDODelta = -1.35 * consMult;
      eventPhDelta = 0.42;
      eventAmmoniaDelta = 0.06 * consMult;
      triggeredEvent = {
        id: makeId('evt'),
        day: nextDay,
        category: 'pollution',
        title: '藻类水华污染预警',
        description: '池水藻类突发性繁殖消耗溶氧并拉升碱度，请及时换水或增氧。',
        severity: 'danger',
      };
    } else {
      eventAmmoniaDelta = 0.09 * consMult;
      eventNitriteDelta = 0.05 * consMult;
      eventDODelta = -0.95 * consMult;
      triggeredEvent = {
        id: makeId('evt'),
        day: nextDay,
        category: 'pollution',
        title: '上游农田径流微污染',
        description: '外部径流渗入导致氨氮与亚硝酸盐陡升，请尽快生态换水！',
        severity: 'danger',
      };
    }
  } else if (roll < probs.pollutionRiskPct + probs.diseaseRiskPct && fishes.length > 0) {
    nextDiseaseDays = Math.max(nextDiseaseDays, 2);
    triggeredEvent = {
      id: makeId('evt'),
      day: nextDay,
      category: 'disease',
      title: '鱼群暴发鳃霉/寄生虫风险',
      description: '受水温与水体微生物波动影响，鱼群未来 2 天健康度将持续受损，请在护理面板投放鱼病防治制剂！',
      severity: 'danger',
    };
  } else if (roll < probs.pollutionRiskPct + probs.diseaseRiskPct + probs.weatherEventPct) {
    const kind = rng();
    if (kind < 0.36) {
      nextWeather = '阵雨充氧';
      eventTempDelta = -2.1;
      eventDODelta = 1.1;
      triggeredEvent = {
        id: makeId('evt'),
        day: nextDay,
        category: 'weather',
        title: '突发清凉阵雨',
        description: '阵雨携带天然活水降温并大幅提高水面溶氧交换。',
        severity: 'positive',
      };
    } else if (kind < 0.72) {
      nextWeather = '闷热低压';
      eventTempDelta = 2.6;
      eventDODelta = -1.25 * consMult;
      triggeredEvent = {
        id: makeId('evt'),
        day: nextDay,
        category: 'weather',
        title: '突发高温闷热低压',
        description: '气压骤降导致水温偏高且溶氧流失加快，注意开启水车增氧。',
        severity: 'warning',
      };
    } else {
      nextWeather = '晴朗微风';
      eventDODelta = 0.75;
      eventAmmoniaDelta = -0.03;
      triggeredEvent = {
        id: makeId('evt'),
        day: nextDay,
        category: 'weather',
        title: '山涧丰沛活水入塘',
        description: '山泉流量充沛，池水天然溶氧提升且氨氮自然稀释。',
        severity: 'positive',
      };
    }
  } else if (
    roll <
    probs.pollutionRiskPct + probs.diseaseRiskPct + probs.weatherEventPct + probs.marketBoomPct
  ) {
    nextMarketDays = 2;
    nextMarketMult = 1.18;
    triggeredEvent = {
      id: makeId('evt'),
      day: nextDay,
      category: 'market',
      title: '水产美食节行情走高',
      description: '周边客商集中采购，接下来 2 天全池鱼类销售价格额外 +18%！',
      severity: 'positive',
    };
  }

  // 2. Water temperature & chemistry
  const nextTemp = round2(
    clamp(pond.temperatureC + (wMod.tempTarget - pond.temperatureC) * 0.45 + eventTempDelta, 14, 32),
  );
  const facilityPurify = 1 + (pond.facilityLevel - 1) * 0.25;
  const bioOxygenDemand =
    (totalBiomass * 0.036 + fishes.length * 0.02 + pond.leftoverFeedKg * 0.38) * consMult;
  const aeratorRecovery = 0.72 + (pond.facilityLevel - 1) * 0.28 + wMod.oxygenDelta;
  const nextDO = round2(
    clamp(
      pond.dissolvedOxygenMgL +
        aeratorRecovery -
        bioOxygenDemand -
        overcrowdCount * 0.14 * consMult +
        eventDODelta,
      1.8,
      10.6,
    ),
  );

  const leftoverDecay = round2(pond.leftoverFeedKg * 0.55);
  const nextLeftover = round2(Math.max(0, pond.leftoverFeedKg - leftoverDecay));
  const ammoniaAdded =
    ((totalBiomass * 0.0022 + leftoverDecay * 0.085 + overcrowdCount * 0.012) * consMult) /
    facilityPurify;
  const ammoniaProcessed = pond.ammoniaMgL * (0.28 * facilityPurify);
  const nextAmmonia = round2(
    clamp(pond.ammoniaMgL + ammoniaAdded - ammoniaProcessed + eventAmmoniaDelta, 0.01, 0.85),
  );

  const nitriteAdded = ammoniaProcessed * 0.62;
  const nitriteProcessed = pond.nitriteMgL * (0.34 * facilityPurify);
  const nextNitrite = round2(
    clamp(pond.nitriteMgL + nitriteAdded - nitriteProcessed + eventNitriteDelta, 0.01, 0.55),
  );

  const phDrift =
    -leftoverDecay * 0.08 * consMult -
    (nextAmmonia > 0.18 ? 0.06 : 0) +
    (7.3 - pond.ph) * 0.18 +
    eventPhDelta;
  const nextPh = round2(clamp(pond.ph + phDrift, 6.0, 8.6));

  // 3. Growth & health
  const tempDiff = Math.abs(nextTemp - 23.0);
  const tempFactor = clamp(1.05 - tempDiff * 0.045, 0.55, 1.08);

  let waterStress = 0;
  if (nextDO < 5.0) waterStress += (5.0 - nextDO) * 2.8;
  if (nextAmmonia > 0.16) waterStress += (nextAmmonia - 0.16) * 35;
  if (nextNitrite > 0.09) waterStress += (nextNitrite - 0.09) * 40;
  if (nextPh < 6.6 || nextPh > 8.1) waterStress += 2.5;
  if (overcrowdCount > 0) waterStress += overcrowdCount * 1.4;
  if (nextDiseaseDays > 0) waterStress += 6.5;

  let newlyMatured = 0;
  let starvingCount = 0;

  const nextFishes: ManagedFish[] = fishes.map((fish) => {
    const spec = FISH_SPECIES_CATALOG[fish.speciesId];

    const hungerGain = (24 + clamp(fish.weightKg * 3.5, 2, 16)) * consMult;
    const nextHunger = round2(clamp(fish.hunger + hungerGain, 0, 100));
    if (nextHunger >= 75) starvingCount++;

    let healthDelta = waterStress > 0 ? -waterStress : 2.2;
    if (nextHunger >= 80) healthDelta -= 4.5 * consMult;
    else if (nextHunger >= 60) healthDelta -= 1.2 * consMult;
    else if (nextHunger <= 35 && waterStress === 0) healthDelta += 1.4;

    const nextHealth = round2(clamp(fish.health + healthDelta, 10, 100));

    const nutritionFactor =
      fish.hunger <= 35 ? 1.05 : fish.hunger <= 65 ? 0.72 : 0.25;
    const healthGrowthFactor = clamp(nextHealth / 100, 0.25, 1.05);
    const qualityWaterFactor = waterStress > 4 ? 0.55 : waterStress > 0 ? 0.8 : 1.0;

    const dailyGain =
      spec.dailyGrowthKg *
      tempFactor *
      nutritionFactor *
      healthGrowthFactor *
      qualityWaterFactor;

    const nextWeight = round2(Math.min(spec.maxWeightKg, fish.weightKg + dailyGain));
    const lenProgress = Math.pow(nextWeight / spec.maxWeightKg, 0.36);
    const nextLength = round2(
      Math.max(
        fish.lengthCm,
        spec.initialLengthCm + (spec.maxLengthCm - spec.initialLengthCm) * lenProgress,
      ),
    );

    const prevStage = fish.growthStage;
    const updated: ManagedFish = {
      ...fish,
      ageDays: fish.ageDays + 1,
      hunger: nextHunger,
      health: nextHealth,
      weightKg: nextWeight,
      lengthCm: nextLength,
    };
    updated.growthStage = computeGrowthStage(updated);
    if (prevStage !== '成熟期' && updated.growthStage === '成熟期') {
      newlyMatured++;
    }
    return updated;
  });

  const upkeep = Math.max(1, Math.round(12 * consMult));
  const nextFunds = round2(Math.max(0, state.funds - upkeep));
  const actualUpkeep = round2(state.funds - nextFunds);

  let nextLogs = state.logs;
  let nextTxs = state.transactions;

  if (actualUpkeep > 0) {
    nextTxs = appendTx(nextTxs, nextDay, 'expense', '日常维护', `第 ${nextDay} 天水泵与增氧电费`, actualUpkeep);
  }

  const avgWeight =
    nextFishes.length > 0
      ? nextFishes.reduce((s, f) => s + f.weightKg, 0) / nextFishes.length
      : 0;

  nextLogs = appendLog(
    nextLogs,
    nextDay,
    'info',
    `第 ${nextDay} 天（${nextWeather} ${nextTemp.toFixed(1)}°C）：在池 ${nextFishes.length} 尾，平均体重 ${avgWeight.toFixed(2)} kg，溶氧 ${nextDO.toFixed(1)} mg/L。`,
  );

  if (triggeredEvent) {
    nextLogs = appendLog(
      nextLogs,
      nextDay,
      triggeredEvent.severity === 'danger'
        ? 'danger'
        : triggeredEvent.severity === 'warning'
          ? 'warning'
          : 'success',
      `随机事件【${triggeredEvent.title}】：${triggeredEvent.description}`,
    );
  }

  if (newlyMatured > 0) {
    nextLogs = appendLog(
      nextLogs,
      nextDay,
      'success',
      `喜报：今日有 ${newlyMatured} 尾鱼进入成熟期！`,
    );
  }
  if (starvingCount > 0 && !state.autoCareEnabled) {
    nextLogs = appendLog(
      nextLogs,
      nextDay,
      'warning',
      `提醒：有 ${starvingCount} 尾鱼饥饿值较高（≥75），请及时投喂以免影响生长与健康。`,
    );
  }
  if (waterStress > 2.5 && !state.autoCareEnabled) {
    nextLogs = appendLog(
      nextLogs,
      nextDay,
      'danger',
      `水质警报：当前溶氧 ${nextDO.toFixed(1)} mg/L、氨氮 ${nextAmmonia.toFixed(2)} mg/L，请尽快增氧、换水或防治鱼病！`,
    );
  }

  let nextState: GameState = {
    ...state,
    day: nextDay,
    weather: nextWeather,
    funds: nextFunds,
    totalExpense: round2(state.totalExpense + actualUpkeep),
    diseaseDaysRemaining: nextDiseaseDays,
    marketBonusDaysRemaining: nextMarketDays,
    marketBonusMultiplier: nextMarketMult,
    lastEvent: triggeredEvent ?? state.lastEvent,
    pond: {
      ...pond,
      temperatureC: nextTemp,
      dissolvedOxygenMgL: nextDO,
      ammoniaMgL: nextAmmonia,
      nitriteMgL: nextNitrite,
      ph: nextPh,
      leftoverFeedKg: nextLeftover,
    },
    fishes: nextFishes,
    transactions: nextTxs,
    logs: nextLogs,
  };

  // 4. Ad-unlocked Auto Restock before feeding so feed is topped up if < half
  if (nextState.autoRestockEnabled) {
    nextState = runAutoRestockStep(nextState);
  }

  // 5. Ad-unlocked Auto Care: keeps all water & fish parameters in 优质
  if (nextState.autoCareEnabled) {
    nextState = runAutoCareStep(nextState);
  }

  // 6. Ad-unlocked Auto Sell Mature (ordinary & good mature fishes; keeps 精品/极品 for appraisal)
  if (nextState.autoSellMature) {
    nextState = settleMatureFishesAutomatically(nextState);
  }

  // 7. Ad-unlocked Free Angler visits
  if (nextState.anglerOpen && nextState.fishes.length > 0) {
    const visitors = Math.min(4, 1 + Math.floor(pond.facilityLevel * 0.8));
    const maxCatch = Math.min(visitors, nextState.fishes.length);
    const catchCount =
      nextState.fishes.length <= 4
        ? rng() < 0.45
          ? 1
          : 0
        : Math.max(1, Math.min(maxCatch, Math.floor(nextState.fishes.length * 0.15)));

    const sortedForHook = [...nextState.fishes].sort((a, b) => b.weightKg - a.weightKg);
    const hooked = sortedForHook.slice(0, catchCount);
    const hookedIds = new Set(hooked.map((f) => f.id));

    const anglerIncome = hooked.reduce((sum, f) => sum + computeMatureFishPrice(f, nextState), 0);
    const nextRevenue = round2(nextState.totalRevenue + anglerIncome);
    const nextHarvested = nextState.totalHarvestedCount + hooked.length;

    nextState = {
      ...nextState,
      funds: round2(nextState.funds + anglerIncome),
      totalRevenue: nextRevenue,
      totalHarvestedCount: nextHarvested,
      manorLevel: nextState.pond.facilityLevel,
      totalAnglerVisits: nextState.totalAnglerVisits + visitors,
      totalAnglerCaught: nextState.totalAnglerCaught + hooked.length,
      totalAnglerRevenue: round2(nextState.totalAnglerRevenue + anglerIncome),
      fishes: nextState.fishes.filter((f) => !hookedIds.has(f.id)),
      transactions:
        hooked.length > 0
          ? appendTx(
              nextState.transactions,
              nextDay,
              'income',
              '垂钓收入',
              `免费钓鱼客 (${visitors}人) 钓获 ${hooked.length} 尾（按成熟鱼价结算）`,
              anglerIncome,
            )
          : nextState.transactions,
      logs:
        hooked.length > 0
          ? appendLog(
              nextState.logs,
              nextDay,
              'success',
              `钓鱼客免费入场（${visitors} 位）：钓起 ${hooked.map((f) => f.name).join('、')} 共 ${hooked.length} 尾，按成熟鱼价售出收入 ¥${anglerIncome}！`,
            )
          : appendLog(
              nextState.logs,
              nextDay,
              'info',
              `钓鱼客免费入场（${visitors} 位）：池中鱼群密度偏低，今日暂未上钩，建议多投放鱼苗吸引钓客。`,
            ),
    };
  }

  // 8. Re-run Auto Restock after sales/angler catches if fish or feed fell below half
  if (nextState.autoRestockEnabled) {
    nextState = runAutoRestockStep(nextState);
  }

  // 9. Check Bankruptcy: if pond has 0 fish, anglers leave & pond fails
  nextState = checkBankruptcyState(nextState);

  return nextState;
}
