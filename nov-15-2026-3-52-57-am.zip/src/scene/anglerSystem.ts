import * as THREE from 'three';
import { WATER_LEVEL, getPondVisualScale, groundHeightAt, pondSignedDistance } from './constants';
import type { MaterialBundle } from './materials';

export interface AnglerSystem {
  group: THREE.Group;
  setVisibleCount: (count: number) => void;
  update: (dt: number, elapsed: number) => void;
  dispose: () => void;
}

interface AnglerRig {
  root: THREE.Group;
  rodPivot: THREE.Group;
  bobber: THREE.Mesh;
  line: THREE.Line;
  rodTipLocal: THREE.Vector3;
  bobberBasePos: THREE.Vector3;
  phase: number;
  rippleTimer: number;
}

export function createAnglerSystem(materials: MaterialBundle): AnglerSystem {
  const group = new THREE.Group();
  group.name = 'manor-anglers';

  const ownedGeos: THREE.BufferGeometry[] = [];
  const ownedMats: THREE.Material[] = [];

  const trackGeo = <T extends THREE.BufferGeometry>(g: T): T => {
    ownedGeos.push(g);
    return g;
  };
  const trackMat = <T extends THREE.Material>(m: T): T => {
    ownedMats.push(m);
    return m;
  };

  // Stylized warm manor materials
  const skinMat = trackMat(
    new THREE.MeshStandardMaterial({ color: 0xe7b996, roughness: 0.78, metalness: 0.02 }),
  );
  const hatMat = trackMat(
    new THREE.MeshStandardMaterial({ color: 0xd9bc72, roughness: 0.88, metalness: 0.02 }),
  );
  const hatBandMat = trackMat(
    new THREE.MeshStandardMaterial({ color: 0x2a6659, roughness: 0.8 }),
  );
  const jacketMats = [
    trackMat(new THREE.MeshStandardMaterial({ color: 0x3b6d63, roughness: 0.82 })),
    trackMat(new THREE.MeshStandardMaterial({ color: 0xb96c3b, roughness: 0.82 })),
    trackMat(new THREE.MeshStandardMaterial({ color: 0x4b6380, roughness: 0.82 })),
  ];
  const pantsMat = trackMat(
    new THREE.MeshStandardMaterial({ color: 0x37403d, roughness: 0.88 }),
  );
  const rodMat = trackMat(
    new THREE.MeshStandardMaterial({ color: 0x72512f, roughness: 0.52, metalness: 0.15 }),
  );
  const bobberMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0xe04836,
      emissive: 0x3b0f0a,
      emissiveIntensity: 0.35,
      roughness: 0.35,
    }),
  );
  const lineMat = trackMat(
    new THREE.LineBasicMaterial({ color: 0xeef6f3, transparent: true, opacity: 0.72 }),
  );
  const bucketMat = trackMat(
    new THREE.MeshStandardMaterial({ color: 0xc29357, roughness: 0.72 }),
  );

  // Shared geometries
  const stoolTopGeo = trackGeo(new THREE.CylinderGeometry(0.22, 0.2, 0.05, 12));
  const stoolLegGeo = trackGeo(new THREE.CylinderGeometry(0.025, 0.025, 0.32, 6));
  const torsoGeo = trackGeo(new THREE.CapsuleGeometry(0.16, 0.28, 6, 12));
  const headGeo = trackGeo(new THREE.SphereGeometry(0.145, 14, 12));
  const hatBrimGeo = trackGeo(new THREE.ConeGeometry(0.32, 0.11, 16));
  const hatBandGeo = trackGeo(new THREE.CylinderGeometry(0.155, 0.16, 0.035, 14));
  const legGeo = trackGeo(new THREE.CapsuleGeometry(0.065, 0.24, 4, 8));
  const armGeo = trackGeo(new THREE.CapsuleGeometry(0.052, 0.22, 4, 8));
  const rodGeo = trackGeo(new THREE.CylinderGeometry(0.011, 0.024, 2.35, 8));
  rodGeo.translate(0, 1.175, 0);
  const bobberGeo = trackGeo(new THREE.SphereGeometry(0.045, 10, 10));
  const bucketGeo = trackGeo(new THREE.CylinderGeometry(0.14, 0.11, 0.24, 12));

  const s = getPondVisualScale();
  // Pre-placed scenic angler spots along shore & dock facing water
  const spots: Array<{ x: number; z: number; lookX: number; lookZ: number; yOverride?: number }> = [
    // South-west mossy river bank looking into west koi basin
    { x: -6.35 * s, z: 3.15 * s, lookX: -2.9 * s, lookZ: 0.6 * s },
    // South cove stone shore facing central pond
    { x: -1.45 * s, z: 4.55 * s, lookX: -0.9 * s, lookZ: 1.4 * s },
    // East cove shoreline near feeding dock
    { x: 6.45 * s, z: 1.55 * s, lookX: 3.8 * s, lookZ: 0.3 * s },
  ];

  const rigs: AnglerRig[] = spots.map((spot, idx) => {
    const anglerRoot = new THREE.Group();
    const groundY = spot.yOverride ?? groundHeightAt(spot.x, spot.z);
    anglerRoot.position.set(spot.x, groundY, spot.z);
    const yaw = Math.atan2(spot.lookX - spot.x, spot.lookZ - spot.z);
    anglerRoot.rotation.y = yaw;

    // Wooden fishing stool
    const stoolTop = new THREE.Mesh(stoolTopGeo, materials.woodDeckMat);
    stoolTop.position.set(0, 0.32, 0);
    stoolTop.castShadow = true;
    anglerRoot.add(stoolTop);

    for (let l = 0; l < 4; l++) {
      const a = (l / 4) * Math.PI * 2 + Math.PI / 4;
      const leg = new THREE.Mesh(stoolLegGeo, materials.woodDarkMat);
      leg.position.set(Math.cos(a) * 0.12, 0.16, Math.sin(a) * 0.12);
      leg.castShadow = true;
      anglerRoot.add(leg);
    }

    // Seated body
    const torso = new THREE.Mesh(torsoGeo, jacketMats[idx % jacketMats.length]);
    torso.position.set(0, 0.56, -0.02);
    torso.rotation.x = 0.14;
    torso.castShadow = true;
    anglerRoot.add(torso);

    // Legs (bent forward)
    for (const side of [-1, 1]) {
      const thigh = new THREE.Mesh(legGeo, pantsMat);
      thigh.position.set(side * 0.09, 0.36, 0.12);
      thigh.rotation.x = Math.PI * 0.44;
      thigh.castShadow = true;
      anglerRoot.add(thigh);

      const shin = new THREE.Mesh(legGeo, pantsMat);
      shin.position.set(side * 0.09, 0.17, 0.25);
      shin.rotation.x = 0.08;
      shin.castShadow = true;
      anglerRoot.add(shin);
    }

    // Head & Straw Sun Hat
    const head = new THREE.Mesh(headGeo, skinMat);
    head.position.set(0, 0.89, 0.03);
    head.castShadow = true;
    anglerRoot.add(head);

    const hatBrim = new THREE.Mesh(hatBrimGeo, hatMat);
    hatBrim.position.set(0, 1.01, 0.03);
    hatBrim.rotation.x = -0.08;
    hatBrim.castShadow = true;
    anglerRoot.add(hatBrim);

    const hatBand = new THREE.Mesh(hatBandGeo, hatBandMat);
    hatBand.position.set(0, 0.99, 0.03);
    anglerRoot.add(hatBand);

    // Arms holding fishing rod
    const armR = new THREE.Mesh(armGeo, jacketMats[idx % jacketMats.length]);
    armR.position.set(0.16, 0.58, 0.14);
    armR.rotation.x = 0.85;
    armR.rotation.z = -0.25;
    anglerRoot.add(armR);

    const armL = new THREE.Mesh(armGeo, jacketMats[idx % jacketMats.length]);
    armL.position.set(-0.15, 0.56, 0.14);
    armL.rotation.x = 0.92;
    armL.rotation.z = 0.28;
    anglerRoot.add(armL);

    // Wooden catch bucket beside stool
    const bucket = new THREE.Mesh(bucketGeo, bucketMat);
    bucket.position.set(0.36, 0.12, 0.06);
    bucket.castShadow = true;
    anglerRoot.add(bucket);

    // Fishing rod pivot
    const rodPivot = new THREE.Group();
    rodPivot.position.set(0.11, 0.58, 0.22);
    rodPivot.rotation.x = 1.05; // angled out over water
    const rodMesh = new THREE.Mesh(rodGeo, rodMat);
    rodMesh.castShadow = true;
    rodPivot.add(rodMesh);
    anglerRoot.add(rodPivot);

    // Find water bobber landing position in world space
    const dirX = Math.sin(yaw);
    const dirZ = Math.cos(yaw);
    let bobDist = 2.65;
    for (let d = 2.2; d <= 3.6; d += 0.25) {
      if (pondSignedDistance(spot.x + dirX * d, spot.z + dirZ * d) < -0.55) {
        bobDist = d;
        break;
      }
    }
    const bobWorldX = spot.x + dirX * bobDist;
    const bobWorldZ = spot.z + dirZ * bobDist;

    const bobber = new THREE.Mesh(bobberGeo, bobberMat);
    bobber.position.set(bobWorldX, WATER_LEVEL + 0.015, bobWorldZ);
    group.add(bobber);

    const lineGeo = trackGeo(new THREE.BufferGeometry());
    lineGeo.setAttribute(
      'position',
      new THREE.BufferAttribute(new Float32Array(6), 3),
    );
    const line = new THREE.Line(lineGeo, lineMat);
    group.add(line);

    group.add(anglerRoot);

    return {
      root: anglerRoot,
      rodPivot,
      bobber,
      line,
      rodTipLocal: new THREE.Vector3(0, 2.34, 0),
      bobberBasePos: new THREE.Vector3(bobWorldX, WATER_LEVEL + 0.015, bobWorldZ),
      phase: idx * 2.1,
      rippleTimer: 1.5 + idx * 0.9,
    };
  });

  let activeCount = 2;

  function setVisibleCount(count: number) {
    activeCount = Math.max(0, Math.min(rigs.length, count));
    rigs.forEach((rig, idx) => {
      const vis = idx < activeCount;
      rig.root.visible = vis;
      rig.bobber.visible = vis;
      rig.line.visible = vis;
    });
  }

  setVisibleCount(activeCount);

  const tmpTip = new THREE.Vector3();

  function update(dt: number, elapsed: number) {
    if (activeCount <= 0) return;

    for (let i = 0; i < activeCount; i++) {
      const r = rigs[i];
      const bobWave = Math.sin(elapsed * 2.6 + r.phase) * 0.024 + Math.sin(elapsed * 6.4 + r.phase) * 0.008;
      r.rodPivot.rotation.x = 1.05 + Math.sin(elapsed * 1.4 + r.phase) * 0.035;
      r.bobber.position.set(
        r.bobberBasePos.x,
        r.bobberBasePos.y + bobWave,
        r.bobberBasePos.z,
      );

      r.root.updateMatrixWorld(true);
      tmpTip.copy(r.rodTipLocal).applyMatrix4(r.rodPivot.matrixWorld);

      const posAttr = r.line.geometry.getAttribute('position') as THREE.BufferAttribute;
      posAttr.setXYZ(0, tmpTip.x, tmpTip.y, tmpTip.z);
      posAttr.setXYZ(1, r.bobber.position.x, r.bobber.position.y + 0.03, r.bobber.position.z);
      posAttr.needsUpdate = true;

      r.rippleTimer -= dt;
      if (r.rippleTimer <= 0) {
        materials.pushRipple(r.bobber.position.x, r.bobber.position.z, elapsed, 0.35);
        r.rippleTimer = 2.8 + (i % 2) * 1.1;
      }
    }
  }

  return {
    group,
    setVisibleCount,
    update,
    dispose: () => {
      ownedGeos.forEach((g) => g.dispose());
      ownedMats.forEach((m) => m.dispose());
    },
  };
}
