import * as THREE from 'three';
import {
  WATER_LEVEL,
  bridgeDeckHeightAt,
  getPondVisualScale,
  getScaledBridgeConfig,
  groundHeightAt,
  pondSignedDistance,
} from './constants';
import type { MaterialBundle } from './materials';

export interface EnvironmentDecor {
  group: THREE.Group;
  update: (dt: number, elapsed: number) => void;
  dispose: () => void;
}

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function createOrganicRockGeometry(radius: number, seed: number): THREE.BufferGeometry {
  const geo = new THREE.IcosahedronGeometry(radius, 2);
  const pos = geo.attributes.position;
  const rng = mulberry32(seed);
  const phaseX = rng() * 6.28;
  const phaseY = rng() * 6.28;
  const phaseZ = rng() * 6.28;

  for (let i = 0; i < pos.count; i++) {
    let x = pos.getX(i);
    let y = pos.getY(i);
    let z = pos.getZ(i);

    const n =
      0.82 +
      0.16 * Math.sin(x * 3.1 + phaseX) * Math.cos(z * 2.9 + phaseZ) +
      0.1 * Math.cos(y * 4.2 + phaseY);

    x *= n * 1.15;
    y *= n * 0.72; // natural river-stone flattening
    z *= n;

    // Flatten underside slightly so rocks sit solidly in mud/turf
    if (y < -radius * 0.35) {
      y = -radius * 0.35 + (y + radius * 0.35) * 0.25;
    }

    pos.setXYZ(i, x, y, z);
  }
  geo.computeVertexNormals();
  return geo;
}

function createNotchedLotusPadGeometry(radius: number): THREE.BufferGeometry {
  const shape = new THREE.Shape();
  const startAng = 0.24;
  const endAng = Math.PI * 2 - 0.24;
  shape.moveTo(0, 0);
  const segs = 28;
  for (let i = 0; i <= segs; i++) {
    const t = startAng + (i / segs) * (endAng - startAng);
    const waveR = radius * (1 + 0.03 * Math.sin(t * 7));
    shape.lineTo(Math.cos(t) * waveR, Math.sin(t) * waveR);
  }
  shape.lineTo(0, 0);

  const geo = new THREE.ExtrudeGeometry(shape, {
    depth: 0.022,
    bevelEnabled: true,
    bevelThickness: 0.008,
    bevelSize: 0.012,
    bevelSegments: 2,
  });
  geo.rotateX(-Math.PI / 2);

  // Subtle upward cup toward perimeter
  const pos = geo.attributes.position;
  const uvs = new Float32Array(pos.count * 2);
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const z = pos.getZ(i);
    const r = Math.hypot(x, z) / radius;
    pos.setY(i, pos.getY(i) + r * r * 0.038);
    uvs[i * 2] = x / (radius * 2) + 0.5;
    uvs[i * 2 + 1] = z / (radius * 2) + 0.5;
  }
  geo.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
  geo.computeVertexNormals();
  return geo;
}

export function createEnvironmentDecor(
  materials: MaterialBundle,
  facilityLevel = 1,
): EnvironmentDecor {
  const s = getPondVisualScale();
  const bridgeCfg = getScaledBridgeConfig();
  const group = new THREE.Group();
  group.name = 'manor-environment';

  const ownedGeometries: THREE.BufferGeometry[] = [];
  const ownedMaterials: THREE.Material[] = [];
  const trackGeo = <T extends THREE.BufferGeometry>(g: T): T => {
    ownedGeometries.push(g);
    return g;
  };
  const trackMat = <T extends THREE.Material>(m: T): T => {
    ownedMaterials.push(m);
    return m;
  };

  const contactShadowGeo = trackGeo(new THREE.PlaneGeometry(1, 1));
  contactShadowGeo.rotateX(-Math.PI / 2);

  function addContactShadow(parent: THREE.Object3D, x: number, y: number, z: number, scale: number) {
    const shadow = new THREE.Mesh(contactShadowGeo, materials.contactShadowMat);
    shadow.position.set(x, y + 0.018, z);
    shadow.scale.setScalar(scale);
    shadow.renderOrder = 1;
    parent.add(shadow);
  }

  // =========================================================================
  // 1. CURVED WOODEN ARCH BRIDGE (Spanning pond waist at x = 1.45)
  // =========================================================================
  const bridgeGroup = new THREE.Group();
  bridgeGroup.name = 'wooden-bridge';
  bridgeGroup.position.set(bridgeCfg.centerX, 0, bridgeCfg.centerZ);

  const halfSpan = bridgeCfg.spanLength * 0.5;
  const bridgeHalfW = bridgeCfg.width * 0.5;

  // 4 Timber Pilings + Stone Collars grounded in pond bed
  const pilingGeo = trackGeo(new THREE.CylinderGeometry(0.11, 0.13, 2.8, 12));
  const collarGeo = trackGeo(new THREE.CylinderGeometry(0.18, 0.22, 0.35, 12));
  const pilingCoords: Array<[number, number]> = [
    [-bridgeHalfW + 0.12, -1.85 * s],
    [bridgeHalfW - 0.12, -1.85 * s],
    [-bridgeHalfW + 0.12, 1.85 * s],
    [bridgeHalfW - 0.12, 1.85 * s],
  ];
  for (const [lx, lz] of pilingCoords) {
    const wx = bridgeCfg.centerX + lx;
    const wz = bridgeCfg.centerZ + lz;
    const bedY = groundHeightAt(wx, wz);
    const deckY = bridgeDeckHeightAt(lz);
    const postH = deckY - bedY + 0.15;

    const piling = new THREE.Mesh(pilingGeo, materials.woodDarkMat);
    piling.scale.y = postH / 2.8;
    piling.position.set(lx, bedY + postH * 0.5 - 0.1, lz);
    piling.castShadow = true;
    piling.receiveShadow = true;
    bridgeGroup.add(piling);

    const collar = new THREE.Mesh(collarGeo, materials.wetRockMat);
    collar.position.set(lx, bedY + 0.14, lz);
    collar.receiveShadow = true;
    bridgeGroup.add(collar);
  }

  // Two arched side stringer beams using TubeGeometry along parabolic arch
  const archPtsL: THREE.Vector3[] = [];
  const archPtsR: THREE.Vector3[] = [];
  for (let i = 0; i <= 20; i++) {
    const z = -halfSpan + (i / 20) * bridgeCfg.spanLength;
    const y = bridgeDeckHeightAt(z) - 0.08;
    archPtsL.push(new THREE.Vector3(-bridgeHalfW + 0.08, y, z));
    archPtsR.push(new THREE.Vector3(bridgeHalfW - 0.08, y, z));
  }
  const stringerGeoL = trackGeo(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(archPtsL), 24, 0.085, 8, false));
  const stringerGeoR = trackGeo(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(archPtsR), 24, 0.085, 8, false));
  const stringerL = new THREE.Mesh(stringerGeoL, materials.woodDarkMat);
  const stringerR = new THREE.Mesh(stringerGeoR, materials.woodDarkMat);
  stringerL.castShadow = true;
  stringerR.castShadow = true;
  bridgeGroup.add(stringerL, stringerR);

  // Individual beveled cedar deck planks scaled to span
  const plankCount = Math.round(22 * s);
  const plankGeo = trackGeo(new THREE.BoxGeometry(bridgeCfg.width + 0.14, 0.075, 0.27));
  for (let i = 0; i < plankCount; i++) {
    const t = (i + 0.5) / plankCount;
    const z = -halfSpan + t * bridgeCfg.spanLength;
    const y = bridgeDeckHeightAt(z);
    const yNext = bridgeDeckHeightAt(z + 0.05);
    const slopeAngle = Math.atan2(yNext - y, 0.05);

    const plank = new THREE.Mesh(plankGeo, materials.woodDeckMat);
    plank.position.set(0, y, z);
    plank.rotation.x = -slopeAngle;
    plank.castShadow = true;
    plank.receiveShadow = true;
    bridgeGroup.add(plank);
  }

  // Carved railing posts with brass finial caps & curved handrails
  const railPostGeo = trackGeo(new THREE.BoxGeometry(0.11, 0.72, 0.11));
  const finialCapGeo = trackGeo(new THREE.SphereGeometry(0.068, 10, 8));
  const handrailPtsL: THREE.Vector3[] = [];
  const handrailPtsR: THREE.Vector3[] = [];

  const postIndices = [0, 0.25, 0.5, 0.75, 1];
  for (const frac of postIndices) {
    const z = -halfSpan + 0.22 + frac * (bridgeCfg.spanLength - 0.44);
    const y = bridgeDeckHeightAt(z);
    for (const side of [-1, 1]) {
      const rx = side * (bridgeHalfW - 0.03);
      const post = new THREE.Mesh(railPostGeo, materials.woodDarkMat);
      post.position.set(rx, y + 0.36, z);
      post.castShadow = true;
      bridgeGroup.add(post);

      const cap = new THREE.Mesh(finialCapGeo, materials.brassMat);
      cap.position.set(rx, y + 0.76, z);
      cap.castShadow = true;
      bridgeGroup.add(cap);

      if (side < 0) handrailPtsL.push(new THREE.Vector3(rx, y + 0.65, z));
      else handrailPtsR.push(new THREE.Vector3(rx, y + 0.65, z));
    }
  }

  const railGeoL = trackGeo(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(handrailPtsL), 22, 0.048, 8, false));
  const railGeoR = trackGeo(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(handrailPtsR), 22, 0.048, 8, false));
  const railL = new THREE.Mesh(railGeoL, materials.woodDeckMat);
  const railR = new THREE.Mesh(railGeoR, materials.woodDeckMat);
  railL.castShadow = true;
  railR.castShadow = true;
  bridgeGroup.add(railL, railR);

  // Stone abutments at both ends of the bridge
  const abutmentGeo = trackGeo(new THREE.BoxGeometry(bridgeCfg.width + 0.5, 0.55, 0.75));
  for (const zEnd of [-halfSpan - 0.18, halfSpan + 0.18]) {
    const gY = groundHeightAt(bridgeCfg.centerX, bridgeCfg.centerZ + zEnd);
    const abut = new THREE.Mesh(abutmentGeo, materials.graniteMat);
    abut.position.set(0, Math.max(gY, 0.15) + 0.08, zEnd);
    abut.castShadow = true;
    abut.receiveShadow = true;
    bridgeGroup.add(abut);
  }
  group.add(bridgeGroup);

  // =========================================================================
  // 2. TIMBER FEEDING DOCK & AUTOMATIC SOLAR FEEDER (Southeast Bank)
  // =========================================================================
  const dockGroup = new THREE.Group();
  dockGroup.name = 'feeding-dock';
  const dockX = 5.45 * s;
  const dockZ = 2.55 * s;
  dockGroup.position.set(dockX, 0.34, dockZ);
  dockGroup.rotation.y = -0.68;

  // Dock pilings grounded to bed/bank
  const dockPostGeo = trackGeo(new THREE.CylinderGeometry(0.085, 0.1, 1.8, 10));
  for (const [px, pz] of [
    [-1.15, -0.95],
    [1.15, -0.95],
    [-1.15, 0.95],
    [1.15, 0.95],
  ]) {
    const post = new THREE.Mesh(dockPostGeo, materials.woodDarkMat);
    post.position.set(px, -0.58, pz);
    post.castShadow = true;
    post.receiveShadow = true;
    dockGroup.add(post);
  }

  // Dock deck planks
  const dockPlankGeo = trackGeo(new THREE.BoxGeometry(2.55, 0.08, 0.24));
  for (let i = 0; i < 8; i++) {
    const p = new THREE.Mesh(dockPlankGeo, materials.woodDeckMat);
    p.position.set(0, 0, -0.88 + i * 0.255);
    p.castShadow = true;
    p.receiveShadow = true;
    dockGroup.add(p);
  }

  // Mooring bollard + rope coil
  const bollardGeo = trackGeo(new THREE.CylinderGeometry(0.085, 0.095, 0.48, 12));
  const bollard = new THREE.Mesh(bollardGeo, materials.woodDarkMat);
  bollard.position.set(-1.02, 0.26, -0.82);
  bollard.castShadow = true;
  dockGroup.add(bollard);

  const ropeCoilGeo = trackGeo(new THREE.TorusGeometry(0.11, 0.025, 8, 18));
  ropeCoilGeo.rotateX(Math.PI / 2);
  const ropeCoil = new THREE.Mesh(ropeCoilGeo, materials.thatchMat);
  ropeCoil.position.set(-1.02, 0.08, -0.82);
  dockGroup.add(ropeCoil);

  // Automatic Solar Fish Feeder (`生态自动投喂机`)
  const feederGroup = new THREE.Group();
  feederGroup.position.set(0.68, 0.04, -0.45);
  const feederLegsGeo = trackGeo(new THREE.CylinderGeometry(0.03, 0.035, 0.55, 8));
  for (const [lx, lz] of [
    [-0.18, -0.18],
    [0.18, -0.18],
    [0, 0.22],
  ]) {
    const leg = new THREE.Mesh(feederLegsGeo, materials.woodDarkMat);
    leg.position.set(lx, 0.26, lz);
    leg.castShadow = true;
    feederGroup.add(leg);
  }
  const hopperGeo = trackGeo(new THREE.CylinderGeometry(0.24, 0.16, 0.48, 16));
  const hopper = new THREE.Mesh(hopperGeo, materials.ceramicMat);
  hopper.position.y = 0.62;
  hopper.castShadow = true;
  feederGroup.add(hopper);

  const hopperRimGeo = trackGeo(new THREE.TorusGeometry(0.24, 0.022, 8, 20));
  hopperRimGeo.rotateX(Math.PI / 2);
  const hopperRim = new THREE.Mesh(hopperRimGeo, materials.brassMat);
  hopperRim.position.y = 0.85;
  feederGroup.add(hopperRim);

  const lidGeo = trackGeo(new THREE.ConeGeometry(0.27, 0.15, 16));
  const lid = new THREE.Mesh(lidGeo, materials.brassMat);
  lid.position.y = 0.93;
  lid.castShadow = true;
  feederGroup.add(lid);

  const solarGeo = trackGeo(new THREE.BoxGeometry(0.26, 0.03, 0.22));
  const solarMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x1a324d,
      roughness: 0.18,
      metalness: 0.65,
    }),
  );
  const solarPanel = new THREE.Mesh(solarGeo, solarMat);
  solarPanel.position.set(0, 1.05, 0);
  solarPanel.rotation.x = 0.35;
  feederGroup.add(solarPanel);

  const chuteGeo = trackGeo(new THREE.CylinderGeometry(0.04, 0.055, 0.26, 10));
  chuteGeo.rotateX(Math.PI * 0.35);
  const chute = new THREE.Mesh(chuteGeo, materials.brassMat);
  chute.position.set(0, 0.38, -0.22);
  feederGroup.add(chute);
  dockGroup.add(feederGroup);

  // Woven Bamboo Fish Basket (`竹编鱼篓`) via LatheGeometry
  const basketPts = [
    new THREE.Vector2(0.01, 0),
    new THREE.Vector2(0.16, 0.02),
    new THREE.Vector2(0.22, 0.18),
    new THREE.Vector2(0.18, 0.36),
    new THREE.Vector2(0.13, 0.44),
    new THREE.Vector2(0.15, 0.48),
  ];
  const basketGeo = trackGeo(new THREE.LatheGeometry(basketPts, 18));
  const basket = new THREE.Mesh(basketGeo, materials.bambooMat);
  basket.position.set(-0.48, 0.04, 0.32);
  basket.castShadow = true;
  basket.receiveShadow = true;
  dockGroup.add(basket);

  // Wooden Feed Bucket
  const bucketGeo = trackGeo(new THREE.CylinderGeometry(0.16, 0.12, 0.26, 14));
  const bucket = new THREE.Mesh(bucketGeo, materials.woodDeckMat);
  bucket.position.set(-0.02, 0.17, 0.48);
  bucket.castShadow = true;
  dockGroup.add(bucket);

  group.add(dockGroup);

  // =========================================================================
  // 3. FLOATING PADDLE-WHEEL AERATOR (`水车增氧机`) IN NORTH COVE
  // =========================================================================
  const aeratorGroup = new THREE.Group();
  aeratorGroup.name = 'paddle-aerator';
  aeratorGroup.position.set(-3.9 * s, WATER_LEVEL + 0.04, -2.4 * s);
  aeratorGroup.rotation.y = 0.45;

  const pontoonGeo = trackGeo(new THREE.CapsuleGeometry(0.13, 1.15, 6, 12));
  pontoonGeo.rotateX(Math.PI / 2);
  for (const px of [-0.55, 0.55]) {
    const pontoon = new THREE.Mesh(pontoonGeo, materials.ceramicMat);
    pontoon.position.set(px, 0.0, 0);
    pontoon.castShadow = true;
    aeratorGroup.add(pontoon);
  }

  const frameCrossGeo = trackGeo(new THREE.BoxGeometry(1.22, 0.06, 0.12));
  for (const fz of [-0.38, 0.38]) {
    const bar = new THREE.Mesh(frameCrossGeo, materials.woodDarkMat);
    bar.position.set(0, 0.13, fz);
    bar.castShadow = true;
    aeratorGroup.add(bar);
  }

  const motorHousingGeo = trackGeo(new THREE.CylinderGeometry(0.16, 0.18, 0.36, 14));
  motorHousingGeo.rotateZ(Math.PI / 2);
  const motorHousing = new THREE.Mesh(motorHousingGeo, materials.brassMat);
  motorHousing.position.set(0, 0.28, 0);
  motorHousing.castShadow = true;
  aeratorGroup.add(motorHousing);

  // Rotating Paddle Axle & Slatted Wheels
  const paddleAxleGroup = new THREE.Group();
  paddleAxleGroup.position.set(0, 0.14, 0);
  const axleGeo = trackGeo(new THREE.CylinderGeometry(0.035, 0.035, 1.75, 10));
  axleGeo.rotateZ(Math.PI / 2);
  const axle = new THREE.Mesh(axleGeo, materials.brassMat);
  paddleAxleGroup.add(axle);

  const hubGeo = trackGeo(new THREE.CylinderGeometry(0.09, 0.09, 0.12, 12));
  hubGeo.rotateZ(Math.PI / 2);
  const bladeGeo = trackGeo(new THREE.BoxGeometry(0.24, 0.22, 0.025));

  for (const wx of [-0.82, 0.82]) {
    const hub = new THREE.Mesh(hubGeo, materials.woodDarkMat);
    hub.position.x = wx;
    paddleAxleGroup.add(hub);

    for (let b = 0; b < 6; b++) {
      const ang = (b / 6) * Math.PI * 2;
      const blade = new THREE.Mesh(bladeGeo, materials.woodDeckMat);
      blade.position.set(wx, Math.cos(ang) * 0.23, Math.sin(ang) * 0.23);
      blade.rotation.x = ang;
      blade.castShadow = true;
      paddleAxleGroup.add(blade);
    }
  }
  aeratorGroup.add(paddleAxleGroup);
  group.add(aeratorGroup);

  // =========================================================================
  // 4. BAMBOO SPRING WATER SPOUT & TIERED MOSS ROCK CASCADE (Northwest)
  // =========================================================================
  const spoutGroup = new THREE.Group();
  spoutGroup.name = 'bamboo-spring-spout';
  const spoutBaseX = -6.0 * s;
  const spoutBaseZ = -3.3 * s;
  const spoutGroundY = groundHeightAt(spoutBaseX, spoutBaseZ);
  spoutGroup.position.set(spoutBaseX, spoutGroundY, spoutBaseZ);
  spoutGroup.rotation.y = -0.78;

  // Support A-frame bamboo legs
  const legBambooGeo = trackGeo(new THREE.CylinderGeometry(0.045, 0.052, 1.15, 10));
  for (const side of [-1, 1]) {
    const leg = new THREE.Mesh(legBambooGeo, materials.bambooMat);
    leg.position.set(side * 0.24, 0.46, 0.0);
    leg.rotation.z = side * 0.24;
    leg.castShadow = true;
    spoutGroup.add(leg);
  }
  // Angled bamboo spout trough
  const spoutPipeGeo = trackGeo(new THREE.CylinderGeometry(0.075, 0.085, 1.65, 14));
  spoutPipeGeo.rotateX(Math.PI / 2 - 0.26);
  const spoutPipe = new THREE.Mesh(spoutPipeGeo, materials.bambooMat);
  spoutPipe.position.set(0, 0.82, 0.35);
  spoutPipe.castShadow = true;
  spoutGroup.add(spoutPipe);

  // Pouring spring water stream arc into pond
  const streamCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, 0.60, 1.12),
    new THREE.Vector3(0, 0.36, 1.38),
    new THREE.Vector3(0, -spoutGroundY + 0.02, 1.56),
  ]);
  const streamGeo = trackGeo(new THREE.TubeGeometry(streamCurve, 14, 0.036, 8, false));
  const streamMesh = new THREE.Mesh(streamGeo, materials.springWaterStreamMat);
  spoutGroup.add(streamMesh);
  group.add(spoutGroup);

  // =========================================================================
  // 5. WATER QUALITY MONITORING BUOY (East Cove)
  // =========================================================================
  const buoyGroup = new THREE.Group();
  buoyGroup.name = 'water-quality-buoy';
  buoyGroup.position.set(4.8 * s, WATER_LEVEL, -1.6 * s);

  const buoyRingGeo = trackGeo(new THREE.TorusGeometry(0.24, 0.075, 10, 20));
  buoyRingGeo.rotateX(Math.PI / 2);
  const buoyRing = new THREE.Mesh(buoyRingGeo, materials.woodDeckMat);
  buoyRing.castShadow = true;
  buoyGroup.add(buoyRing);

  const buoyCoreGeo = trackGeo(new THREE.CylinderGeometry(0.14, 0.16, 0.24, 14));
  const buoyCore = new THREE.Mesh(buoyCoreGeo, materials.brassMat);
  buoyCore.position.y = 0.04;
  buoyGroup.add(buoyCore);

  const mastGeo = trackGeo(new THREE.CylinderGeometry(0.022, 0.028, 0.52, 8));
  const mast = new THREE.Mesh(mastGeo, materials.brassMat);
  mast.position.y = 0.34;
  buoyGroup.add(mast);

  const beaconGeo = trackGeo(new THREE.SphereGeometry(0.055, 12, 10));
  const beacon = new THREE.Mesh(beaconGeo, materials.lanternGlowMat);
  beacon.position.y = 0.62;
  buoyGroup.add(beacon);
  group.add(buoyGroup);

  // =========================================================================
  // 6. MANOR CARE GAZEBO (`水产管护木亭`) ON NORTHEAST TERRACE
  // =========================================================================
  const gazeboGroup = new THREE.Group();
  gazeboGroup.name = 'manor-gazebo';
  const gzX = 7.6 * s;
  const gzZ = -5.6 * s;
  const gzGroundY = groundHeightAt(gzX, gzZ);
  gazeboGroup.position.set(gzX, gzGroundY, gzZ);
  gazeboGroup.rotation.y = -0.35;

  // Stone plinth floor
  const plinthGeo = trackGeo(new THREE.BoxGeometry(3.2, 0.35, 2.8));
  const plinth = new THREE.Mesh(plinthGeo, materials.graniteMat);
  plinth.position.y = 0.1;
  plinth.castShadow = true;
  plinth.receiveShadow = true;
  gazeboGroup.add(plinth);
  addContactShadow(gazeboGroup, 0, 0.02, 0, 4.4);

  // 4 Cedar pillars
  const gzPostGeo = trackGeo(new THREE.CylinderGeometry(0.09, 0.105, 2.25, 10));
  for (const [px, pz] of [
    [-1.25, -1.05],
    [1.25, -1.05],
    [-1.25, 1.05],
    [1.25, 1.05],
  ]) {
    const pillar = new THREE.Mesh(gzPostGeo, materials.woodDarkMat);
    pillar.position.set(px, 1.35, pz);
    pillar.castShadow = true;
    pillar.receiveShadow = true;
    gazeboGroup.add(pillar);
  }

  // Eaves beam frame
  const beamXGeo = trackGeo(new THREE.BoxGeometry(2.9, 0.14, 0.14));
  const beamZGeo = trackGeo(new THREE.BoxGeometry(0.14, 0.14, 2.5));
  for (const bz of [-1.05, 1.05]) {
    const b = new THREE.Mesh(beamXGeo, materials.woodDarkMat);
    b.position.set(0, 2.42, bz);
    gazeboGroup.add(b);
  }
  for (const bx of [-1.25, 1.25]) {
    const b = new THREE.Mesh(beamZGeo, materials.woodDarkMat);
    b.position.set(bx, 2.42, 0);
    gazeboGroup.add(b);
  }

  // Pitched pyramidal shingled roof + brass roof finial
  const roofGeo = trackGeo(new THREE.ConeGeometry(2.45, 1.25, 4));
  roofGeo.rotateY(Math.PI / 4);
  const roof = new THREE.Mesh(roofGeo, materials.thatchMat);
  roof.position.y = 3.05;
  roof.scale.set(1.08, 1.0, 0.96);
  roof.castShadow = true;
  roof.receiveShadow = true;
  gazeboGroup.add(roof);

  const roofCapGeo = trackGeo(new THREE.SphereGeometry(0.14, 12, 10));
  const roofCap = new THREE.Mesh(roofCapGeo, materials.brassMat);
  roofCap.position.y = 3.72;
  gazeboGroup.add(roofCap);

  // Stacked burlap feed sacks + celadon water jar + leaning landing net
  const sackGeo = trackGeo(new THREE.SphereGeometry(0.28, 12, 10));
  sackGeo.scale(1.25, 0.65, 0.95);
  for (const [sx, sy, sz, rot] of [
    [-0.75, 0.4, -0.5, 0.2],
    [-0.65, 0.4, -0.05, -0.35],
    [-0.7, 0.64, -0.28, 0.1],
  ]) {
    const sack = new THREE.Mesh(sackGeo, materials.woodDeckMat);
    sack.position.set(sx, sy, sz);
    sack.rotation.y = rot;
    sack.castShadow = true;
    gazeboGroup.add(sack);
  }

  const jarPts = [
    new THREE.Vector2(0.01, 0),
    new THREE.Vector2(0.2, 0.03),
    new THREE.Vector2(0.28, 0.25),
    new THREE.Vector2(0.24, 0.45),
    new THREE.Vector2(0.14, 0.54),
    new THREE.Vector2(0.17, 0.6),
  ];
  const jarGeo = trackGeo(new THREE.LatheGeometry(jarPts, 16));
  const jar = new THREE.Mesh(jarGeo, materials.ceramicMat);
  jar.position.set(0.75, 0.28, -0.45);
  jar.castShadow = true;
  gazeboGroup.add(jar);

  // Landing net (`抄网`) leaning on front-left pillar
  const netHandleGeo = trackGeo(new THREE.CylinderGeometry(0.022, 0.024, 1.75, 8));
  const netHandle = new THREE.Mesh(netHandleGeo, materials.bambooMat);
  netHandle.position.set(-1.12, 1.08, 1.16);
  netHandle.rotation.z = -0.18;
  netHandle.rotation.x = 0.14;
  netHandle.castShadow = true;
  gazeboGroup.add(netHandle);

  const netHoopGeo = trackGeo(new THREE.TorusGeometry(0.2, 0.018, 8, 18));
  const netHoop = new THREE.Mesh(netHoopGeo, materials.brassMat);
  netHoop.position.set(-0.94, 2.04, 1.03);
  netHoop.rotation.y = 0.35;
  gazeboGroup.add(netHoop);

  group.add(gazeboGroup);

  // =========================================================================
  // 7. SHORELINE BOULDERS, PEBBLES (InstancedMesh), LANTERNS & STEPPING STONES
  // =========================================================================
  const rng = mulberry32(2026);
  const rockVariantGeos = [
    trackGeo(createOrganicRockGeometry(0.58, 11)),
    trackGeo(createOrganicRockGeometry(0.45, 22)),
    trackGeo(createOrganicRockGeometry(0.72, 33)),
  ];

  // Sample perimeter around pond where pondSignedDistance ≈ 0..0.45
  let rockCount = 0;
  for (let angleIdx = 0; angleIdx < 56; angleIdx++) {
    const theta = (angleIdx / 56) * Math.PI * 2;
    let r = 2.0 * s;
    while (r < 12.5 * s && pondSignedDistance(Math.cos(theta) * r, Math.sin(theta) * r) < 0.05) {
      r += 0.25 * s;
    }
    const rx = Math.cos(theta) * r + (rng() - 0.5) * 0.45;
    const rz = Math.sin(theta) * r + (rng() - 0.5) * 0.45;

    // Skip bridge abutments & dock footprint
    if (Math.abs(rx - bridgeCfg.centerX) < 1.35 * s && Math.abs(rz - bridgeCfg.centerZ) > 2.2 * s) continue;
    if (Math.hypot(rx - dockX, rz - dockZ) < 1.8) continue;
    if (rng() < 0.34) continue; // keep natural open grassy shore stretches!

    const ry = groundHeightAt(rx, rz);
    const geo = rockVariantGeos[rockCount % rockVariantGeos.length];
    const isWet = ry < 0.14;
    const rock = new THREE.Mesh(geo, isWet ? materials.wetRockMat : materials.graniteMat);
    const rockScale = 0.68 + rng() * 0.88;
    rock.scale.set(
      rockScale * (0.9 + rng() * 0.25),
      rockScale * (0.75 + rng() * 0.35),
      rockScale,
    );
    rock.position.set(rx, ry + 0.08 * rockScale, rz);
    rock.rotation.set((rng() - 0.5) * 0.3, rng() * Math.PI * 2, (rng() - 0.5) * 0.3);
    rock.castShadow = true;
    rock.receiveShadow = true;
    group.add(rock);
    if (!isWet) addContactShadow(group, rx, ry, rz, rockScale * 1.45);
    rockCount++;
  }

  // Extra dramatic cascade boulders around northwest waterfall spout
  for (const [bx, bz, bs] of [
    [-6.2 * s, -2.9 * s, 1.35],
    [-5.4 * s, -3.5 * s, 1.15],
    [-6.6 * s, -2.2 * s, 1.0],
    [-5.1 * s, -2.3 * s, 0.85],
  ]) {
    const by = groundHeightAt(bx, bz);
    const boulder = new THREE.Mesh(rockVariantGeos[2], materials.wetRockMat);
    boulder.scale.setScalar(bs);
    boulder.position.set(bx, by + 0.15, bz);
    boulder.rotation.y = rng() * Math.PI;
    boulder.castShadow = true;
    boulder.receiveShadow = true;
    group.add(boulder);
  }

  // InstancedMesh shoreline & pond-bed smooth river pebbles (~180 instances)
  const pebbleGeo = trackGeo(new THREE.DodecahedronGeometry(0.11, 1));
  pebbleGeo.scale(1.2, 0.55, 0.95);
  const pebbleCount = 180;
  const pebbleInstanced = new THREE.InstancedMesh(pebbleGeo, materials.wetRockMat, pebbleCount);
  pebbleInstanced.receiveShadow = true;
  const dummy = new THREE.Object3D();
  const cPebble = new THREE.Color();
  let pPlaced = 0;
  for (let i = 0; i < 650 && pPlaced < pebbleCount; i++) {
    const px = (rng() - 0.5) * 16.5 * s;
    const pz = (rng() - 0.5) * 12.5 * s;
    const sdf = pondSignedDistance(px, pz);
    if (sdf > -1.8 && sdf < 0.55) {
      const py = groundHeightAt(px, pz);
      dummy.position.set(px, py + 0.02, pz);
      dummy.rotation.set(rng() * 0.3, rng() * Math.PI * 2, rng() * 0.3);
      const ps = 0.55 + rng() * 1.25;
      dummy.scale.setScalar(ps);
      dummy.updateMatrix();
      pebbleInstanced.setMatrixAt(pPlaced, dummy.matrix);
      cPebble.setHSL(0.1 + rng() * 0.08, 0.1 + rng() * 0.12, 0.55 + rng() * 0.3);
      pebbleInstanced.setColorAt(pPlaced, cPebble);
      pPlaced++;
    }
  }
  pebbleInstanced.count = pPlaced;
  pebbleInstanced.instanceMatrix.needsUpdate = true;
  if (pebbleInstanced.instanceColor) pebbleInstanced.instanceColor.needsUpdate = true;
  pebbleInstanced.computeBoundingSphere();
  group.add(pebbleInstanced);

  // Manor Stone Lanterns (`石灯笼`) along path & dock
  const lanternBaseGeo = trackGeo(new THREE.CylinderGeometry(0.16, 0.22, 0.28, 6));
  const lanternStemGeo = trackGeo(new THREE.CylinderGeometry(0.09, 0.11, 0.42, 6));
  const lanternBoxGeo = trackGeo(new THREE.BoxGeometry(0.24, 0.24, 0.24));
  const lanternRoofGeo = trackGeo(new THREE.ConeGeometry(0.32, 0.22, 6));
  for (const [lx, lz] of [
    [2.7 * s, -3.55 * s],
    [0.2 * s, 4.15 * s],
    [6.55 * s, 1.35 * s],
  ]) {
    const ly = groundHeightAt(lx, lz);
    const lantern = new THREE.Group();
    lantern.position.set(lx, ly, lz);

    const base = new THREE.Mesh(lanternBaseGeo, materials.graniteMat);
    base.position.y = 0.12;
    base.castShadow = true;
    lantern.add(base);

    const stem = new THREE.Mesh(lanternStemGeo, materials.graniteMat);
    stem.position.y = 0.44;
    stem.castShadow = true;
    lantern.add(stem);

    const chamber = new THREE.Mesh(lanternBoxGeo, materials.lanternGlowMat);
    chamber.position.y = 0.74;
    lantern.add(chamber);

    const cap = new THREE.Mesh(lanternRoofGeo, materials.graniteMat);
    cap.position.y = 0.96;
    cap.castShadow = true;
    lantern.add(cap);

    addContactShadow(lantern, 0, 0.01, 0, 0.75);
    group.add(lantern);
  }

  // Flagstone Stepping Stones connecting bridge -> gazebo & bridge -> feeding dock
  const flagstoneGeo = trackGeo(new THREE.CylinderGeometry(0.36, 0.4, 0.08, 7));
  const stonePathCoords: Array<[number, number]> = [
    [1.7 * s, -3.9 * s],
    [2.45 * s, -4.45 * s],
    [3.35 * s, -4.85 * s],
    [4.35 * s, -5.15 * s],
    [5.35 * s, -5.35 * s],
    [1.65 * s, 4.15 * s],
    [2.55 * s, 4.1 * s],
    [3.5 * s, 3.75 * s],
    [4.35 * s, 3.3 * s],
  ];
  for (const [sx, sz] of stonePathCoords) {
    const sy = groundHeightAt(sx, sz);
    const stone = new THREE.Mesh(flagstoneGeo, materials.graniteMat);
    stone.position.set(sx, sy + 0.02, sz);
    stone.scale.set(1.15, 1, 0.82);
    stone.rotation.y = rng() * Math.PI;
    stone.receiveShadow = true;
    group.add(stone);
  }

  // =========================================================================
  // 8. LOTUS PADS, BLOSSOMING LOTUS FLOWERS, WATERWEED & CATTAILS
  // =========================================================================
  const lotusPadGeo = trackGeo(createNotchedLotusPadGeometry(0.46));
  const lotusPetalGeo = trackGeo(new THREE.SphereGeometry(0.11, 8, 8));
  lotusPetalGeo.scale(0.65, 1.35, 0.28);
  const lotusPodGeo = trackGeo(new THREE.CylinderGeometry(0.065, 0.04, 0.06, 10));

  const lotusClusters: Array<{ x: number; z: number; scale: number; hasFlower: boolean; pink: boolean }> = [
    { x: -5.0, z: 1.6, scale: 1.05, hasFlower: true, pink: true },
    { x: -4.4, z: 2.25, scale: 0.85, hasFlower: false, pink: true },
    { x: -5.55, z: 2.2, scale: 0.72, hasFlower: false, pink: false },
    { x: -4.75, z: 0.9, scale: 0.92, hasFlower: true, pink: false },
    { x: 0.25, z: 2.75, scale: 0.98, hasFlower: true, pink: true },
    { x: 0.95, z: 3.1, scale: 0.78, hasFlower: false, pink: true },
    { x: -0.35, z: 2.25, scale: 0.74, hasFlower: false, pink: false },
    { x: 5.1, z: -2.5, scale: 1.0, hasFlower: true, pink: true },
    { x: 5.7, z: -2.0, scale: 0.82, hasFlower: false, pink: true },
    { x: 4.5, z: -2.85, scale: 0.76, hasFlower: true, pink: false },
    { x: 6.1, z: -0.25, scale: 0.94, hasFlower: true, pink: true },
    { x: 5.6, z: 0.45, scale: 0.75, hasFlower: false, pink: true },
    { x: -2.1, z: -2.95, scale: 0.88, hasFlower: false, pink: true },
    { x: -1.45, z: -3.15, scale: 0.7, hasFlower: false, pink: false },
  ];

  const floatingLotusPads: Array<{ mesh: THREE.Object3D; baseY: number; phase: number }> = [];

  lotusClusters.forEach((item, idx) => {
    const padGroup = new THREE.Group();
    padGroup.position.set(item.x * s, WATER_LEVEL + 0.018, item.z * s);
    padGroup.rotation.y = idx * 1.45;
    padGroup.scale.setScalar(item.scale);

    const pad = new THREE.Mesh(lotusPadGeo, materials.lotusLeafMat);
    pad.castShadow = true;
    pad.receiveShadow = true;
    padGroup.add(pad);

    if (item.hasFlower) {
      const flower = new THREE.Group();
      flower.position.set(0.06, 0.04, 0.04);
      const petalMat = item.pink ? materials.lotusPetalPinkMat : materials.lotusPetalCreamMat;

      // Outer 8 petals + inner 6 petals
      for (let ring = 0; ring < 2; ring++) {
        const count = ring === 0 ? 8 : 6;
        const rDist = ring === 0 ? 0.105 : 0.062;
        const tilt = ring === 0 ? 0.85 : 0.48;
        for (let p = 0; p < count; p++) {
          const ang = (p / count) * Math.PI * 2 + ring * 0.35;
          const petal = new THREE.Mesh(lotusPetalGeo, petalMat);
          petal.position.set(Math.cos(ang) * rDist, 0.06 + ring * 0.025, Math.sin(ang) * rDist);
          petal.rotation.y = -ang + Math.PI / 2;
          petal.rotation.x = tilt;
          petal.castShadow = true;
          flower.add(petal);
        }
      }
      const pod = new THREE.Mesh(lotusPodGeo, materials.lotusCenterMat);
      pod.position.y = 0.075;
      flower.add(pod);
      padGroup.add(flower);
    }

    group.add(padGroup);
    floatingLotusPads.push({ mesh: padGroup, baseY: WATER_LEVEL + 0.018, phase: idx * 0.85 });
  });

  // Submerged Swaying Ribbon Waterweed (`水草`)
  const ribbonBladeGeo = trackGeo(new THREE.PlaneGeometry(0.085, 0.85, 1, 6));
  ribbonBladeGeo.translate(0, 0.425, 0);
  // Subtle natural bend on ribbon geometry
  const rbPos = ribbonBladeGeo.attributes.position;
  for (let i = 0; i < rbPos.count; i++) {
    const py = rbPos.getY(i);
    rbPos.setZ(i, Math.sin(py * 3.5) * 0.05);
  }
  ribbonBladeGeo.computeVertexNormals();

  for (let w = 0; w < 26; w++) {
    const wx = (-6.2 + rng() * 12.6) * s;
    const wz = (-3.4 + rng() * 6.8) * s;
    const sdf = pondSignedDistance(wx, wz);
    if (sdf < -0.55 * s && sdf > -2.8 * s) {
      const bedY = groundHeightAt(wx, wz);
      const clump = new THREE.Group();
      clump.position.set(wx, bedY, wz);
      const bladeCount = 5 + Math.floor(rng() * 4);
      const maxH = Math.min(0.85, Math.abs(bedY) * 0.72);
      for (let b = 0; b < bladeCount; b++) {
        const blade = new THREE.Mesh(ribbonBladeGeo, materials.waterweedMat);
        blade.rotation.y = (b / bladeCount) * Math.PI + rng() * 0.4;
        blade.rotation.x = (rng() - 0.5) * 0.25;
        blade.scale.set(0.8 + rng() * 0.5, maxH / 0.85, 1);
        clump.add(blade);
      }
      group.add(clump);
    }
  }

  // Shoreline Cattails (`香蒲芦苇`)
  const cattailBladeGeo = trackGeo(new THREE.ConeGeometry(0.032, 1.05, 4));
  cattailBladeGeo.translate(0, 0.525, 0);
  const cattailStalkGeo = trackGeo(new THREE.CylinderGeometry(0.014, 0.018, 1.25, 6));
  cattailStalkGeo.translate(0, 0.625, 0);
  const cattailSpikeGeo = trackGeo(new THREE.CapsuleGeometry(0.032, 0.16, 4, 8));

  const cattailSpots: Array<[number, number]> = [
    [-6.6, 1.2],
    [-6.1, 2.3],
    [-4.9, 3.5],
    [-2.4, 4.1],
    [3.3, 3.2],
    [6.6, 0.9],
    [6.9, -1.5],
    [5.8, -3.2],
    [-0.5, -3.6],
    [-3.3, -3.8],
  ];
  for (const [cx0, cz0] of cattailSpots) {
    const cx = cx0 * s;
    const cz = cz0 * s;
    const cy = groundHeightAt(cx, cz);
    const reedGroup = new THREE.Group();
    reedGroup.position.set(cx, cy - 0.04, cz);
    for (let i = 0; i < 6; i++) {
      const blade = new THREE.Mesh(cattailBladeGeo, materials.cattailLeafMat);
      blade.position.set((rng() - 0.5) * 0.28, 0, (rng() - 0.5) * 0.28);
      blade.rotation.set((rng() - 0.5) * 0.35, rng() * Math.PI, (rng() - 0.5) * 0.35);
      blade.scale.setScalar(0.75 + rng() * 0.45);
      blade.castShadow = true;
      reedGroup.add(blade);
    }
    for (let st = 0; st < 2; st++) {
      const sx = (rng() - 0.5) * 0.22;
      const sz = (rng() - 0.5) * 0.22;
      const stalk = new THREE.Mesh(cattailStalkGeo, materials.cattailLeafMat);
      stalk.position.set(sx, 0, sz);
      stalk.rotation.z = (rng() - 0.5) * 0.12;
      reedGroup.add(stalk);

      const spike = new THREE.Mesh(cattailSpikeGeo, materials.cattailHeadMat);
      spike.position.set(sx, 1.05, sz);
      spike.castShadow = true;
      reedGroup.add(spike);
    }
    group.add(reedGroup);
  }

  // =========================================================================
  // 9. TREES (Weeping Willow & Japanese Maples) & MEADOW GRASS TUFTS
  // =========================================================================
  const canopyClusterGeo = trackGeo(new THREE.IcosahedronGeometry(0.95, 2));
  const willowCurtainGeo = trackGeo(new THREE.CylinderGeometry(0.035, 0.01, 1.65, 5));

  function addWillowTree(tx: number, tz: number, scale: number) {
    const ty = groundHeightAt(tx, tz);
    const tree = new THREE.Group();
    tree.position.set(tx, ty, tz);
    tree.scale.setScalar(scale);

    // Gnarled curved main trunk
    const trunkCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, -0.1, 0),
      new THREE.Vector3(0.18, 1.15, 0.1),
      new THREE.Vector3(0.32, 2.35, -0.08),
    ]);
    const trunkGeo = trackGeo(new THREE.TubeGeometry(trunkCurve, 12, 0.26, 8, false));
    const trunk = new THREE.Mesh(trunkGeo, materials.willowBarkMat);
    trunk.castShadow = true;
    trunk.receiveShadow = true;
    tree.add(trunk);

    // 3 Main spreading boughs
    for (let b = 0; b < 3; b++) {
      const ang = (b / 3) * Math.PI * 2 + 0.4;
      const bx = Math.cos(ang) * 1.45;
      const bz = Math.sin(ang) * 1.45;
      const boughCurve = new THREE.CatmullRomCurve3([
        new THREE.Vector3(0.28, 2.15, -0.05),
        new THREE.Vector3(0.28 + bx * 0.55, 2.85, bz * 0.55),
        new THREE.Vector3(0.28 + bx, 2.55, bz),
      ]);
      const boughGeo = trackGeo(new THREE.TubeGeometry(boughCurve, 10, 0.11, 7, false));
      const bough = new THREE.Mesh(boughGeo, materials.willowBarkMat);
      bough.castShadow = true;
      tree.add(bough);

      // Multi-lobe foliage cluster
      const cluster = new THREE.Mesh(canopyClusterGeo, materials.willowFoliageMat);
      cluster.position.set(0.28 + bx * 0.85, 2.95, bz * 0.85);
      cluster.scale.set(1.25, 0.85, 1.15);
      cluster.castShadow = true;
      cluster.receiveShadow = true;
      tree.add(cluster);

      // Drooping willow frond curtains
      for (let f = 0; f < 6; f++) {
        const fa = (f / 6) * Math.PI * 2;
        const frond = new THREE.Mesh(willowCurtainGeo, materials.willowFoliageMat);
        frond.position.set(
          0.28 + bx * 0.85 + Math.cos(fa) * 0.65,
          2.05,
          bz * 0.85 + Math.sin(fa) * 0.65,
        );
        frond.castShadow = true;
        tree.add(frond);
      }
    }

    // Crown canopy
    const crown = new THREE.Mesh(canopyClusterGeo, materials.willowFoliageMat);
    crown.position.set(0.25, 3.4, -0.05);
    crown.scale.set(1.35, 0.92, 1.3);
    crown.castShadow = true;
    tree.add(crown);

    addContactShadow(tree, 0, 0.02, 0, 2.8);
    group.add(tree);
  }

  function addMapleTree(tx: number, tz: number, scale: number) {
    const ty = groundHeightAt(tx, tz);
    const tree = new THREE.Group();
    tree.position.set(tx, ty, tz);
    tree.scale.setScalar(scale);

    const trunkCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, -0.1, 0),
      new THREE.Vector3(-0.14, 1.0, 0.08),
      new THREE.Vector3(0.06, 2.0, -0.06),
    ]);
    const trunkGeo = trackGeo(new THREE.TubeGeometry(trunkCurve, 10, 0.19, 8, false));
    const trunk = new THREE.Mesh(trunkGeo, materials.willowBarkMat);
    trunk.castShadow = true;
    tree.add(trunk);

    for (const [cx, cy, cz, sx, sy, sz] of [
      [0.05, 2.65, 0, 1.25, 0.72, 1.18],
      [-0.75, 2.25, 0.55, 0.95, 0.6, 0.9],
      [0.82, 2.35, -0.45, 0.92, 0.58, 0.88],
      [0.15, 3.1, 0.25, 0.85, 0.55, 0.82],
    ]) {
      const puff = new THREE.Mesh(canopyClusterGeo, materials.mapleFoliageMat);
      puff.position.set(cx, cy, cz);
      puff.scale.set(sx, sy, sz);
      puff.castShadow = true;
      puff.receiveShadow = true;
      tree.add(puff);
    }
    addContactShadow(tree, 0, 0.02, 0, 2.3);
    group.add(tree);
  }

  // Place graceful perimeter trees framing the pond without obstructing the isometric view!
  addWillowTree(-8.4 * s, -2.5 * s, 1.12);
  addWillowTree(3.1 * s, -6.9 * s, 1.02);
  addMapleTree(-7.6 * s, 4.8 * s, 1.05);
  addMapleTree(9.8 * s, -1.8 * s, 0.95);
  addMapleTree(8.6 * s, 4.8 * s, 1.1);

  // InstancedMesh Meadow Grass Tufts (~380 instances)
  const tuftGeo = trackGeo(new THREE.ConeGeometry(0.055, 0.34, 4));
  tuftGeo.translate(0, 0.17, 0);
  const grassCount = 380;
  const grassInstanced = new THREE.InstancedMesh(tuftGeo, materials.grassTuftMat, grassCount);
  grassInstanced.receiveShadow = true;
  const cGrass = new THREE.Color();
  let gPlaced = 0;

  for (let i = 0; i < 1200 && gPlaced < grassCount; i++) {
    const gx = (rng() - 0.5) * 32 * s;
    const gz = (rng() - 0.5) * 26 * s;
    const sdf = pondSignedDistance(gx, gz);
    if (sdf > 0.55) {
      // Avoid gazebo plinth
      if (Math.hypot(gx - gzX, gz - gzZ) < 2.2) continue;
      const gy = groundHeightAt(gx, gz);
      dummy.position.set(gx, gy - 0.02, gz);
      dummy.rotation.set((rng() - 0.5) * 0.28, rng() * Math.PI * 2, (rng() - 0.5) * 0.28);
      dummy.scale.set(0.8 + rng() * 0.7, 0.75 + rng() * 0.85, 0.8 + rng() * 0.7);
      dummy.updateMatrix();
      grassInstanced.setMatrixAt(gPlaced, dummy.matrix);
      cGrass.setHSL(0.24 + (rng() - 0.5) * 0.05, 0.38 + rng() * 0.14, 0.42 + rng() * 0.16);
      grassInstanced.setColorAt(gPlaced, cGrass);
      gPlaced++;
    }
  }
  grassInstanced.count = gPlaced;
  grassInstanced.instanceMatrix.needsUpdate = true;
  if (grassInstanced.instanceColor) grassInstanced.instanceColor.needsUpdate = true;
  grassInstanced.computeBoundingSphere();
  group.add(grassInstanced);

  // =========================================================================
  // 10. PROGRESSIVE MANOR RENOVATION UPGRADES (Lv.2 -> Lv.9)
  // =========================================================================
  const extraAeratorAxles: THREE.Group[] = [];
  const extraAerators: Array<{ group: THREE.Group; x: number; z: number; phase: number }> = [];
  const floatingWaterLanterns: Array<{ group: THREE.Group; baseY: number; phase: number }> = [];

  // Lv.2+: Second Floating Paddle-Wheel Aerator in East Cove
  if (facilityLevel >= 2) {
    const eastAerator = new THREE.Group();
    const eax = 3.15 * s;
    const eaz = 1.35 * s;
    eastAerator.position.set(eax, WATER_LEVEL + 0.04, eaz);
    eastAerator.rotation.y = -0.52;

    for (const px of [-0.55, 0.55]) {
      const pontoon = new THREE.Mesh(pontoonGeo, materials.ceramicMat);
      pontoon.position.set(px, 0, 0);
      pontoon.castShadow = true;
      eastAerator.add(pontoon);
    }
    for (const fz of [-0.38, 0.38]) {
      const bar = new THREE.Mesh(frameCrossGeo, materials.woodDarkMat);
      bar.position.set(0, 0.13, fz);
      bar.castShadow = true;
      eastAerator.add(bar);
    }
    const motor2 = new THREE.Mesh(motorHousingGeo, materials.brassMat);
    motor2.position.set(0, 0.28, 0);
    motor2.castShadow = true;
    eastAerator.add(motor2);

    const axle2Group = new THREE.Group();
    axle2Group.position.set(0, 0.14, 0);
    axle2Group.add(new THREE.Mesh(axleGeo, materials.brassMat));
    for (const wx of [-0.82, 0.82]) {
      const hub = new THREE.Mesh(hubGeo, materials.woodDarkMat);
      hub.position.x = wx;
      axle2Group.add(hub);
      for (let b = 0; b < 6; b++) {
        const ang = (b / 6) * Math.PI * 2;
        const blade = new THREE.Mesh(bladeGeo, materials.woodDeckMat);
        blade.position.set(wx, Math.cos(ang) * 0.23, Math.sin(ang) * 0.23);
        blade.rotation.x = ang;
        blade.castShadow = true;
        axle2Group.add(blade);
      }
    }
    eastAerator.add(axle2Group);
    group.add(eastAerator);
    extraAeratorAxles.push(axle2Group);
    extraAerators.push({ group: eastAerator, x: eax, z: eaz, phase: 1.8 });
  }

  // Lv.3+: Extra Perimeter Stone Lanterns & Extra Blooming Lotus Clusters
  if (facilityLevel >= 3) {
    for (const [lx, lz] of [
      [-6.85 * s, 0.45 * s],
      [-2.1 * s, -4.4 * s],
      [4.2 * s, 4.15 * s],
    ]) {
      const ly = groundHeightAt(lx, lz);
      const lantern = new THREE.Group();
      lantern.position.set(lx, ly, lz);
      const base = new THREE.Mesh(lanternBaseGeo, materials.graniteMat);
      base.position.y = 0.12;
      base.castShadow = true;
      const stem = new THREE.Mesh(lanternStemGeo, materials.graniteMat);
      stem.position.y = 0.44;
      stem.castShadow = true;
      const chamber = new THREE.Mesh(lanternBoxGeo, materials.lanternGlowMat);
      chamber.position.y = 0.74;
      const cap = new THREE.Mesh(lanternRoofGeo, materials.graniteMat);
      cap.position.y = 0.96;
      cap.castShadow = true;
      lantern.add(base, stem, chamber, cap);
      addContactShadow(lantern, 0, 0.01, 0, 0.75);
      group.add(lantern);
    }

    const extraLotusCoords: Array<{ x: number; z: number; pink: boolean }> = [
      { x: -3.25 * s, z: 2.35 * s, pink: true },
      { x: -1.15 * s, z: 1.95 * s, pink: false },
      { x: 3.45 * s, z: -2.45 * s, pink: true },
    ];
    extraLotusCoords.forEach((lc, idx) => {
      const padGroup = new THREE.Group();
      padGroup.position.set(lc.x, WATER_LEVEL + 0.018, lc.z);
      padGroup.rotation.y = idx * 2.1 + 0.7;
      padGroup.scale.setScalar(0.95);
      const pad = new THREE.Mesh(lotusPadGeo, materials.lotusLeafMat);
      pad.castShadow = true;
      pad.receiveShadow = true;
      padGroup.add(pad);

      const flower = new THREE.Group();
      flower.position.set(0.05, 0.04, 0.04);
      const petalMat = lc.pink ? materials.lotusPetalPinkMat : materials.lotusPetalCreamMat;
      for (let ring = 0; ring < 2; ring++) {
        const count = ring === 0 ? 8 : 6;
        const rDist = ring === 0 ? 0.105 : 0.062;
        const tilt = ring === 0 ? 0.85 : 0.48;
        for (let p = 0; p < count; p++) {
          const ang = (p / count) * Math.PI * 2 + ring * 0.35;
          const petal = new THREE.Mesh(lotusPetalGeo, petalMat);
          petal.position.set(Math.cos(ang) * rDist, 0.06 + ring * 0.025, Math.sin(ang) * rDist);
          petal.rotation.y = -ang + Math.PI / 2;
          petal.rotation.x = tilt;
          flower.add(petal);
        }
      }
      const pod = new THREE.Mesh(lotusPodGeo, materials.lotusCenterMat);
      pod.position.y = 0.075;
      flower.add(pod);
      padGroup.add(flower);
      group.add(padGroup);
      floatingLotusPads.push({ mesh: padGroup, baseY: WATER_LEVEL + 0.018, phase: idx * 1.15 + 3.2 });
    });
  }

  // Lv.4+: Warm Glowing Gazebo Eaves Lanterns & Carved Lakeside Balustrade Posts
  if (facilityLevel >= 4) {
    const eavesLanternGeo = trackGeo(new THREE.CylinderGeometry(0.11, 0.09, 0.24, 10));
    const eavesCapGeo = trackGeo(new THREE.ConeGeometry(0.14, 0.08, 10));
    for (const [ex, ez] of [
      [-1.32, -1.12],
      [1.32, -1.12],
      [-1.32, 1.12],
      [1.32, 1.12],
    ]) {
      const orb = new THREE.Mesh(eavesLanternGeo, materials.lanternGlowMat);
      orb.position.set(ex, 2.22, ez);
      gazeboGroup.add(orb);
      const cap = new THREE.Mesh(eavesCapGeo, materials.brassMat);
      cap.position.set(ex, 2.36, ez);
      gazeboGroup.add(cap);
    }

    const postStoneGeo = trackGeo(new THREE.BoxGeometry(0.18, 0.62, 0.18));
    const capGoldGeo = trackGeo(new THREE.SphereGeometry(0.085, 10, 8));
    for (let i = 0; i < 5; i++) {
      const bx = (-1.6 + i * 1.45) * s;
      const bz = -4.35 * s;
      const by = groundHeightAt(bx, bz);
      if (pondSignedDistance(bx, bz) < 0.2) continue;
      const pMesh = new THREE.Mesh(postStoneGeo, materials.graniteMat);
      pMesh.position.set(bx, by + 0.28, bz);
      pMesh.castShadow = true;
      group.add(pMesh);
      const pCap = new THREE.Mesh(capGoldGeo, materials.brassMat);
      pCap.position.set(bx, by + 0.63, bz);
      group.add(pCap);
    }
  }

  // Lv.5+: Lakeside Scenic Viewing Pier & Bench (`亲水观景挑台`)
  if (facilityLevel >= 5) {
    const pierGroup = new THREE.Group();
    const px = -5.25 * s;
    const pz = 3.55 * s;
    pierGroup.position.set(px, 0.34, pz);
    pierGroup.rotation.y = 0.65;

    const pierPostGeo = trackGeo(new THREE.CylinderGeometry(0.08, 0.095, 1.75, 10));
    for (const [lx, lz] of [
      [-1.35, -0.85],
      [1.35, -0.85],
      [-1.35, 0.85],
      [1.35, 0.85],
    ]) {
      const post = new THREE.Mesh(pierPostGeo, materials.woodDarkMat);
      post.position.set(lx, -0.58, lz);
      post.castShadow = true;
      pierGroup.add(post);
    }

    const pierPlankGeo = trackGeo(new THREE.BoxGeometry(2.95, 0.085, 0.22));
    for (let i = 0; i < 8; i++) {
      const p = new THREE.Mesh(pierPlankGeo, materials.woodDeckMat);
      p.position.set(0, 0, -0.82 + i * 0.235);
      p.castShadow = true;
      p.receiveShadow = true;
      pierGroup.add(p);
    }

    // Carved lakeside wooden bench
    const benchSeatGeo = trackGeo(new THREE.BoxGeometry(1.35, 0.07, 0.38));
    const benchSeat = new THREE.Mesh(benchSeatGeo, materials.woodDeckMat);
    benchSeat.position.set(0, 0.34, 0.32);
    benchSeat.castShadow = true;
    pierGroup.add(benchSeat);

    const benchLegGeo = trackGeo(new THREE.BoxGeometry(0.09, 0.32, 0.32));
    for (const bx of [-0.52, 0.52]) {
      const leg = new THREE.Mesh(benchLegGeo, materials.woodDarkMat);
      leg.position.set(bx, 0.16, 0.32);
      leg.castShadow = true;
      pierGroup.add(leg);
    }

    // Corner brass railing posts
    const cornerPostGeo = trackGeo(new THREE.CylinderGeometry(0.045, 0.052, 0.68, 8));
    const finialGeo = trackGeo(new THREE.SphereGeometry(0.07, 10, 8));
    for (const [rx, rz] of [
      [-1.35, -0.85],
      [1.35, -0.85],
    ]) {
      const rp = new THREE.Mesh(cornerPostGeo, materials.woodDarkMat);
      rp.position.set(rx, 0.36, rz);
      rp.castShadow = true;
      pierGroup.add(rp);
      const rf = new THREE.Mesh(finialGeo, materials.brassMat);
      rf.position.set(rx, 0.74, rz);
      pierGroup.add(rf);
    }
    group.add(pierGroup);
  }

  // Lv.6+: Jade-Gold Ornamental Manor Pillars Flanking the Bridge
  if (facilityLevel >= 6) {
    const pillarBaseGeo = trackGeo(new THREE.BoxGeometry(0.54, 0.32, 0.54));
    const pillarShaftGeo = trackGeo(new THREE.CylinderGeometry(0.16, 0.19, 1.35, 10));
    const orbGeo = trackGeo(new THREE.SphereGeometry(0.16, 12, 10));
    const jadeGlowMat = trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x6ce5c4,
        emissive: 0x2ca889,
        emissiveIntensity: 0.72,
        roughness: 0.22,
        metalness: 0.18,
      }),
    );

    for (const side of [-1, 1]) {
      const px = bridgeCfg.centerX + side * (bridgeHalfW + 0.58);
      const pz = bridgeCfg.centerZ + halfSpan + 0.48;
      const py = groundHeightAt(px, pz);
      const col = new THREE.Group();
      col.position.set(px, py, pz);

      const base = new THREE.Mesh(pillarBaseGeo, materials.graniteMat);
      base.position.y = 0.14;
      base.castShadow = true;
      const shaft = new THREE.Mesh(pillarShaftGeo, materials.graniteMat);
      shaft.position.y = 0.92;
      shaft.castShadow = true;
      const collar = new THREE.Mesh(
        trackGeo(new THREE.CylinderGeometry(0.24, 0.22, 0.1, 10)),
        materials.brassMat,
      );
      collar.position.y = 1.62;
      const orb = new THREE.Mesh(orbGeo, jadeGlowMat);
      orb.position.y = 1.82;
      col.add(base, shaft, collar, orb);
      addContactShadow(col, 0, 0.01, 0, 1.0);
      group.add(col);
    }
  }

  // Lv.7+: Smart Solar Ecological Purifier Tower (`御水智慧净水塔`)
  if (facilityLevel >= 7) {
    const purifierGroup = new THREE.Group();
    const pfx = -4.2 * s;
    const pfz = -4.9 * s;
    const pfy = groundHeightAt(pfx, pfz);
    purifierGroup.position.set(pfx, pfy, pfz);

    const pad = new THREE.Mesh(
      trackGeo(new THREE.CylinderGeometry(0.85, 0.95, 0.24, 12)),
      materials.graniteMat,
    );
    pad.position.y = 0.12;
    pad.castShadow = true;
    pad.receiveShadow = true;
    purifierGroup.add(pad);

    const tank = new THREE.Mesh(
      trackGeo(new THREE.CylinderGeometry(0.42, 0.46, 1.35, 16)),
      materials.ceramicMat,
    );
    tank.position.y = 0.88;
    tank.castShadow = true;
    purifierGroup.add(tank);

    const brassBand = new THREE.Mesh(
      trackGeo(new THREE.TorusGeometry(0.45, 0.04, 8, 24)),
      materials.brassMat,
    );
    brassBand.rotation.x = Math.PI / 2;
    brassBand.position.y = 1.25;
    purifierGroup.add(brassBand);

    const dome = new THREE.Mesh(
      trackGeo(new THREE.ConeGeometry(0.52, 0.36, 16)),
      materials.brassMat,
    );
    dome.position.y = 1.72;
    dome.castShadow = true;
    purifierGroup.add(dome);

    const solarWing = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(0.95, 0.04, 0.58)),
      solarMat,
    );
    solarWing.position.set(0, 2.02, 0);
    solarWing.rotation.x = 0.38;
    solarWing.castShadow = true;
    purifierGroup.add(solarWing);

    addContactShadow(purifierGroup, 0, 0.02, 0, 1.9);
    group.add(purifierGroup);
  }

  // Lv.8+: Floating Illuminated Lotus Water Lanterns (`水榭莲花灯`)
  if (facilityLevel >= 8) {
    const wlBaseGeo = trackGeo(new THREE.CylinderGeometry(0.22, 0.18, 0.05, 10));
    const wlCoreGeo = trackGeo(new THREE.OctahedronGeometry(0.11, 0));
    const waterLanternSpots: Array<[number, number]> = [
      [-3.5 * s, -0.85 * s],
      [-1.35 * s, 0.95 * s],
      [3.95 * s, -0.95 * s],
      [0.45 * s, -1.75 * s],
    ];
    waterLanternSpots.forEach(([wx, wz], idx) => {
      if (pondSignedDistance(wx, wz) > -0.35) return;
      const wl = new THREE.Group();
      wl.position.set(wx, WATER_LEVEL + 0.02, wz);
      const base = new THREE.Mesh(wlBaseGeo, materials.lotusLeafMat);
      const glow = new THREE.Mesh(wlCoreGeo, materials.lanternGlowMat);
      glow.position.y = 0.12;
      wl.add(base, glow);
      group.add(wl);
      floatingWaterLanterns.push({ group: wl, baseY: WATER_LEVEL + 0.02, phase: idx * 1.4 });
    });
  }

  // Lv.9: Grand Manor Ceremonial Archway (`传世水产世家牌楼`)
  if (facilityLevel >= 9) {
    const archGroup = new THREE.Group();
    const ax = bridgeCfg.centerX + 0.35;
    const az = bridgeCfg.centerZ - halfSpan - 1.35;
    const ay = groundHeightAt(ax, az);
    archGroup.position.set(ax, ay, az);
    archGroup.rotation.y = 0.12;

    const archColGeo = trackGeo(new THREE.CylinderGeometry(0.13, 0.16, 2.85, 12));
    const archPlinthGeo = trackGeo(new THREE.BoxGeometry(0.46, 0.32, 0.46));
    for (const sx of [-1.35, 1.35]) {
      const pl = new THREE.Mesh(archPlinthGeo, materials.graniteMat);
      pl.position.set(sx, 0.14, 0);
      pl.castShadow = true;
      const col = new THREE.Mesh(archColGeo, materials.woodDarkMat);
      col.position.set(sx, 1.55, 0);
      col.castShadow = true;
      archGroup.add(pl, col);
      addContactShadow(archGroup, sx, 0.01, 0, 0.95);
    }

    const lintel = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(3.4, 0.22, 0.24)),
      materials.woodDarkMat,
    );
    lintel.position.set(0, 2.68, 0);
    lintel.castShadow = true;
    archGroup.add(lintel);

    const plaque = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(1.15, 0.38, 0.12)),
      materials.brassMat,
    );
    plaque.position.set(0, 2.98, 0.06);
    plaque.castShadow = true;
    archGroup.add(plaque);

    const archRoof = new THREE.Mesh(
      trackGeo(new THREE.ConeGeometry(2.35, 0.72, 4)),
      materials.thatchMat,
    );
    archRoof.rotation.y = Math.PI / 4;
    archRoof.scale.set(1.38, 0.9, 0.62);
    archRoof.position.set(0, 3.38, 0);
    archRoof.castShadow = true;
    archGroup.add(archRoof);

    const ridgeFinial = new THREE.Mesh(
      trackGeo(new THREE.SphereGeometry(0.14, 10, 8)),
      materials.brassMat,
    );
    ridgeFinial.position.set(0, 3.76, 0);
    archGroup.add(ridgeFinial);

    group.add(archGroup);
  }

  let splashTimer = 0;

  function update(dt: number, elapsed: number) {
    // Rotate paddle-wheel aerators smoothly & bob gently on water
    paddleAxleGroup.rotation.x -= dt * 3.6;
    aeratorGroup.position.y = WATER_LEVEL + 0.04 + Math.sin(elapsed * 2.2) * 0.012;

    for (const ax of extraAeratorAxles) {
      ax.rotation.x -= dt * 3.4;
    }
    for (const ea of extraAerators) {
      ea.group.position.y = WATER_LEVEL + 0.04 + Math.sin(elapsed * 2.2 + ea.phase) * 0.012;
    }

    // Bob water quality buoy gently
    buoyGroup.position.y = WATER_LEVEL + Math.sin(elapsed * 1.8 + 1.2) * 0.018;
    buoyGroup.rotation.z = Math.sin(elapsed * 1.4) * 0.04;
    buoyGroup.rotation.x = Math.cos(elapsed * 1.1) * 0.035;

    // Gentle bobbing of floating lotus pads & lotus lanterns
    for (const lp of floatingLotusPads) {
      lp.mesh.position.y = lp.baseY + Math.sin(elapsed * 1.4 + lp.phase) * 0.008;
    }
    for (const wl of floatingWaterLanterns) {
      wl.group.position.y = wl.baseY + Math.sin(elapsed * 1.6 + wl.phase) * 0.011;
      wl.group.rotation.y = elapsed * 0.25 + wl.phase;
    }

    // Periodic gentle splash ripple at bamboo spring spout & paddle aerators
    splashTimer -= dt;
    if (splashTimer <= 0) {
      materials.pushRipple(-4.95 * s, -2.25 * s, elapsed, 0.55); // Bamboo waterfall landing zone
      materials.pushRipple(-3.9 * s, -2.4 * s, elapsed, 0.42);   // Paddle aerator ripples
      for (const ea of extraAerators) {
        materials.pushRipple(ea.x, ea.z, elapsed, 0.38);
      }
      splashTimer = 1.45;
    }
  }

  return {
    group,
    update,
    dispose: () => {
      ownedGeometries.forEach((g) => g.dispose());
      ownedMaterials.forEach((m) => m.dispose());
    },
  };
}
