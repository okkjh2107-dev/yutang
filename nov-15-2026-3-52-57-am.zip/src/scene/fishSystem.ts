import * as THREE from 'three';
import { computeFishScaleFactor } from '../game/simulation';
import type { FishLiveState, ManagedFish } from '../types/pond';
import { WATER_LEVEL, getPondVisualScale, groundHeightAt, pondSignedDistance } from './constants';
import { createFishAssetLibrary, type FishRig } from './fishFactory';
import type { MaterialBundle } from './materials';
import type { TextureBundle } from './textures';

interface FishAgent {
  fish: ManagedFish;
  rig: FishRig;
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  speed: number;
  targetSpeed: number;
  targetScale: number;
  currentScale: number;
  targetX: number;
  targetZ: number;
  targetY: number;
  swimPhase: number;
  turnBend: number;
  waypointTimer: number;
  surgeTimer: number;
  rippleCooldown: number;
  activity: FishLiveState['activity'];
}

export interface FishSystem {
  group: THREE.Group;
  hitMeshes: THREE.Object3D[];
  syncFishes: (fishes: ManagedFish[], withSplashForNew?: boolean) => void;
  triggerFeedingBurst: () => void;
  update: (dt: number, elapsed: number) => void;
  setSelectedFish: (fishId: string | null) => void;
  getFishLiveState: (fishId: string) => FishLiveState | null;
  dispose: () => void;
}

function getObstacleZones(): Array<{ x: number; z: number; r: number }> {
  const s = getPondVisualScale();
  return [
    { x: 0.78 * s, z: -1.8 * s, r: 0.55 },
    { x: 2.12 * s, z: -1.8 * s, r: 0.55 },
    { x: 0.78 * s, z: 2.3 * s, r: 0.55 },
    { x: 2.12 * s, z: 2.3 * s, r: 0.55 },
    { x: -3.9 * s, z: -2.4 * s, r: 1.1 },
    { x: 4.8 * s, z: -1.6 * s, r: 0.6 },
  ];
}

function wrapAngle(angle: number): number {
  let a = angle;
  while (a > Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
}

function findValidPondPoint(seedOffset: number): { x: number; z: number } {
  const s = getPondVisualScale();
  const obstacles = getObstacleZones();
  for (let attempt = 0; attempt < 40; attempt++) {
    const angle = (seedOffset * 2.39996 + attempt * 1.17) % (Math.PI * 2);
    const radius = (1.1 + ((attempt * 0.37 + seedOffset * 0.19) % 1) * 5.2) * s;
    const x = Math.cos(angle) * radius * 1.15;
    const z = Math.sin(angle) * radius * 0.75;
    const sdf = pondSignedDistance(x, z);
    if (sdf < -1.05) {
      let clear = true;
      for (const obs of obstacles) {
        if (Math.hypot(x - obs.x, z - obs.z) < obs.r + 0.45) {
          clear = false;
          break;
        }
      }
      if (clear) return { x, z };
    }
  }
  return { x: -2.5 * s, z: 0.2 * s };
}

export function createFishSystem(
  textures: TextureBundle,
  materials: MaterialBundle,
  initialFishes: ManagedFish[],
): FishSystem {
  const assetLib = createFishAssetLibrary(textures);
  const group = new THREE.Group();
  group.name = 'fish-school';

  const agents: FishAgent[] = [];
  const hitMeshes: THREE.Object3D[] = [];
  const agentMap = new Map<string, FishAgent>();

  // Selection indicator ring hovering gently over selected fish
  const ringGeo = new THREE.RingGeometry(0.42, 0.52, 36);
  ringGeo.rotateX(-Math.PI / 2);
  const selectionRing = new THREE.Mesh(ringGeo, materials.selectionRingMat);
  selectionRing.visible = false;
  selectionRing.renderOrder = 4;
  group.add(selectionRing);

  let selectedFishId: string | null = null;
  let spawnCounter = 1;
  let currentElapsed = 0;

  function rebuildHitMeshes() {
    hitMeshes.length = 0;
    for (const a of agents) {
      hitMeshes.push(a.rig.hitProxy);
    }
  }

  function addAgent(fish: ManagedFish, withSplash: boolean) {
    const idx = spawnCounter++;
    const scaleFactor = computeFishScaleFactor(fish);
    const rig = assetLib.createFishRig({
      id: fish.id,
      category: fish.category,
      patternId: fish.patternId,
      scaleFactor,
    });

    const spawn = findValidPondPoint(idx);
    const bedY = groundHeightAt(spawn.x, spawn.z);
    const safeY = THREE.MathUtils.clamp(fish.preferredDepth, bedY + 0.28, WATER_LEVEL - 0.16);
    const wp = findValidPondPoint(idx + 11);

    const agent: FishAgent = {
      fish,
      rig,
      x: spawn.x,
      y: safeY,
      z: spawn.z,
      yaw: (idx * 1.37) % (Math.PI * 2),
      pitch: 0,
      speed: fish.baseSpeed,
      targetSpeed: fish.baseSpeed,
      targetScale: scaleFactor,
      currentScale: scaleFactor,
      targetX: wp.x,
      targetZ: wp.z,
      targetY: safeY,
      swimPhase: idx * 1.15,
      turnBend: 0,
      waypointTimer: 2 + (idx % 5) * 1.4,
      surgeTimer: 4 + (idx % 4) * 2.1,
      rippleCooldown: 1 + (idx % 3) * 0.8,
      activity: fish.speciesId === 'common_carp' ? '中层洄游' : '悠然巡游',
    };

    rig.root.position.set(agent.x, agent.y, agent.z);
    rig.root.rotation.y = agent.yaw;
    group.add(rig.root);
    agents.push(agent);
    agentMap.set(fish.id, agent);

    if (withSplash) {
      materials.pushRipple(agent.x, agent.z, currentElapsed, 0.95);
    }
  }

  const MAX_VISIBLE_3D_FISH = 56;

  function pickVisibleSubset(fishes: ManagedFish[]): ManagedFish[] {
    if (fishes.length <= MAX_VISIBLE_3D_FISH) return fishes;
    const picked: ManagedFish[] = [];
    const seen = new Set<string>();
    if (selectedFishId) {
      const sel = fishes.find((f) => f.id === selectedFishId);
      if (sel) {
        picked.push(sel);
        seen.add(sel.id);
      }
    }
    const step = fishes.length / MAX_VISIBLE_3D_FISH;
    for (let k = 0; picked.length < MAX_VISIBLE_3D_FISH && k < fishes.length; k++) {
      const candidate = fishes[Math.min(fishes.length - 1, Math.floor(k * step))];
      if (!seen.has(candidate.id)) {
        seen.add(candidate.id);
        picked.push(candidate);
      }
    }
    return picked;
  }

  function syncFishes(fishes: ManagedFish[], withSplashForNew = false) {
    const visibleFishes = pickVisibleSubset(fishes);
    const incomingIds = new Set(visibleFishes.map((f) => f.id));

    // Remove sold/harvested fish from 3D scene
    for (let i = agents.length - 1; i >= 0; i--) {
      const a = agents[i];
      if (!incomingIds.has(a.fish.id)) {
        if (selectedFishId === a.fish.id) {
          selectedFishId = null;
          selectionRing.visible = false;
        }
        group.remove(a.rig.root);
        a.rig.dispose();
        agentMap.delete(a.fish.id);
        agents.splice(i, 1);
      }
    }

    // Update existing or spawn newly bought/bred fish
    for (const fish of visibleFishes) {
      const existing = agentMap.get(fish.id);
      if (existing) {
        existing.fish = fish;
        existing.targetScale = computeFishScaleFactor(fish);
      } else {
        addAgent(fish, withSplashForNew);
      }
    }

    rebuildHitMeshes();
  }

  function triggerFeedingBurst() {
    const s = getPondVisualScale();
    // Feeding zone near the wooden feeding dock
    const feedSpots: Array<[number, number]> = [
      [3.8 * s, 1.8 * s],
      [3.2 * s, 1.3 * s],
      [4.2 * s, 1.1 * s],
      [2.8 * s, 2.0 * s],
    ];
    feedSpots.forEach(([fx, fz], i) => {
      materials.pushRipple(fx, fz, currentElapsed + i * 0.08, 1.05);
    });

    // Steer fish toward feeding zone excitedly
    for (let i = 0; i < agents.length; i++) {
      const a = agents[i];
      const spot = feedSpots[i % feedSpots.length];
      a.targetX = spot[0] + Math.cos(i * 1.9) * 0.85;
      a.targetZ = spot[1] + Math.sin(i * 1.9) * 0.75;
      a.targetY = -0.18;
      a.targetSpeed = a.fish.baseSpeed * 1.55;
      a.waypointTimer = 4.2;
    }
  }

  // Initial sync
  syncFishes(initialFishes, false);

  function update(dt: number, elapsed: number) {
    currentElapsed = elapsed;
    const clampedDt = Math.min(dt, 0.05);

    for (let i = 0; i < agents.length; i++) {
      const a = agents[i];

      // Smoothly grow/shrink 3D fish size as weight changes
      if (Math.abs(a.currentScale - a.targetScale) > 0.002) {
        a.currentScale = THREE.MathUtils.damp(a.currentScale, a.targetScale, 3.0, clampedDt);
        a.rig.root.scale.setScalar(a.currentScale);
      }

      // 1. Waypoint & playful speed surge scheduling
      a.waypointTimer -= clampedDt;
      a.surgeTimer -= clampedDt;
      a.rippleCooldown -= clampedDt;

      const distToTarget = Math.hypot(a.targetX - a.x, a.targetZ - a.z);
      if (a.waypointTimer <= 0 || distToTarget < 1.15) {
        const nextWp = findValidPondPoint(Math.floor(elapsed * 3.1) + i * 7);
        a.targetX = nextWp.x;
        a.targetZ = nextWp.z;
        const bedAtWp = groundHeightAt(nextWp.x, nextWp.z);
        const depthOffset = Math.sin(elapsed * 0.7 + i) * 0.16;
        a.targetY = THREE.MathUtils.clamp(
          a.fish.preferredDepth + depthOffset,
          bedAtWp + 0.28,
          WATER_LEVEL - 0.16,
        );
        a.waypointTimer = 3.5 + ((i * 1.7 + elapsed) % 4.5);
      }

      if (a.surgeTimer <= 0) {
        const isBurst = ((Math.floor(elapsed) + i) % 3) === 0;
        const healthSpeedFactor = 0.65 + (a.fish.health / 100) * 0.4;
        a.targetSpeed = a.fish.baseSpeed * healthSpeedFactor * (isBurst ? 1.45 : 0.88);
        a.surgeTimer = 2.8 + ((i * 1.3) % 3.5);
      }

      // 2. Desired steering vector toward waypoint
      let steerX = a.targetX - a.x;
      let steerZ = a.targetZ - a.z;
      const steerLen = Math.hypot(steerX, steerZ) || 1;
      steerX /= steerLen;
      steerZ /= steerLen;

      // 3. Soft boundary avoidance using numerical SDF gradient
      const lookAheadX = a.x + Math.cos(a.yaw) * 0.95;
      const lookAheadZ = a.z - Math.sin(a.yaw) * 0.95;
      const sdfAhead = pondSignedDistance(lookAheadX, lookAheadZ);
      if (sdfAhead > -0.95) {
        const eps = 0.25;
        const gx =
          (pondSignedDistance(lookAheadX + eps, lookAheadZ) -
            pondSignedDistance(lookAheadX - eps, lookAheadZ)) /
          (2 * eps);
        const gz =
          (pondSignedDistance(lookAheadX, lookAheadZ + eps) -
            pondSignedDistance(lookAheadX, lookAheadZ - eps)) /
          (2 * eps);
        const gLen = Math.hypot(gx, gz) || 1;
        const urgency = THREE.MathUtils.clamp((sdfAhead + 0.95) * 2.4, 0, 3.2);
        steerX -= (gx / gLen) * urgency;
        steerZ -= (gz / gLen) * urgency;
      }

      // 4. Obstacle avoidance (bridge pilings & aerator pontoons)
      for (const obs of getObstacleZones()) {
        const dx = a.x - obs.x;
        const dz = a.z - obs.z;
        const d = Math.hypot(dx, dz);
        if (d < obs.r + 0.85 && d > 0.001) {
          const push = ((obs.r + 0.85 - d) / 0.85) * 2.4;
          steerX += (dx / d) * push;
          steerZ += (dz / d) * push;
        }
      }

      // 5. Gentle fish-to-fish separation
      for (let j = 0; j < agents.length; j++) {
        if (i === j) continue;
        const b = agents[j];
        const dx = a.x - b.x;
        const dz = a.z - b.z;
        const dy = a.y - b.y;
        const dSq = dx * dx + dz * dz + dy * dy * 2.0;
        if (dSq < 1.25 && dSq > 0.0001) {
          const d = Math.sqrt(dSq);
          const sep = (1.12 - d) * 1.65;
          steerX += (dx / d) * sep;
          steerZ += (dz / d) * sep;
        }
      }

      const desiredYaw = Math.atan2(-steerZ, steerX);
      const yawDiff = wrapAngle(desiredYaw - a.yaw);
      const maxTurnRate = 1.95;
      const yawDelta = THREE.MathUtils.clamp(yawDiff * 2.4, -maxTurnRate, maxTurnRate) * clampedDt;
      a.yaw = wrapAngle(a.yaw + yawDelta);

      // Smooth speed & vertical depth glide
      a.speed = THREE.MathUtils.damp(a.speed, a.targetSpeed, 2.2, clampedDt);
      const stepDist = a.speed * clampedDt;
      const nextX = a.x + Math.cos(a.yaw) * stepDist;
      const nextZ = a.z - Math.sin(a.yaw) * stepDist;

      if (pondSignedDistance(nextX, nextZ) < -0.52) {
        a.x = nextX;
        a.z = nextZ;
      } else {
        a.yaw = wrapAngle(a.yaw + Math.PI * 0.45 * clampedDt * 5);
      }

      const bedY = groundHeightAt(a.x, a.z);
      const clampedTargetY = THREE.MathUtils.clamp(a.targetY, bedY + 0.26, WATER_LEVEL - 0.15);
      const prevY = a.y;
      a.y = THREE.MathUtils.damp(a.y, clampedTargetY, 1.6, clampedDt);
      const vy = (a.y - prevY) / Math.max(clampedDt, 0.001);
      a.pitch = THREE.MathUtils.damp(a.pitch, THREE.MathUtils.clamp(vy * 0.35, -0.28, 0.28), 4.0, clampedDt);

      if (Math.abs(yawDiff) > 0.55) {
        a.activity = '敏捷转向';
      } else if (a.y > -0.26) {
        a.activity = '浅滩觅食';
      } else if (a.fish.category === 'edible') {
        a.activity = '中层洄游';
      } else {
        a.activity = '悠然巡游';
      }

      if (a.y > -0.24 && a.rippleCooldown <= 0) {
        materials.pushRipple(a.x, a.z, elapsed, 0.32);
        a.rippleCooldown = 2.6 + (i % 4) * 1.1;
      }

      const tailFreq = 4.6 + a.speed * 4.4;
      a.swimPhase += clampedDt * tailFreq;
      const targetTurnBend = THREE.MathUtils.clamp(yawDiff * 0.85, -0.9, 0.9);
      a.turnBend = THREE.MathUtils.damp(a.turnBend, targetTurnBend, 5.5, clampedDt);

      a.rig.root.position.set(a.x, a.y, a.z);
      a.rig.root.rotation.set(0, a.yaw, a.pitch);

      a.rig.updateSwimUniforms(a.swimPhase, a.turnBend);

      const tailDist = 0.52 - -0.5;
      const tailFlex = Math.pow(tailDist / 1.04, 1.55);
      const tailSpineZ =
        Math.sin(tailDist * 5.2 - a.swimPhase) * 0.068 * tailFlex +
        a.turnBend * Math.pow(tailDist, 1.7) * 0.42;
      a.rig.caudalFin.position.z = tailSpineZ;
      a.rig.caudalFin.rotation.y =
        Math.sin(a.swimPhase - 1.35) * 0.42 + a.turnBend * 0.52;

      const dorsalDist = 0.52 - -0.04;
      const dorsalFlex = Math.pow(dorsalDist / 1.04, 1.55);
      const dorsalSpineZ =
        Math.sin(dorsalDist * 5.2 - a.swimPhase) * 0.068 * dorsalFlex +
        a.turnBend * Math.pow(dorsalDist, 1.7) * 0.42;
      a.rig.dorsalFin.position.z = dorsalSpineZ;
      a.rig.dorsalFin.rotation.y = -a.turnBend * 0.24;
      a.rig.dorsalFin.rotation.z = Math.sin(a.swimPhase - 0.65) * 0.08;

      a.rig.pectoralL.rotation.y = -0.34 + Math.sin(a.swimPhase * 0.72) * 0.24;
      a.rig.pectoralR.rotation.y = 0.34 - Math.sin(a.swimPhase * 0.72 + 0.35) * 0.24;
    }

    if (selectedFishId) {
      const sel = agentMap.get(selectedFishId);
      if (sel) {
        selectionRing.visible = true;
        selectionRing.position.set(sel.x, WATER_LEVEL + 0.03, sel.z);
        const pulseScale = 1.0 + Math.sin(elapsed * 3.0) * 0.06;
        selectionRing.scale.setScalar(pulseScale * sel.currentScale);
      } else {
        selectionRing.visible = false;
      }
    } else {
      selectionRing.visible = false;
    }
  }

  function setSelectedFish(fishId: string | null) {
    if (selectedFishId) {
      const prev = agentMap.get(selectedFishId);
      prev?.rig.setHighlight(false);
    }
    selectedFishId = fishId;
    if (fishId) {
      const next = agentMap.get(fishId);
      next?.rig.setHighlight(true);
    }
  }

  function getFishLiveState(fishId: string): FishLiveState | null {
    const agent = agentMap.get(fishId);
    if (!agent) return null;
    return {
      fish: agent.fish,
      activity: agent.activity,
      speedCmPerSec: Math.round(agent.speed * 26),
      depthMeters: Number(Math.abs(agent.y).toFixed(2)),
    };
  }

  return {
    group,
    hitMeshes,
    syncFishes,
    triggerFeedingBurst,
    update,
    setSelectedFish,
    getFishLiveState,
    dispose: () => {
      ringGeo.dispose();
      agents.forEach((a) => a.rig.dispose());
      assetLib.dispose();
    },
  };
}
