import * as THREE from 'three';
import type { TextureBundle } from './textures';

export interface RippleEvent {
  x: number;
  z: number;
  startTime: number;
  strength: number;
}

export interface MaterialBundle {
  terrainMat: THREE.MeshStandardMaterial;
  waterMat: THREE.MeshPhysicalMaterial;
  woodDeckMat: THREE.MeshStandardMaterial;
  woodDarkMat: THREE.MeshStandardMaterial;
  bambooMat: THREE.MeshStandardMaterial;
  thatchMat: THREE.MeshStandardMaterial;
  graniteMat: THREE.MeshStandardMaterial;
  wetRockMat: THREE.MeshStandardMaterial;
  brassMat: THREE.MeshStandardMaterial;
  ceramicMat: THREE.MeshStandardMaterial;
  lanternGlowMat: THREE.MeshStandardMaterial;
  lotusLeafMat: THREE.MeshPhysicalMaterial;
  lotusPetalPinkMat: THREE.MeshStandardMaterial;
  lotusPetalCreamMat: THREE.MeshStandardMaterial;
  lotusCenterMat: THREE.MeshStandardMaterial;
  waterweedMat: THREE.MeshStandardMaterial;
  cattailLeafMat: THREE.MeshStandardMaterial;
  cattailHeadMat: THREE.MeshStandardMaterial;
  willowBarkMat: THREE.MeshStandardMaterial;
  willowFoliageMat: THREE.MeshStandardMaterial;
  mapleFoliageMat: THREE.MeshStandardMaterial;
  grassTuftMat: THREE.MeshStandardMaterial;
  contactShadowMat: THREE.MeshBasicMaterial;
  springWaterStreamMat: THREE.MeshPhysicalMaterial;
  selectionRingMat: THREE.MeshBasicMaterial;
  updateTime: (elapsed: number) => void;
  pushRipple: (x: number, z: number, time: number, strength?: number) => void;
  dispose: () => void;
}

const MAX_RIPPLES = 8;

export function createMaterialBundle(textures: TextureBundle): MaterialBundle {
  const animatedShaders: Array<{ uniforms: Record<string, THREE.IUniform> }> = [];
  const rippleArray: THREE.Vector4[] = Array.from(
    { length: MAX_RIPPLES },
    () => new THREE.Vector4(0, 0, -999, 0),
  );
  let rippleCursor = 0;

  // 1. Terrain with submerged underwater caustics + damp shoreline sheen
  const terrainMat = new THREE.MeshStandardMaterial({
    map: textures.meadowMap,
    bumpMap: textures.meadowBump,
    bumpScale: 0.08,
    vertexColors: true,
    roughness: 0.9,
    metalness: 0.02,
  });

  terrainMat.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = { value: 0 };
    animatedShaders.push(shader);

    shader.vertexShader =
      `varying vec3 vTerrainWorldPos;\n` +
      shader.vertexShader.replace(
        '#include <worldpos_vertex>',
        `
        #include <worldpos_vertex>
        vTerrainWorldPos = (modelMatrix * vec4(transformed, 1.0)).xyz;
        `,
      );

    shader.fragmentShader =
      `uniform float uTime;\nvarying vec3 vTerrainWorldPos;\n` +
      shader.fragmentShader
        .replace(
          '#include <color_fragment>',
          `
          #include <color_fragment>
          // Damp shoreline darkening right near waterline
          float shoreWet = 1.0 - smoothstep(0.0, 0.22, abs(vTerrainWorldPos.y));
          diffuseColor.rgb = mix(diffuseColor.rgb, diffuseColor.rgb * vec3(0.68, 0.71, 0.69), shoreWet * 0.65);

          // Underwater sunlit caustics on pond bed
          if (vTerrainWorldPos.y < -0.02) {
            float depthFade = smoothstep(-0.02, -0.24, vTerrainWorldPos.y) * smoothstep(-2.3, -0.35, vTerrainWorldPos.y);
            vec2 p = vTerrainWorldPos.xz * 1.45;
            float c1 = sin(p.x * 2.1 + uTime * 1.35 + cos(p.y * 1.8 - uTime * 1.1));
            float c2 = cos(p.y * 2.3 - uTime * 1.25 + sin(p.x * 1.9 + uTime * 0.95));
            float caustic = pow(clamp((c1 * c2) * 0.5 + 0.5, 0.0, 1.0), 4.0);
            diffuseColor.rgb += vec3(0.18, 0.34, 0.30) * caustic * depthFade * 0.85;
          }
          `,
        )
        .replace(
          '#include <roughnessmap_fragment>',
          `
          #include <roughnessmap_fragment>
          float wetZone = 1.0 - smoothstep(-0.05, 0.20, vTerrainWorldPos.y);
          roughnessFactor = mix(roughnessFactor, 0.28, wetZone * 0.7);
          `,
        );
  };
  terrainMat.customProgramCacheKey = () => 'manor-terrain-caustics-v1';

  // 2. Dynamic Pond Water (Physical clearcoat + vertex/normal waves + interactive ripples + depth color)
  const waterMat = new THREE.MeshPhysicalMaterial({
    color: 0xffffff,
    transparent: true,
    opacity: 0.85,
    depthWrite: false,
    roughness: 0.06,
    metalness: 0.06,
    clearcoat: 1.0,
    clearcoatRoughness: 0.04,
    ior: 1.333,
    envMapIntensity: 1.45,
    side: THREE.FrontSide,
  });

  waterMat.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = { value: 0 };
    shader.uniforms.uRipples = { value: rippleArray };
    animatedShaders.push(shader);

    shader.vertexShader =
      `
      attribute float aWaterDepth;
      uniform float uTime;
      uniform vec4 uRipples[${MAX_RIPPLES}];
      varying float vWaterDepth;
      varying vec3 vWaterWorldPos;
      varying float vRippleGlow;
      varying vec2 vWaveSlope;

      void evalWaterSurface(vec2 xz, float depth, out float heightOut, out vec2 slopeOut, out float glowOut) {
        float edgeMask = smoothstep(0.0, 0.28, depth);
        float t = uTime;

        // Layered natural pond wavelets
        float w1 = sin(xz.x * 1.65 + xz.y * 1.15 + t * 1.55);
        float w2 = cos(xz.x * 2.45 - xz.y * 1.95 + t * 1.95);
        float w3 = sin(xz.x * 4.10 + xz.y * 3.20 - t * 2.40);

        heightOut = (w1 * 0.015 + w2 * 0.011 + w3 * 0.005) * edgeMask;

        float dx = (cos(xz.x * 1.65 + xz.y * 1.15 + t * 1.55) * 1.65 * 0.015
                 - sin(xz.x * 2.45 - xz.y * 1.95 + t * 1.95) * 2.45 * 0.011
                 + cos(xz.x * 4.10 + xz.y * 3.20 - t * 2.40) * 4.10 * 0.005);
        float dz = (cos(xz.x * 1.65 + xz.y * 1.15 + t * 1.55) * 1.15 * 0.015
                 + sin(xz.x * 2.45 - xz.y * 1.95 + t * 1.95) * 1.95 * 0.011
                 + cos(xz.x * 4.10 + xz.y * 3.20 - t * 2.40) * 3.20 * 0.005);

        glowOut = 0.0;

        // Interactive click & fish swim ripples
        for (int i = 0; i < ${MAX_RIPPLES}; i++) {
          vec4 rp = uRipples[i];
          float age = t - rp.z;
          if (age > 0.0 && age < 4.5 && rp.w > 0.001) {
            vec2 diff = xz - rp.xy;
            float dist = length(diff);
            float radius = age * 1.85;
            float ringDist = dist - radius;
            float envelope = exp(-ringDist * ringDist * 3.8) * exp(-age * 0.72) * rp.w;
            float ringWave = sin(ringDist * 14.0);
            heightOut += ringWave * envelope * 0.025 * edgeMask;
            vec2 dir = dist > 0.001 ? diff / dist : vec2(0.0);
            float dRing = cos(ringDist * 14.0) * 14.0 * envelope * 0.025;
            dx += dir.x * dRing;
            dz += dir.y * dRing;
            glowOut += clamp(envelope * 1.4, 0.0, 1.0);
          }
        }

        slopeOut = vec2(dx, dz) * edgeMask;
      }
      ` +
      shader.vertexShader.replace(
        '#include <begin_vertex>',
        `
        #include <begin_vertex>
        vec4 worldPre = modelMatrix * vec4(transformed, 1.0);
        float wHeight;
        vec2 wSlope;
        float rGlow;
        evalWaterSurface(worldPre.xz, aWaterDepth, wHeight, wSlope, rGlow);
        transformed.y += wHeight;
        vWaterDepth = aWaterDepth;
        vWaterWorldPos = (modelMatrix * vec4(transformed, 1.0)).xyz;
        vWaveSlope = wSlope;
        vRippleGlow = rGlow;
        `,
      );

    shader.fragmentShader =
      `
      uniform float uTime;
      varying float vWaterDepth;
      varying vec3 vWaterWorldPos;
      varying float vRippleGlow;
      varying vec2 vWaveSlope;
      ` +
      shader.fragmentShader
        .replace(
          '#include <normal_fragment_maps>',
          `
          #include <normal_fragment_maps>
          // Perturb view-space normal with high-frequency micro-ripples for sparkling specular highlights
          float microX = cos(vWaterWorldPos.x * 7.5 + uTime * 2.1) * sin(vWaterWorldPos.z * 6.8 - uTime * 1.7) * 0.048;
          float microZ = sin(vWaterWorldPos.x * 6.4 - uTime * 1.9) * cos(vWaterWorldPos.z * 7.9 + uTime * 2.3) * 0.048;
          vec3 worldWaveN = normalize(vec3(-(vWaveSlope.x * 2.5 + microX), 1.0, -(vWaveSlope.y * 2.5 + microZ)));
          vec3 viewWaveN = normalize((viewMatrix * vec4(worldWaveN, 0.0)).xyz);
          normal = normalize(mix(normal, viewWaveN, 0.88));
          `,
        )
        .replace(
          '#include <clearcoat_normal_fragment_maps>',
          `
          #include <clearcoat_normal_fragment_maps>
          #ifdef USE_CLEARCOAT
            clearcoatNormal = normalize(mix(clearcoatNormal, viewWaveN, 0.88));
          #endif
          `,
        )
        .replace(
          '#include <color_fragment>',
          `
          #include <color_fragment>
          if (vWaterDepth <= 0.002) discard;

          // Depth-driven natural color gradient: clear jade shallows -> celadon mid -> deep sapphire-teal
          vec3 shallowCol = vec3(0.46, 0.78, 0.71);
          vec3 midCol     = vec3(0.15, 0.50, 0.49);
          vec3 deepCol    = vec3(0.06, 0.28, 0.33);

          float tMid = smoothstep(0.05, 0.65, vWaterDepth);
          float tDeep = smoothstep(0.60, 1.65, vWaterDepth);
          vec3 waterCol = mix(shallowCol, midCol, tMid);
          waterCol = mix(waterCol, deepCol, tDeep);

          // Delicate shoreline meniscus highlight
          float shoreEdge = 1.0 - smoothstep(0.0, 0.14, vWaterDepth);
          float foamNoise = 0.5 + 0.5 * sin(vWaterWorldPos.x * 6.0 + uTime * 1.6) * cos(vWaterWorldPos.z * 6.0 - uTime * 1.4);
          waterCol = mix(waterCol, vec3(0.88, 0.96, 0.94), shoreEdge * (0.28 + 0.22 * foamNoise));

          // Interactive ripple crest sheen
          waterCol += vec3(0.30, 0.44, 0.42) * clamp(vRippleGlow * 0.55, 0.0, 0.45);

          // Fresnel sky tint
          vec3 viewDirW = normalize(cameraPosition - vWaterWorldPos);
          float fresnel = pow(1.0 - clamp(dot(viewDirW, vec3(0.0, 1.0, 0.0)), 0.0, 1.0), 2.5);
          waterCol = mix(waterCol, vec3(0.76, 0.89, 0.93), fresnel * 0.48);

          diffuseColor.rgb = waterCol;
          float baseAlpha = mix(0.24, 0.74, smoothstep(0.03, 1.45, vWaterDepth));
          diffuseColor.a = clamp(baseAlpha + fresnel * 0.18 + vRippleGlow * 0.14, 0.18, 0.88);
          `,
        );
  };
  waterMat.customProgramCacheKey = () => 'manor-pond-water-v1';

  // 3. Structural Wood, Stone, Brass & Architectural Materials
  const woodDeckMat = new THREE.MeshStandardMaterial({
    map: textures.woodDeckMap,
    bumpMap: textures.woodDeckBump,
    bumpScale: 0.04,
    roughness: 0.78,
    metalness: 0.02,
  });

  const woodDarkMat = new THREE.MeshStandardMaterial({
    map: textures.woodDarkMap,
    bumpMap: textures.woodDeckBump,
    bumpScale: 0.035,
    roughness: 0.84,
    metalness: 0.03,
  });

  const bambooMat = new THREE.MeshStandardMaterial({
    map: textures.bambooMap,
    roughness: 0.52,
    metalness: 0.04,
  });

  const thatchMat = new THREE.MeshStandardMaterial({
    map: textures.thatchShingleMap,
    roughness: 0.92,
    metalness: 0.0,
  });

  const graniteMat = new THREE.MeshStandardMaterial({
    map: textures.graniteMap,
    bumpMap: textures.graniteBump,
    bumpScale: 0.07,
    roughness: 0.86,
    metalness: 0.04,
  });

  const wetRockMat = new THREE.MeshStandardMaterial({
    map: textures.graniteMap,
    bumpMap: textures.graniteBump,
    bumpScale: 0.06,
    color: 0xb7c2bc,
    roughness: 0.38,
    metalness: 0.08,
  });

  const brassMat = new THREE.MeshStandardMaterial({
    color: 0xd1a453,
    roughness: 0.26,
    metalness: 0.88,
    envMapIntensity: 1.25,
  });

  const ceramicMat = new THREE.MeshStandardMaterial({
    color: 0x3b6e6c,
    roughness: 0.24,
    metalness: 0.08,
    envMapIntensity: 1.1,
  });

  const lanternGlowMat = new THREE.MeshStandardMaterial({
    color: 0xffe4a3,
    emissive: 0xffb347,
    emissiveIntensity: 0.95,
    roughness: 0.4,
  });

  // 4. Botanical Materials (Lotus, Aquatic Plants, Trees, Grass)
  const lotusLeafMat = new THREE.MeshPhysicalMaterial({
    map: textures.lotusLeafMap,
    roughness: 0.42,
    metalness: 0.02,
    clearcoat: 0.35,
    clearcoatRoughness: 0.28,
    side: THREE.DoubleSide,
  });

  const lotusPetalPinkMat = new THREE.MeshStandardMaterial({
    color: 0xf7a8b8,
    roughness: 0.48,
    metalness: 0.0,
    side: THREE.DoubleSide,
  });

  const lotusPetalCreamMat = new THREE.MeshStandardMaterial({
    color: 0xfdf2e9,
    roughness: 0.45,
    metalness: 0.0,
    side: THREE.DoubleSide,
  });

  const lotusCenterMat = new THREE.MeshStandardMaterial({
    color: 0xf0be42,
    roughness: 0.65,
    metalness: 0.02,
  });

  // Submerged swaying waterweed
  const waterweedMat = new THREE.MeshStandardMaterial({
    color: 0x357845,
    roughness: 0.65,
    metalness: 0.02,
    side: THREE.DoubleSide,
  });
  waterweedMat.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = { value: 0 };
    animatedShaders.push(shader);
    shader.vertexShader =
      `uniform float uTime;\n` +
      shader.vertexShader.replace(
        '#include <begin_vertex>',
        `
        #include <begin_vertex>
        float swayWeight = clamp(position.y / 0.75, 0.0, 1.0);
        vec4 wP = modelMatrix * vec4(transformed, 1.0);
        transformed.x += sin(uTime * 1.4 + wP.x * 1.7 + wP.z * 1.3) * 0.09 * swayWeight;
        transformed.z += cos(uTime * 1.15 + wP.z * 1.5) * 0.07 * swayWeight;
        `,
      );
  };
  waterweedMat.customProgramCacheKey = () => 'manor-waterweed-sway-v1';

  const cattailLeafMat = new THREE.MeshStandardMaterial({
    color: 0x4f7f42,
    roughness: 0.68,
    metalness: 0.02,
    side: THREE.DoubleSide,
  });

  const cattailHeadMat = new THREE.MeshStandardMaterial({
    color: 0x5c361c,
    roughness: 0.94,
    metalness: 0.0,
  });

  const willowBarkMat = new THREE.MeshStandardMaterial({
    color: 0x5c4738,
    roughness: 0.92,
    metalness: 0.01,
  });

  const willowFoliageMat = new THREE.MeshStandardMaterial({
    color: 0x5c8b48,
    roughness: 0.78,
    metalness: 0.01,
  });

  const mapleFoliageMat = new THREE.MeshStandardMaterial({
    color: 0xc95a3c,
    roughness: 0.74,
    metalness: 0.02,
  });

  const grassTuftMat = new THREE.MeshStandardMaterial({
    color: 0x628e47,
    roughness: 0.82,
    metalness: 0.01,
    side: THREE.DoubleSide,
  });
  grassTuftMat.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = { value: 0 };
    animatedShaders.push(shader);
    shader.vertexShader =
      `uniform float uTime;\n` +
      shader.vertexShader.replace(
        '#include <begin_vertex>',
        `
        #include <begin_vertex>
        float gWeight = clamp(position.y / 0.34, 0.0, 1.0);
        vec3 instOrigin = vec3(0.0);
        #ifdef USE_INSTANCING
          instOrigin = (instanceMatrix * vec4(0.0, 0.0, 0.0, 1.0)).xyz;
        #endif
        float windPhase = uTime * 1.85 + instOrigin.x * 0.45 + instOrigin.z * 0.35;
        transformed.x += sin(windPhase) * 0.045 * gWeight * gWeight;
        transformed.z += cos(windPhase * 0.8) * 0.025 * gWeight * gWeight;
        `,
      );
  };
  grassTuftMat.customProgramCacheKey = () => 'manor-grass-sway-v1';

  const contactShadowMat = new THREE.MeshBasicMaterial({
    map: textures.contactShadowMap,
    transparent: true,
    depthWrite: false,
    opacity: 0.55,
  });

  const springWaterStreamMat = new THREE.MeshPhysicalMaterial({
    color: 0xbef2ea,
    transparent: true,
    opacity: 0.68,
    roughness: 0.08,
    metalness: 0.04,
    clearcoat: 1.0,
    depthWrite: false,
  });

  const selectionRingMat = new THREE.MeshBasicMaterial({
    color: 0xffe082,
    transparent: true,
    opacity: 0.85,
    side: THREE.DoubleSide,
    depthWrite: false,
  });

  const allMaterials: THREE.Material[] = [
    terrainMat,
    waterMat,
    woodDeckMat,
    woodDarkMat,
    bambooMat,
    thatchMat,
    graniteMat,
    wetRockMat,
    brassMat,
    ceramicMat,
    lanternGlowMat,
    lotusLeafMat,
    lotusPetalPinkMat,
    lotusPetalCreamMat,
    lotusCenterMat,
    waterweedMat,
    cattailLeafMat,
    cattailHeadMat,
    willowBarkMat,
    willowFoliageMat,
    mapleFoliageMat,
    grassTuftMat,
    contactShadowMat,
    springWaterStreamMat,
    selectionRingMat,
  ];

  return {
    terrainMat,
    waterMat,
    woodDeckMat,
    woodDarkMat,
    bambooMat,
    thatchMat,
    graniteMat,
    wetRockMat,
    brassMat,
    ceramicMat,
    lanternGlowMat,
    lotusLeafMat,
    lotusPetalPinkMat,
    lotusPetalCreamMat,
    lotusCenterMat,
    waterweedMat,
    cattailLeafMat,
    cattailHeadMat,
    willowBarkMat,
    willowFoliageMat,
    mapleFoliageMat,
    grassTuftMat,
    contactShadowMat,
    springWaterStreamMat,
    selectionRingMat,
    updateTime: (elapsed: number) => {
      for (const sh of animatedShaders) {
        if (sh.uniforms.uTime) {
          sh.uniforms.uTime.value = elapsed;
        }
      }
    },
    pushRipple: (x: number, z: number, time: number, strength = 1.0) => {
      rippleArray[rippleCursor].set(x, z, time, strength);
      rippleCursor = (rippleCursor + 1) % MAX_RIPPLES;
    },
    dispose: () => {
      allMaterials.forEach((m) => m.dispose());
    },
  };
}
