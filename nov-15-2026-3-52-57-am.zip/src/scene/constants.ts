import * as THREE from 'three';
import type { CameraPreset } from '../types/pond';

export const WATER_LEVEL = 0.0;
export const TERRAIN_SIZE = 124;
export const TERRAIN_SEGMENTS = 200;
export const WATER_WIDTH = 19.5;
export const WATER_HEIGHT = 15.0;
export const WATER_SEGMENTS_X = 112;
export const WATER_SEGMENTS_Z = 88;

export const SCENE_BG_COLOR = 0xd6e7df;
export const FOG_COLOR = 0xd6e7df;

let currentPondScale = 1.0;

export function setPondVisualScale(scale: number) {
  currentPondScale = Math.max(0.85, Math.min(2.4, scale));
}

export function getPondVisualScale(): number {
  return currentPondScale;
}

export const CAMERA_PRESETS: CameraPreset[] = [
  {
    id: 'isometric',
    label: '全景庄园',
    position: [24, 21.5, 24],
    target: [0.2, -0.2, 0.2],
    zoom: 1.0,
  },
  {
    id: 'water_close',
    label: '水面近赏',
    position: [13, 12.5, 14.5],
    target: [-1.2, -0.35, 0.4],
    zoom: 1.75,
  },
  {
    id: 'bridge_view',
    label: '木桥垂柳',
    position: [15.5, 12.0, -13.5],
    target: [1.4, 0.2, 0.0],
    zoom: 1.55,
  },
  {
    id: 'dock_view',
    label: '栈台养殖',
    position: [-14.0, 13.5, 16.5],
    target: [3.2, 0.1, 1.4],
    zoom: 1.45,
  },
];

function smin(a: number, b: number, k: number): number {
  const h = Math.max(k - Math.abs(a - b), 0) / k;
  return Math.min(a, b) - h * h * k * 0.25;
}

function ellipseSDF(x: number, z: number, cx: number, cz: number, rx: number, rz: number): number {
  const dx = (x - cx) / rx;
  const dz = (z - cz) / rz;
  const k0 = Math.hypot(dx, dz);
  if (k0 < 1e-5) return -Math.min(rx, rz);
  const k1 = Math.hypot(dx / rx, dz / rz);
  return (k0 * (k0 - 1.0)) / Math.max(k1, 1e-5);
}

/**
 * Signed distance to the organic pond shoreline in XZ plane.
 * Scales cleanly with currentPondScale as the pond expands across Lv.1 -> Lv.4.
 */
export function pondSignedDistance(x: number, z: number): number {
  const s = currentPondScale;
  const sx = x / s;
  const sz = z / s;

  const westBasin = ellipseSDF(sx, sz, -2.55, 0.25, 4.75, 4.35);
  const eastCove = ellipseSDF(sx, sz, 4.25, -0.45, 3.65, 3.25);
  const southBay = ellipseSDF(sx, sz, 0.75, 2.35, 2.65, 2.15);

  let d = smin(westBasin, eastCove, 2.2);
  d = smin(d, southBay, 1.8);

  const wave =
    Math.sin(sx * 0.58 + sz * 0.42) * 0.24 +
    Math.cos(sx * 0.95 - sz * 0.78) * 0.15 +
    Math.sin(sx * 1.45 + sz * 1.15) * 0.06;

  return (d + wave) * s;
}

export function smoothstep(edge0: number, edge1: number, x: number): number {
  const t = THREE.MathUtils.clamp((x - edge0) / (edge1 - edge0), 0, 1);
  return t * t * (3 - 2 * t);
}

/**
 * Returns exact terrain elevation at (x, z).
 * Negative underwater inside the pond basin, rising smoothly to lush manor banks outside.
 */
export function groundHeightAt(x: number, z: number): number {
  const s = currentPondScale;
  const sdf = pondSignedDistance(x, z);

  if (sdf < 0) {
    const depthNorm = smoothstep(0, 2.45 * s, -sdf);
    const microBed =
      Math.sin(x * 0.8 + z * 0.65) * 0.05 +
      Math.cos(x * 1.5 - z * 1.2) * 0.025;
    return -1.78 * Math.pow(depthNorm, 0.82) + microBed * depthNorm;
  }

  const shoreRise = 0.36 * smoothstep(0.0, 1.55 * s, sdf);

  const lawnUndulation =
    (Math.sin(x * 0.18 + 0.5) * Math.cos(z * 0.16 - 0.3) * 0.22 +
      Math.sin(x * 0.42 - z * 0.34) * 0.07) *
    smoothstep(1.2, 5.5, sdf);

  const distFromCenter = Math.hypot(x * 0.9, z);
  const perimeterHill =
    smoothstep(14.5 * s, 34.0 * Math.max(1.0, s * 0.92), distFromCenter) *
    (1.45 + 0.65 * Math.sin(Math.atan2(z, x) * 3.0 + 0.7));

  const wfX = -6.4 * s;
  const wfZ = -4.3 * s;
  const waterfallMound =
    Math.exp(-((x - wfX) ** 2 / (7.5 * s) + (z - wfZ) ** 2 / (6.0 * s))) * 0.95;

  const gzX = 7.4 * s;
  const gzZ = -5.6 * s;
  const gazeboFlatFactor =
    1.0 - 0.75 * Math.exp(-((x - gzX) ** 2 / 9.0 + (z - gzZ) ** 2 / 7.5));

  return shoreRise + lawnUndulation * gazeboFlatFactor + perimeterHill + waterfallMound;
}

export const BRIDGE_CONFIG = {
  centerX: 1.45,
  centerZ: 0.25,
  spanLength: 6.8,
  width: 1.55,
  archHeight: 0.92,
  deckBaseY: 0.44,
};

export function getScaledBridgeConfig() {
  const s = currentPondScale;
  return {
    centerX: BRIDGE_CONFIG.centerX * s,
    centerZ: BRIDGE_CONFIG.centerZ * s,
    spanLength: BRIDGE_CONFIG.spanLength * s,
    width: BRIDGE_CONFIG.width * (1 + (s - 1) * 0.25),
    archHeight: BRIDGE_CONFIG.archHeight * (1 + (s - 1) * 0.25),
    deckBaseY: BRIDGE_CONFIG.deckBaseY,
  };
}

export function bridgeDeckHeightAt(localZ: number): number {
  const cfg = getScaledBridgeConfig();
  const halfSpan = cfg.spanLength * 0.5;
  const norm = THREE.MathUtils.clamp(localZ / halfSpan, -1, 1);
  return cfg.deckBaseY + cfg.archHeight * (1 - norm * norm);
}
