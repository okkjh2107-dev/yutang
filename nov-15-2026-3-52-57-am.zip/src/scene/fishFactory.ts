import * as THREE from 'three';
import type { FishCategory, FishPatternId } from '../types/pond';
import type { TextureBundle } from './textures';

export interface FishRigSpec {
  id: string;
  category: FishCategory;
  patternId: FishPatternId;
  scaleFactor: number;
}

export interface FishRig {
  root: THREE.Group;
  hitProxy: THREE.Mesh;
  pectoralL: THREE.Mesh;
  pectoralR: THREE.Mesh;
  caudalFin: THREE.Mesh;
  dorsalFin: THREE.Mesh;
  updateSwimUniforms: (phase: number, turnBend: number) => void;
  setHighlight: (selected: boolean) => void;
  dispose: () => void;
}

export interface FishAssetLibrary {
  createFishRig: (spec: FishRigSpec) => FishRig;
  dispose: () => void;
}

/**
 * Generates an anatomical spline-lofted fish body BufferGeometry.
 * Local coordinates:
 *  +X = Nose tip (x = +0.52)
 *  -X = Caudal peduncle (x = -0.52)
 *  +Y = Dorsal ridge
 *  +Z / -Z = Right / Left flanks
 */
function createLoftedFishBodyGeometry(isKoi: boolean): THREE.BufferGeometry {
  const lengthSegs = 28;
  const radialSegs = 22;
  const bodyLength = 1.04;

  const positions: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];

  for (let i = 0; i <= lengthSegs; i++) {
    const u = i / lengthSegs; // 0 = snout, 1 = tail peduncle
    const x = 0.52 - u * bodyLength;

    // Anatomical height/width curves
    let dorsalH: number;
    let bellyH: number;
    let halfW: number;

    if (isKoi) {
      // Plump arched Koi silhouette
      const snoutProfile = Math.pow(Math.sin(Math.min(u / 0.34, 1) * (Math.PI * 0.5)), 0.72);
      const tailTaper = Math.pow(Math.max(0, 1 - Math.max(0, u - 0.28) / 0.72), 1.15);
      const envelope = u < 0.34 ? snoutProfile : tailTaper;

      dorsalH = 0.025 + 0.145 * envelope;
      bellyH = 0.02 + 0.115 * envelope;
      halfW = 0.014 + 0.112 * envelope;

      // Slight cheek flare & slender caudal peduncle
      if (u > 0.78) {
        const ped = (u - 0.78) / 0.22;
        dorsalH *= 1 - ped * 0.42;
        bellyH *= 1 - ped * 0.42;
        halfW *= 1 - ped * 0.55;
      }
    } else {
      // Deeper muscular flank for food fish (carp/mandarin/crucian)
      const snoutProfile = Math.pow(Math.sin(Math.min(u / 0.32, 1) * (Math.PI * 0.5)), 0.75);
      const tailTaper = Math.pow(Math.max(0, 1 - Math.max(0, u - 0.26) / 0.74), 1.05);
      const envelope = u < 0.32 ? snoutProfile : tailTaper;

      dorsalH = 0.022 + 0.165 * envelope;
      bellyH = 0.02 + 0.13 * envelope;
      halfW = 0.012 + 0.095 * envelope;

      if (u > 0.78) {
        const ped = (u - 0.78) / 0.22;
        dorsalH *= 1 - ped * 0.45;
        bellyH *= 1 - ped * 0.45;
        halfW *= 1 - ped * 0.58;
      }
    }

    // Gentle upward nose lift near mouth
    const noseCurveY = u < 0.12 ? -0.018 * (1 - u / 0.12) : 0;

    for (let j = 0; j <= radialSegs; j++) {
      const v = j / radialSegs;
      const theta = v * Math.PI * 2; // 0 = top (+Y), PI/2 = right (+Z), PI = bottom (-Y)

      const cosT = Math.cos(theta);
      const sinT = Math.sin(theta);

      // Sharper dorsal ridge & fuller rounded belly
      const ry = cosT >= 0 ? dorsalH * Math.pow(cosT, 0.9) : -bellyH * Math.pow(-cosT, 0.85);
      const rz = halfW * sinT * (1 + 0.08 * Math.sin(theta * 2));

      // Pinch tip cleanly at u = 0
      const tipPinch = u === 0 ? 0.18 : 1.0;
      positions.push(x, ry * tipPinch + noseCurveY, rz * tipPinch);
      uvs.push(u, 1.0 - v);
    }
  }

  for (let i = 0; i < lengthSegs; i++) {
    for (let j = 0; j < radialSegs; j++) {
      const a = i * (radialSegs + 1) + j;
      const b = (i + 1) * (radialSegs + 1) + j;
      const c = (i + 1) * (radialSegs + 1) + (j + 1);
      const d = i * (radialSegs + 1) + (j + 1);
      indices.push(a, b, d);
      indices.push(b, c, d);
    }
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

/**
 * Generates a delicate beveled fin blade geometry in XY plane (thin in Z),
 * anchored at x = 0 so it rotates cleanly around its root attachment.
 */
function createFinGeometry(
  shapePoints: Array<[number, number]>,
  thickness = 0.012,
): THREE.BufferGeometry {
  const shape = new THREE.Shape();
  shape.moveTo(shapePoints[0][0], shapePoints[0][1]);
  for (let i = 1; i < shapePoints.length; i++) {
    shape.lineTo(shapePoints[i][0], shapePoints[i][1]);
  }
  shape.closePath();

  const geo = new THREE.ExtrudeGeometry(shape, {
    steps: 2,
    depth: thickness,
    bevelEnabled: true,
    bevelThickness: thickness * 0.45,
    bevelSize: thickness * 0.45,
    bevelSegments: 2,
    curveSegments: 10,
  });

  // Center along Z thickness
  geo.translate(0, 0, -thickness * 0.5);
  // Normalize UV 0..1 across fin bounding box for fin ray texture
  geo.computeBoundingBox();
  const bb = geo.boundingBox!;
  const spanX = Math.max(bb.max.x - bb.min.x, 0.001);
  const spanY = Math.max(bb.max.y - bb.min.y, 0.001);
  const pos = geo.attributes.position;
  const uvs = new Float32Array(pos.count * 2);
  for (let i = 0; i < pos.count; i++) {
    // 0 at root (max X or min X depending on fin), 1 at outer tip
    uvs[i * 2] = 1.0 - (pos.getX(i) - bb.min.x) / spanX;
    uvs[i * 2 + 1] = (pos.getY(i) - bb.min.y) / spanY;
  }
  geo.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
  geo.computeVertexNormals();
  return geo;
}

function injectSwimVertexShader(
  mat: THREE.MeshStandardMaterial,
  uniformState: { uSwimPhase: { value: number }; uTurnBend: { value: number } },
  includeHeadPin: boolean,
) {
  mat.onBeforeCompile = (shader) => {
    shader.uniforms.uSwimPhase = uniformState.uSwimPhase;
    shader.uniforms.uTurnBend = uniformState.uTurnBend;

    shader.vertexShader =
      `
      uniform float uSwimPhase;
      uniform float uTurnBend;
      ` +
      shader.vertexShader.replace(
        '#include <begin_vertex>',
        `
        #include <begin_vertex>
        float distFromNose = clamp(0.52 - transformed.x, 0.0, 1.3);
        float flexWeight = ${includeHeadPin ? 'pow(distFromNose / 1.04, 1.55)' : '0.85'};
        float sWave = sin(distFromNose * 5.2 - uSwimPhase) * 0.068 * flexWeight;
        float turnArc = uTurnBend * pow(distFromNose, 1.7) * 0.42;
        transformed.z += sWave + turnArc;
        `,
      );
  };
  mat.customProgramCacheKey = () => (includeHeadPin ? 'fish-body-swim-v1' : 'fish-fin-swim-v1');
}

export function createFishAssetLibrary(textures: TextureBundle): FishAssetLibrary {
  // Shared master geometries (zero per-fish geometry duplication!)
  const koiBodyGeo = createLoftedFishBodyGeometry(true);
  const foodBodyGeo = createLoftedFishBodyGeometry(false);

  // Flowing forked Koi caudal fin (extends toward -X from x=0)
  const koiTailGeo = createFinGeometry(
    [
      [0.0, 0.028],
      [-0.14, 0.11],
      [-0.32, 0.165],
      [-0.23, 0.04],
      [-0.20, 0.0],
      [-0.23, -0.04],
      [-0.31, -0.155],
      [-0.14, -0.10],
      [0.0, -0.028],
    ],
    0.01,
  );

  // Crisp crescent caudal fin for food fish
  const foodTailGeo = createFinGeometry(
    [
      [0.0, 0.025],
      [-0.11, 0.095],
      [-0.24, 0.13],
      [-0.19, 0.0],
      [-0.24, -0.13],
      [-0.11, -0.095],
      [0.0, -0.025],
    ],
    0.01,
  );

  // Dorsal sail fin
  const koiDorsalGeo = createFinGeometry(
    [
      [0.18, 0.0],
      [0.10, 0.115],
      [-0.08, 0.13],
      [-0.22, 0.07],
      [-0.26, 0.0],
    ],
    0.008,
  );

  const foodDorsalGeo = createFinGeometry(
    [
      [0.16, 0.0],
      [0.08, 0.13],
      [-0.09, 0.11],
      [-0.20, 0.05],
      [-0.24, 0.0],
    ],
    0.009,
  );

  // Broad fan pectoral fin (flattened in XZ plane)
  const pectoralGeo = createFinGeometry(
    [
      [0.02, 0.0],
      [-0.08, 0.14],
      [-0.19, 0.12],
      [-0.17, 0.02],
      [-0.05, -0.02],
    ],
    0.007,
  );
  pectoralGeo.rotateX(Math.PI / 2);

  // Small ventral pelvic fin
  const pelvicGeo = createFinGeometry(
    [
      [0.02, 0.0],
      [-0.05, 0.07],
      [-0.12, 0.05],
      [-0.06, -0.01],
    ],
    0.006,
  );
  pelvicGeo.rotateX(Math.PI / 2);

  // Eye & barbel shared micro-geometries
  const eyeWhiteGeo = new THREE.SphereGeometry(0.024, 12, 10);
  const eyePupilGeo = new THREE.SphereGeometry(0.014, 10, 8);
  const barbelGeo = new THREE.ConeGeometry(0.006, 0.055, 6);
  barbelGeo.rotateZ(Math.PI * 0.65);

  const hitProxyGeo = new THREE.CapsuleGeometry(0.22, 0.95, 4, 8);
  hitProxyGeo.rotateZ(Math.PI / 2);

  // Shared static materials for eyes & hit proxy
  const eyeWhiteMat = new THREE.MeshStandardMaterial({
    color: 0xf4f0e4,
    roughness: 0.15,
    metalness: 0.05,
  });
  const eyePupilMat = new THREE.MeshStandardMaterial({
    color: 0x101316,
    roughness: 0.08,
    metalness: 0.1,
  });
  const hitProxyMat = new THREE.MeshBasicMaterial({
    visible: false,
  });

  const createdMaterials = new Set<THREE.Material>([eyeWhiteMat, eyePupilMat, hitProxyMat]);

  function getFinTexture(patternId: FishPatternId): THREE.CanvasTexture {
    switch (patternId) {
      case 'koi_ogon':
        return textures.finRayMaps.koiGold;
      case 'koi_kohaku':
      case 'koi_showa':
        return textures.finRayMaps.koiRedTip;
      case 'koi_black':
        return textures.finRayMaps.koiBlack;
      case 'koi_tancho':
      case 'koi_asagi':
        return textures.finRayMaps.koiWhite;
      case 'food_grass_carp':
      case 'food_tilapia':
        return textures.finRayMaps.edibleOlive;
      case 'food_carp':
      case 'food_mandarin':
      case 'food_crucian':
        return textures.finRayMaps.edibleAmber;
    }
  }

  function createFishRig(spec: FishRigSpec): FishRig {
    const isKoi = spec.patternId.startsWith('koi_');
    const root = new THREE.Group();
    root.name = `fish-${spec.id}`;
    root.scale.setScalar(spec.scaleFactor);

    const uniformState = {
      uSwimPhase: { value: 0 },
      uTurnBend: { value: 0 },
    };

    const bodyMat = new THREE.MeshStandardMaterial({
      map: textures.fishSkinMaps[spec.patternId],
      roughness: isKoi ? 0.24 : 0.30,
      metalness: spec.patternId === 'koi_ogon' ? 0.34 : 0.12,
      envMapIntensity: 1.15,
    });
    injectSwimVertexShader(bodyMat, uniformState, true);

    const finMat = new THREE.MeshStandardMaterial({
      map: getFinTexture(spec.patternId),
      roughness: 0.38,
      metalness: 0.05,
      transparent: true,
      opacity: 0.88,
      side: THREE.DoubleSide,
    });

    createdMaterials.add(bodyMat);
    createdMaterials.add(finMat);

    // 1. Primary sculpted body
    const bodyMesh = new THREE.Mesh(isKoi ? koiBodyGeo : foodBodyGeo, bodyMat);
    bodyMesh.castShadow = true;
    bodyMesh.receiveShadow = true;
    root.add(bodyMesh);

    // 2. Protruding glossy eyes (left & right)
    const eyeL = new THREE.Mesh(eyeWhiteGeo, eyeWhiteMat);
    eyeL.position.set(0.36, 0.028, -0.068);
    const pupilL = new THREE.Mesh(eyePupilGeo, eyePupilMat);
    pupilL.position.set(0.004, 0.0, -0.015);
    eyeL.add(pupilL);
    root.add(eyeL);

    const eyeR = new THREE.Mesh(eyeWhiteGeo, eyeWhiteMat);
    eyeR.position.set(0.36, 0.028, 0.068);
    const pupilR = new THREE.Mesh(eyePupilGeo, eyePupilMat);
    pupilR.position.set(0.004, 0.0, 0.015);
    eyeR.add(pupilR);
    root.add(eyeR);

    // Koi sensory barbels near mouth
    if (isKoi) {
      const barbL = new THREE.Mesh(barbelGeo, finMat);
      barbL.position.set(0.47, -0.022, -0.032);
      barbL.rotation.y = 0.45;
      root.add(barbL);

      const barbR = new THREE.Mesh(barbelGeo, finMat);
      barbR.position.set(0.47, -0.022, 0.032);
      barbR.rotation.y = -0.45;
      root.add(barbR);
    }

    // 3. Dorsal sail fin (rides along spine)
    const dorsalFin = new THREE.Mesh(isKoi ? koiDorsalGeo : foodDorsalGeo, finMat);
    dorsalFin.position.set(-0.04, isKoi ? 0.115 : 0.135, 0);
    dorsalFin.castShadow = true;
    root.add(dorsalFin);

    // 4. Independent Pectoral Fins (articulated left/right rowing)
    const pectoralL = new THREE.Mesh(pectoralGeo, finMat);
    pectoralL.position.set(0.20, -0.048, -0.088);
    pectoralL.rotation.y = -0.35;
    pectoralL.rotation.x = 0.22;
    pectoralL.castShadow = true;
    root.add(pectoralL);

    const pectoralR = new THREE.Mesh(pectoralGeo, finMat);
    pectoralR.position.set(0.20, -0.048, 0.088);
    pectoralR.scale.z = -1;
    pectoralR.rotation.y = 0.35;
    pectoralR.rotation.x = -0.22;
    pectoralR.castShadow = true;
    root.add(pectoralR);

    // 5. Ventral Pelvic Fins
    const pelvicL = new THREE.Mesh(pelvicGeo, finMat);
    pelvicL.position.set(-0.06, -0.095, -0.048);
    pelvicL.rotation.y = -0.25;
    pelvicL.rotation.x = 0.32;
    root.add(pelvicL);

    const pelvicR = new THREE.Mesh(pelvicGeo, finMat);
    pelvicR.position.set(-0.06, -0.095, 0.048);
    pelvicR.scale.z = -1;
    pelvicR.rotation.y = 0.25;
    pelvicR.rotation.x = -0.32;
    root.add(pelvicR);

    // 6. Articulated Forked Caudal Tail Fin
    const caudalFin = new THREE.Mesh(isKoi ? koiTailGeo : foodTailGeo, finMat);
    caudalFin.position.set(-0.50, 0.0, 0);
    caudalFin.castShadow = true;
    root.add(caudalFin);

    // 7. Invisible simplified raycast hit proxy for effortless clicking/tapping on desktop & mobile
    const hitProxy = new THREE.Mesh(hitProxyGeo, hitProxyMat);
    hitProxy.userData = { interactType: 'fish', fishId: spec.id };
    root.add(hitProxy);

    return {
      root,
      hitProxy,
      pectoralL,
      pectoralR,
      caudalFin,
      dorsalFin,
      updateSwimUniforms: (phase: number, turnBend: number) => {
        uniformState.uSwimPhase.value = phase;
        uniformState.uTurnBend.value = turnBend;
      },
      setHighlight: (selected: boolean) => {
        bodyMat.emissive.setHex(selected ? 0x3b2c12 : 0x000000);
        bodyMat.emissiveIntensity = selected ? 0.65 : 0;
      },
      dispose: () => {
        createdMaterials.delete(bodyMat);
        createdMaterials.delete(finMat);
        bodyMat.dispose();
        finMat.dispose();
      },
    };
  }

  return {
    createFishRig,
    dispose: () => {
      koiBodyGeo.dispose();
      foodBodyGeo.dispose();
      koiTailGeo.dispose();
      foodTailGeo.dispose();
      koiDorsalGeo.dispose();
      foodDorsalGeo.dispose();
      pectoralGeo.dispose();
      pelvicGeo.dispose();
      eyeWhiteGeo.dispose();
      eyePupilGeo.dispose();
      barbelGeo.dispose();
      hitProxyGeo.dispose();
      createdMaterials.forEach((m) => m.dispose());
    },
  };
}
