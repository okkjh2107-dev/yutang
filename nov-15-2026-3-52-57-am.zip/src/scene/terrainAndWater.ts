import * as THREE from 'three';
import {
  TERRAIN_SEGMENTS,
  TERRAIN_SIZE,
  WATER_HEIGHT,
  WATER_LEVEL,
  WATER_SEGMENTS_X,
  WATER_SEGMENTS_Z,
  WATER_WIDTH,
  getPondVisualScale,
  groundHeightAt,
  pondSignedDistance,
  smoothstep,
} from './constants';
import type { MaterialBundle } from './materials';

export interface TerrainAndWaterResult {
  terrainMesh: THREE.Mesh;
  waterMesh: THREE.Mesh;
  dispose: () => void;
}

const _cDeepBed = new THREE.Color(0x41564e);
const _cSandBed = new THREE.Color(0x8e866b);
const _cWetShore = new THREE.Color(0x9a8f73);
const _cMeadowLight = new THREE.Color(0x74a650);
const _cMeadowRich = new THREE.Color(0x4f833b);
const _cHillMoss = new THREE.Color(0x46733b);
const _cTemp = new THREE.Color();

export function createTerrainAndWater(materials: MaterialBundle): TerrainAndWaterResult {
  const s = getPondVisualScale();

  // 1. Sculpted Natural Estate Terrain + Pond Basin
  const terrainGeo = new THREE.PlaneGeometry(
    TERRAIN_SIZE,
    TERRAIN_SIZE,
    TERRAIN_SEGMENTS,
    TERRAIN_SEGMENTS,
  );
  terrainGeo.rotateX(-Math.PI / 2);

  const pos = terrainGeo.attributes.position;
  const colors = new Float32Array(pos.count * 3);

  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const z = pos.getZ(i);
    const y = groundHeightAt(x, z);
    pos.setY(i, y);

    const sdf = pondSignedDistance(x, z);

    const patchNoise =
      0.5 +
      0.28 * Math.sin(x * 0.48 + z * 0.36) +
      0.22 * Math.cos(x * 0.92 - z * 0.74);

    if (y < -0.05) {
      const deepT = smoothstep(-0.15, -1.65, y);
      _cTemp.copy(_cSandBed).lerp(_cDeepBed, deepT);
      _cTemp.offsetHSL(0, 0, (patchNoise - 0.5) * 0.08);
    } else if (sdf < 0.85 * s) {
      const shoreT = smoothstep(0.05, 0.85 * s, sdf);
      _cTemp.copy(_cWetShore).lerp(_cMeadowLight, shoreT);
    } else {
      _cTemp.copy(_cMeadowRich).lerp(_cMeadowLight, smoothstep(0.2, 0.85, patchNoise));
      const hillT = smoothstep(15.0 * s, 32.0 * Math.max(1.0, s * 0.9), Math.hypot(x, z));
      _cTemp.lerp(_cHillMoss, hillT * 0.55);
    }

    const bridgePathDist = Math.abs(x - 1.45 * s - Math.sin(z * 0.18) * 0.6);
    if (sdf > 0.35 && bridgePathDist < 0.85 && Math.abs(z) < 9.5 * s) {
      const pathT = (1.0 - smoothstep(0.25, 0.85, bridgePathDist)) * 0.35;
      _cTemp.lerp(_cWetShore, pathT);
    }

    colors[i * 3] = _cTemp.r;
    colors[i * 3 + 1] = _cTemp.g;
    colors[i * 3 + 2] = _cTemp.b;
  }

  terrainGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  terrainGeo.computeVertexNormals();

  const terrainMesh = new THREE.Mesh(terrainGeo, materials.terrainMat);
  terrainMesh.name = 'manor-terrain';
  terrainMesh.receiveShadow = true;
  terrainMesh.castShadow = false;

  // 2. Dynamic Pond Water Surface scaled to current pond level
  const waterGeo = new THREE.PlaneGeometry(
    WATER_WIDTH * s,
    WATER_HEIGHT * s,
    WATER_SEGMENTS_X,
    WATER_SEGMENTS_Z,
  );
  waterGeo.rotateX(-Math.PI / 2);

  const wPos = waterGeo.attributes.position;
  const depthAttr = new Float32Array(wPos.count);

  for (let i = 0; i < wPos.count; i++) {
    const x = wPos.getX(i);
    const z = wPos.getZ(i);
    const bedY = groundHeightAt(x, z);
    const depth = Math.max(0, WATER_LEVEL - bedY + 0.025);
    depthAttr[i] = depth;
  }

  waterGeo.setAttribute('aWaterDepth', new THREE.BufferAttribute(depthAttr, 1));

  const waterMesh = new THREE.Mesh(waterGeo, materials.waterMat);
  waterMesh.name = 'pond-water';
  waterMesh.position.y = WATER_LEVEL;
  waterMesh.renderOrder = 3;
  waterMesh.receiveShadow = true;
  waterMesh.userData = { interactType: 'pond' };

  return {
    terrainMesh,
    waterMesh,
    dispose: () => {
      terrainGeo.dispose();
      waterGeo.dispose();
    },
  };
}
