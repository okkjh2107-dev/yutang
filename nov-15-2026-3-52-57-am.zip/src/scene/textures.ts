import * as THREE from 'three';
import type { FishPatternId } from '../types/pond';

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export interface TextureBundle {
  meadowMap: THREE.CanvasTexture;
  meadowBump: THREE.CanvasTexture;
  woodDeckMap: THREE.CanvasTexture;
  woodDeckBump: THREE.CanvasTexture;
  woodDarkMap: THREE.CanvasTexture;
  graniteMap: THREE.CanvasTexture;
  graniteBump: THREE.CanvasTexture;
  lotusLeafMap: THREE.CanvasTexture;
  bambooMap: THREE.CanvasTexture;
  thatchShingleMap: THREE.CanvasTexture;
  contactShadowMap: THREE.CanvasTexture;
  fishSkinMaps: Record<FishPatternId, THREE.CanvasTexture>;
  finRayMaps: {
    koiWhite: THREE.CanvasTexture;
    koiGold: THREE.CanvasTexture;
    koiRedTip: THREE.CanvasTexture;
    koiBlack: THREE.CanvasTexture;
    edibleOlive: THREE.CanvasTexture;
    edibleAmber: THREE.CanvasTexture;
  };
  dispose: () => void;
}

function finalizeTexture(
  canvas: HTMLCanvasElement,
  options: {
    isColor?: boolean;
    repeatX?: number;
    repeatY?: number;
    anisotropy?: number;
    clamp?: boolean;
  } = {},
): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = options.isColor !== false ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  tex.wrapS = options.clamp ? THREE.ClampToEdgeWrapping : THREE.RepeatWrapping;
  tex.wrapT = options.clamp ? THREE.ClampToEdgeWrapping : THREE.RepeatWrapping;
  if (options.repeatX && options.repeatY) {
    tex.repeat.set(options.repeatX, options.repeatY);
  }
  tex.anisotropy = options.anisotropy ?? 4;
  tex.needsUpdate = true;
  return tex;
}

function createMeadowTextures(anisotropy: number) {
  const size = 512;
  const colorCanvas = document.createElement('canvas');
  colorCanvas.width = size;
  colorCanvas.height = size;
  const ctx = colorCanvas.getContext('2d')!;

  const bumpCanvas = document.createElement('canvas');
  bumpCanvas.width = size;
  bumpCanvas.height = size;
  const bCtx = bumpCanvas.getContext('2d')!;

  const rng = mulberry32(1042);

  // Neutral soft-warm base so vertex colors (grass, wet shore, sandy riverbed) tint cleanly
  ctx.fillStyle = '#dcdcd2';
  ctx.fillRect(0, 0, size, size);

  bCtx.fillStyle = '#808080';
  bCtx.fillRect(0, 0, size, size);

  // Soft organic soil/turf mottling
  for (let i = 0; i < 420; i++) {
    const x = rng() * size;
    const y = rng() * size;
    const r = 8 + rng() * 28;
    const shade = Math.floor(195 + (rng() - 0.5) * 45);
    ctx.fillStyle = `rgba(${shade}, ${shade + 4}, ${shade - 8}, 0.16)`;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();

    const bShade = Math.floor(128 + (rng() - 0.5) * 70);
    bCtx.fillStyle = `rgba(${bShade}, ${bShade}, ${bShade}, 0.22)`;
    bCtx.beginPath();
    bCtx.arc(x, y, r * 0.7, 0, Math.PI * 2);
    bCtx.fill();
  }

  // Fine granular pebbles / turf fibers
  for (let i = 0; i < 2400; i++) {
    const x = rng() * size;
    const y = rng() * size;
    const w = 1.5 + rng() * 3.5;
    const h = 1.5 + rng() * 4.5;
    const lum = Math.floor(175 + rng() * 75);
    ctx.fillStyle = `rgba(${lum}, ${lum + 3}, ${lum - 6}, 0.28)`;
    ctx.fillRect(x, y, w, h);

    const bVal = Math.floor(90 + rng() * 140);
    bCtx.fillStyle = `rgba(${bVal}, ${bVal}, ${bVal}, 0.35)`;
    bCtx.fillRect(x, y, w, h);
  }

  return {
    meadowMap: finalizeTexture(colorCanvas, { isColor: true, repeatX: 12, repeatY: 12, anisotropy }),
    meadowBump: finalizeTexture(bumpCanvas, { isColor: false, repeatX: 12, repeatY: 12, anisotropy }),
  };
}

function createWoodTextures(
  baseHex: string,
  grainHex: string,
  seed: number,
  anisotropy: number,
  planks = 6,
) {
  const size = 512;
  const colorCanvas = document.createElement('canvas');
  colorCanvas.width = size;
  colorCanvas.height = size;
  const ctx = colorCanvas.getContext('2d')!;

  const bumpCanvas = document.createElement('canvas');
  bumpCanvas.width = size;
  bumpCanvas.height = size;
  const bCtx = bumpCanvas.getContext('2d')!;

  const rng = mulberry32(seed);
  ctx.fillStyle = baseHex;
  ctx.fillRect(0, 0, size, size);

  bCtx.fillStyle = '#909090';
  bCtx.fillRect(0, 0, size, size);

  const plankH = size / planks;
  for (let p = 0; p < planks; p++) {
    const y0 = p * plankH;
    // Slight per-plank tonal variation
    const tint = Math.floor((rng() - 0.5) * 24);
    ctx.fillStyle = tint > 0 ? `rgba(255,245,225,0.08)` : `rgba(40,22,10,0.09)`;
    ctx.fillRect(0, y0, size, plankH);

    // Longitudinal grain lines
    for (let g = 0; g < 48; g++) {
      const gy = y0 + rng() * plankH;
      ctx.strokeStyle = grainHex;
      ctx.globalAlpha = 0.09 + rng() * 0.14;
      ctx.lineWidth = 0.8 + rng() * 1.8;
      ctx.beginPath();
      ctx.moveTo(0, gy);
      const wave = (rng() - 0.5) * 6;
      ctx.bezierCurveTo(size * 0.33, gy + wave, size * 0.66, gy - wave, size, gy);
      ctx.stroke();

      bCtx.strokeStyle = rng() > 0.5 ? '#b8b8b8' : '#646464';
      bCtx.globalAlpha = 0.25;
      bCtx.lineWidth = 1.2;
      bCtx.beginPath();
      bCtx.moveTo(0, gy);
      bCtx.lineTo(size, gy + wave * 0.3);
      bCtx.stroke();
    }
    ctx.globalAlpha = 1;
    bCtx.globalAlpha = 1;

    // Plank seam
    ctx.fillStyle = 'rgba(28, 18, 10, 0.45)';
    ctx.fillRect(0, y0, size, 2.5);
    bCtx.fillStyle = '#262626';
    bCtx.fillRect(0, y0, size, 3);
  }

  return {
    map: finalizeTexture(colorCanvas, { isColor: true, anisotropy }),
    bump: finalizeTexture(bumpCanvas, { isColor: false, anisotropy }),
  };
}

function createGraniteTextures(anisotropy: number) {
  const size = 512;
  const colorCanvas = document.createElement('canvas');
  colorCanvas.width = size;
  colorCanvas.height = size;
  const ctx = colorCanvas.getContext('2d')!;

  const bumpCanvas = document.createElement('canvas');
  bumpCanvas.width = size;
  bumpCanvas.height = size;
  const bCtx = bumpCanvas.getContext('2d')!;

  const rng = mulberry32(8821);
  ctx.fillStyle = '#8b9088';
  ctx.fillRect(0, 0, size, size);
  bCtx.fillStyle = '#808080';
  bCtx.fillRect(0, 0, size, size);

  // Mineral speckles & moss veins
  for (let i = 0; i < 600; i++) {
    const x = rng() * size;
    const y = rng() * size;
    const r = 4 + rng() * 22;
    const isMoss = rng() > 0.72;
    ctx.fillStyle = isMoss
      ? `rgba(82, 114, 68, ${0.14 + rng() * 0.16})`
      : `rgba(${110 + Math.floor(rng() * 60)}, ${114 + Math.floor(rng() * 56)}, ${108 + Math.floor(rng() * 52)}, 0.22)`;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();

    const bv = Math.floor(85 + rng() * 90);
    bCtx.fillStyle = `rgba(${bv},${bv},${bv},0.3)`;
    bCtx.beginPath();
    bCtx.arc(x, y, r * 0.85, 0, Math.PI * 2);
    bCtx.fill();
  }

  for (let i = 0; i < 3000; i++) {
    const x = rng() * size;
    const y = rng() * size;
    const s = 1 + rng() * 2.5;
    const v = rng() > 0.5 ? 210 : 65;
    ctx.fillStyle = `rgba(${v},${v},${v - 5},0.16)`;
    ctx.fillRect(x, y, s, s);
  }

  return {
    graniteMap: finalizeTexture(colorCanvas, { isColor: true, repeatX: 2, repeatY: 2, anisotropy }),
    graniteBump: finalizeTexture(bumpCanvas, { isColor: false, repeatX: 2, repeatY: 2, anisotropy }),
  };
}

function createLotusLeafTexture(anisotropy: number): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const cx = size / 2;
  const cy = size / 2;

  const grad = ctx.createRadialGradient(cx, cy, 12, cx, cy, size * 0.5);
  grad.addColorStop(0, '#629c52');
  grad.addColorStop(0.55, '#428340');
  grad.addColorStop(0.92, '#2f6a33');
  grad.addColorStop(1, '#587836');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);

  // Radial botanical veins
  ctx.strokeStyle = 'rgba(178, 224, 146, 0.36)';
  const veinCount = 18;
  for (let i = 0; i < veinCount; i++) {
    const ang = (i / veinCount) * Math.PI * 2;
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    const ex = cx + Math.cos(ang) * size * 0.46;
    const ey = cy + Math.sin(ang) * size * 0.46;
    ctx.quadraticCurveTo(
      cx + Math.cos(ang + 0.12) * size * 0.25,
      cy + Math.sin(ang + 0.12) * size * 0.25,
      ex,
      ey,
    );
    ctx.stroke();
  }

  // Center stem dimple
  ctx.fillStyle = '#8ebc64';
  ctx.beginPath();
  ctx.arc(cx, cy, 14, 0, Math.PI * 2);
  ctx.fill();

  return finalizeTexture(canvas, { isColor: true, clamp: true, anisotropy });
}

function createBambooTexture(anisotropy: number): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  const grad = ctx.createLinearGradient(0, 0, size, 0);
  grad.addColorStop(0, '#6a8443');
  grad.addColorStop(0.5, '#89a354');
  grad.addColorStop(1, '#5d7438');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);

  // Bamboo node rings
  for (let y = 32; y < size; y += 64) {
    ctx.fillStyle = '#4c5e2c';
    ctx.fillRect(0, y - 3, size, 6);
    ctx.fillStyle = '#a4ba72';
    ctx.fillRect(0, y + 3, size, 2);
  }

  return finalizeTexture(canvas, { isColor: true, anisotropy });
}

function createThatchShingleTexture(anisotropy: number): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const rng = mulberry32(419);

  ctx.fillStyle = '#5a4636';
  ctx.fillRect(0, 0, size, size);

  const rows = 10;
  const cols = 8;
  const rowH = size / rows;
  const colW = size / cols;

  for (let r = 0; r < rows; r++) {
    const offset = (r % 2) * (colW * 0.5);
    for (let c = -1; c <= cols; c++) {
      const x = c * colW + offset;
      const y = r * rowH;
      const tone = Math.floor((rng() - 0.5) * 28);
      ctx.fillStyle = `rgb(${84 + tone}, ${66 + tone}, ${52 + tone})`;
      ctx.fillRect(x + 2, y + 2, colW - 4, rowH - 3);
      ctx.fillStyle = 'rgba(20, 14, 10, 0.36)';
      ctx.fillRect(x, y + rowH - 3, colW, 3);
    }
  }

  return finalizeTexture(canvas, { isColor: true, repeatX: 2, repeatY: 2, anisotropy });
}

function createContactShadowTexture(): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const cx = size / 2;
  const grad = ctx.createRadialGradient(cx, cx, 8, cx, cx, cx);
  grad.addColorStop(0, 'rgba(16, 28, 22, 0.58)');
  grad.addColorStop(0.5, 'rgba(16, 28, 22, 0.24)');
  grad.addColorStop(1, 'rgba(16, 28, 22, 0.0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);
  return finalizeTexture(canvas, { isColor: true, clamp: true, anisotropy: 1 });
}

/**
 * Generates an anatomical UV-mapped fish skin texture.
 * UV convention for our lofted fish body:
 * - U (x: 0..512): 0 = nose tip, 512 = tail peduncle
 * - V (y: 0..256): 0 = dorsal crest, 0.5 (128) = belly seam, 1.0 (256) = dorsal crest (wraps around circumference)
 *   Wait: Let's make V=0.5 dorsal top and V=0 / V=1 belly, OR V=0.5 belly?
 *   Let's align with our loft UV: angle theta=0 is dorsal crest (top, +Y), theta=PI/2 is right flank (+Z),
 *   theta=PI is belly (-Y), theta=3PI/2 is left flank (-Z), theta=2PI is dorsal crest (+Y).
 *   So in canvas Y (where top of canvas v=1 or v=0 depending on flipY=true):
 *   CanvasTexture default flipY=true -> v=0 is bottom of canvas, v=1 is top of canvas.
 *   Since theta wraps 0..2PI -> v = theta / 2PI:
 *   y=0 (top of canvas, v=1) & y=256 (bottom, v=0) = DORSAL RIDGE!
 *   y=64 (v=0.75) = Left flank; y=192 (v=0.25) = Right flank; y=128 (v=0.5) = BELLY!
 */
function createFishSkinTexture(patternId: FishPatternId, anisotropy: number): THREE.CanvasTexture {
  const w = 512;
  const h = 256;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;
  const rng = mulberry32(
    patternId.split('').reduce((acc, ch) => acc * 31 + ch.charCodeAt(0), 17),
  );

  const drawVerticalCounterShade = (dorsal: string, flank: string, belly: string) => {
    const grad = ctx.createLinearGradient(0, 0, 0, h);
    grad.addColorStop(0.0, dorsal);
    grad.addColorStop(0.26, flank);
    grad.addColorStop(0.5, belly);
    grad.addColorStop(0.74, flank);
    grad.addColorStop(1.0, dorsal);
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);
  };

  const drawOrganicBlotches = (
    color: string,
    blobs: Array<{ x: number; y: number; rx: number; ry: number; rot?: number }>,
  ) => {
    ctx.fillStyle = color;
    for (const b of blobs) {
      ctx.save();
      ctx.translate(b.x * w, b.y * h);
      ctx.rotate(b.rot ?? 0);
      ctx.beginPath();
      ctx.ellipse(0, 0, b.rx * w, b.ry * h, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  };

  switch (patternId) {
    case 'koi_kohaku': {
      drawVerticalCounterShade('#f8f6ef', '#fcfbf6', '#f2efe6');
      // Classic vermilion Kohaku patches wrapping across the dorsal ridge (near y=0 and y=1)
      const hiColor = '#e23b1e';
      drawOrganicBlotches(hiColor, [
        { x: 0.16, y: 0.04, rx: 0.09, ry: 0.16, rot: 0.2 },
        { x: 0.16, y: 0.96, rx: 0.09, ry: 0.16, rot: -0.2 },
        { x: 0.42, y: 0.06, rx: 0.14, ry: 0.21, rot: -0.15 },
        { x: 0.42, y: 0.94, rx: 0.14, ry: 0.21, rot: 0.15 },
        { x: 0.72, y: 0.03, rx: 0.11, ry: 0.17, rot: 0.1 },
        { x: 0.72, y: 0.97, rx: 0.11, ry: 0.17, rot: -0.1 },
      ]);
      break;
    }
    case 'koi_showa': {
      drawVerticalCounterShade('#f5f3ec', '#faf8f2', '#ece9df');
      drawOrganicBlotches('#d9381e', [
        { x: 0.18, y: 0.05, rx: 0.1, ry: 0.18 },
        { x: 0.18, y: 0.95, rx: 0.1, ry: 0.18 },
        { x: 0.56, y: 0.04, rx: 0.13, ry: 0.2 },
        { x: 0.56, y: 0.96, rx: 0.13, ry: 0.2 },
      ]);
      drawOrganicBlotches('#1d2024', [
        { x: 0.09, y: 0.14, rx: 0.05, ry: 0.11, rot: 0.4 },
        { x: 0.34, y: 0.08, rx: 0.09, ry: 0.19, rot: -0.3 },
        { x: 0.34, y: 0.92, rx: 0.09, ry: 0.19, rot: 0.3 },
        { x: 0.76, y: 0.05, rx: 0.08, ry: 0.16 },
        { x: 0.76, y: 0.95, rx: 0.08, ry: 0.16 },
      ]);
      break;
    }
    case 'koi_ogon': {
      drawVerticalCounterShade('#e59a1a', '#f7be38', '#fae08a');
      break;
    }
    case 'koi_tancho': {
      drawVerticalCounterShade('#fbfaf6', '#ffffff', '#f0eee7');
      // Iconic crimson crown circle on head
      drawOrganicBlotches('#dc261b', [
        { x: 0.13, y: 0.0, rx: 0.055, ry: 0.095 },
        { x: 0.13, y: 1.0, rx: 0.055, ry: 0.095 },
      ]);
      break;
    }
    case 'koi_asagi': {
      drawVerticalCounterShade('#496b88', '#789bb5', '#e55934');
      break;
    }
    case 'koi_black': {
      drawVerticalCounterShade('#14171c', '#262b33', '#6e7278');
      drawOrganicBlotches('#3a3e46', [
        { x: 0.25, y: 0.14, rx: 0.12, ry: 0.16, rot: 0.2 },
        { x: 0.62, y: 0.86, rx: 0.14, ry: 0.18, rot: -0.2 },
      ]);
      break;
    }
    case 'food_grass_carp': {
      drawVerticalCounterShade('#485838', '#8a956e', '#d8d5bf');
      break;
    }
    case 'food_carp': {
      drawVerticalCounterShade('#5c4724', '#b88b44', '#ebd9ae');
      break;
    }
    case 'food_tilapia': {
      drawVerticalCounterShade('#3f4f58', '#8fa3ad', '#dde4e7');
      // Subtle vertical tilapia bars
      ctx.fillStyle = 'rgba(36, 48, 56, 0.28)';
      for (let bx = 0.25; bx <= 0.85; bx += 0.11) {
        ctx.fillRect(bx * w, 0, w * 0.032, h * 0.34);
        ctx.fillRect(bx * w, h * 0.66, w * 0.032, h * 0.34);
      }
      break;
    }
    case 'food_mandarin': {
      drawVerticalCounterShade('#6c582b', '#c9a65a', '#eadbb2');
      // Marbled dark olive-brown spots
      for (let i = 0; i < 42; i++) {
        const bx = 0.22 + rng() * 0.7;
        const by = rng() > 0.5 ? rng() * 0.34 : 0.66 + rng() * 0.34;
        drawOrganicBlotches('rgba(62, 46, 20, 0.55)', [
          {
            x: bx,
            y: by,
            rx: 0.015 + rng() * 0.025,
            ry: 0.03 + rng() * 0.045,
            rot: rng() * Math.PI,
          },
        ]);
      }
      break;
    }
    case 'food_crucian': {
      drawVerticalCounterShade('#5a4e32', '#b39a5d', '#e4d6ad');
      break;
    }
  }

  // Subtle diamond scale mesh overlay on body (x > 0.22)
  ctx.strokeStyle =
    patternId === 'koi_asagi'
      ? 'rgba(220, 236, 250, 0.35)'
      : patternId.startsWith('food_')
        ? 'rgba(35, 32, 22, 0.22)'
        : 'rgba(255, 255, 255, 0.16)';
  ctx.lineWidth = 1.0;
  const stepX = 14;
  const stepY = 12;
  for (let x = w * 0.2; x < w * 0.96; x += stepX) {
    const colOffset = Math.floor(x / stepX) % 2 === 0 ? 0 : stepY * 0.5;
    for (let y = 0; y < h; y += stepY) {
      ctx.beginPath();
      ctx.arc(x, y + colOffset, 6.5, -Math.PI * 0.45, Math.PI * 0.45);
      ctx.stroke();
    }
  }

  // Operculum / gill arc detail around x = 0.21
  ctx.strokeStyle = 'rgba(40, 34, 28, 0.26)';
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.arc(w * 0.17, h * 0.25, h * 0.14, -0.7, 0.9);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(w * 0.17, h * 0.75, h * 0.14, -0.9, 0.7);
  ctx.stroke();

  return finalizeTexture(canvas, { isColor: true, clamp: true, anisotropy });
}

function createFinRayTexture(
  baseHex: string,
  tipHex: string,
  anisotropy: number,
): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  const grad = ctx.createLinearGradient(0, 0, size, 0);
  grad.addColorStop(0, baseHex);
  grad.addColorStop(0.75, baseHex);
  grad.addColorStop(1, tipHex);
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);

  // Delicate radial fin rays
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
  ctx.lineWidth = 1.5;
  for (let i = 0; i < 18; i++) {
    const y = (i / 17) * size;
    ctx.beginPath();
    ctx.moveTo(0, size * 0.5 + (y - size * 0.5) * 0.25);
    ctx.lineTo(size, y);
    ctx.stroke();
  }

  return finalizeTexture(canvas, { isColor: true, clamp: true, anisotropy });
}

export function createTextureBundle(renderer: THREE.WebGLRenderer): TextureBundle {
  const anisotropy = Math.min(renderer.capabilities.getMaxAnisotropy(), 8);

  const { meadowMap, meadowBump } = createMeadowTextures(anisotropy);
  const deckWood = createWoodTextures('#9c6e44', '#5c3a1f', 101, anisotropy, 6);
  const darkWood = createWoodTextures('#6e492a', '#3d2512', 202, anisotropy, 4);
  const { graniteMap, graniteBump } = createGraniteTextures(anisotropy);
  const lotusLeafMap = createLotusLeafTexture(anisotropy);
  const bambooMap = createBambooTexture(anisotropy);
  const thatchShingleMap = createThatchShingleTexture(anisotropy);
  const contactShadowMap = createContactShadowTexture();

  const fishSkinMaps: Record<FishPatternId, THREE.CanvasTexture> = {
    koi_kohaku: createFishSkinTexture('koi_kohaku', anisotropy),
    koi_showa: createFishSkinTexture('koi_showa', anisotropy),
    koi_ogon: createFishSkinTexture('koi_ogon', anisotropy),
    koi_black: createFishSkinTexture('koi_black', anisotropy),
    koi_tancho: createFishSkinTexture('koi_tancho', anisotropy),
    koi_asagi: createFishSkinTexture('koi_asagi', anisotropy),
    food_grass_carp: createFishSkinTexture('food_grass_carp', anisotropy),
    food_carp: createFishSkinTexture('food_carp', anisotropy),
    food_tilapia: createFishSkinTexture('food_tilapia', anisotropy),
    food_mandarin: createFishSkinTexture('food_mandarin', anisotropy),
    food_crucian: createFishSkinTexture('food_crucian', anisotropy),
  };

  const finRayMaps = {
    koiWhite: createFinRayTexture('#f8f5ec', '#ffffff', anisotropy),
    koiGold: createFinRayTexture('#f3b63a', '#fce8a6', anisotropy),
    koiRedTip: createFinRayTexture('#f6f3ea', '#e64b2c', anisotropy),
    koiBlack: createFinRayTexture('#23272e', '#4d5460', anisotropy),
    edibleOlive: createFinRayTexture('#75805d', '#a5ae8d', anisotropy),
    edibleAmber: createFinRayTexture('#b59858', '#dec88e', anisotropy),
  };

  const allTextures: THREE.Texture[] = [
    meadowMap,
    meadowBump,
    deckWood.map,
    deckWood.bump,
    darkWood.map,
    darkWood.bump,
    graniteMap,
    graniteBump,
    lotusLeafMap,
    bambooMap,
    thatchShingleMap,
    contactShadowMap,
    ...Object.values(fishSkinMaps),
    ...Object.values(finRayMaps),
  ];

  return {
    meadowMap,
    meadowBump,
    woodDeckMap: deckWood.map,
    woodDeckBump: deckWood.bump,
    woodDarkMap: darkWood.map,
    graniteMap,
    graniteBump,
    lotusLeafMap,
    bambooMap,
    thatchShingleMap,
    contactShadowMap,
    fishSkinMaps,
    finRayMaps,
    dispose: () => {
      allTextures.forEach((t) => t.dispose());
    },
  };
}
