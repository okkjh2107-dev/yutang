import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { MAX_POND_LEVEL, getPondTier } from '../game/catalog';
import type { CameraPresetId, FishLiveState, ManagedFish, SceneSelection } from '../types/pond';
import {
  CAMERA_PRESETS,
  FOG_COLOR,
  SCENE_BG_COLOR,
  WATER_LEVEL,
  getPondVisualScale,
  pondSignedDistance,
  setPondVisualScale,
} from './constants';
import { createAnglerSystem } from './anglerSystem';
import { createEnvironmentDecor } from './environmentDecor';
import { createFishSystem } from './fishSystem';
import { createMaterialBundle } from './materials';
import { createTerrainAndWater } from './terrainAndWater';
import { createTextureBundle } from './textures';

export interface SceneCallbacks {
  initialFishes: ManagedFish[];
  initialAnglerCount?: number;
  initialPondLevel?: number;
  onSelectionChange: (selection: SceneSelection) => void;
  onWebGLUnavailable?: () => void;
}

const _raycaster = new THREE.Raycaster();
const _pointerNdc = new THREE.Vector2();
const _targetPos = new THREE.Vector3();
const _targetLook = new THREE.Vector3();

function detectSoftwareWebGL(): boolean {
  try {
    const probeCanvas = document.createElement('canvas');
    const gl = probeCanvas.getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

export class PondSceneManager {
  private container: HTMLElement;
  private callbacks: SceneCallbacks;
  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.OrthographicCamera;
  private controls!: OrbitControls;
  private clock = new THREE.Clock();
  private isSoftwareGl = false;
  private frameId = 0;
  private disposed = false;

  private textures!: ReturnType<typeof createTextureBundle>;
  private materials!: ReturnType<typeof createMaterialBundle>;
  private terrainAndWater!: ReturnType<typeof createTerrainAndWater>;
  private decor!: ReturnType<typeof createEnvironmentDecor>;
  private anglerSystem!: ReturnType<typeof createAnglerSystem>;
  private fishSystem!: ReturnType<typeof createFishSystem>;
  private envRT: THREE.WebGLRenderTarget | null = null;

  private resizeObserver: ResizeObserver | null = null;
  private selectedFishId: string | null = null;
  private selectedPond = false;
  private liveSyncTimer = 0;
  private currentPondLevel = 1;
  private currentAnglerCount = 2;

  // Smooth eased camera pan/zoom transition state
  private cameraTransition: {
    active: boolean;
    startPos: THREE.Vector3;
    endPos: THREE.Vector3;
    startLook: THREE.Vector3;
    endLook: THREE.Vector3;
    startZoom: number;
    endZoom: number;
    elapsed: number;
    duration: number;
    zoomBreath: number;
  } = {
    active: false,
    startPos: new THREE.Vector3(),
    endPos: new THREE.Vector3(),
    startLook: new THREE.Vector3(),
    endLook: new THREE.Vector3(),
    startZoom: 1,
    endZoom: 1,
    elapsed: 0,
    duration: 0.75,
    zoomBreath: 0,
  };
  private manualZoomTarget: number | null = null;

  // Dynamic pond renovation / upgrade celebration effect state
  private renovationGroup: THREE.Group | null = null;
  private renovationRings: Array<{
    mesh: THREE.Mesh;
    mat: THREE.MeshBasicMaterial;
    delay: number;
    maxRadius: number;
  }> = [];
  private renovationSparkles: Array<{
    mesh: THREE.Mesh;
    mat: THREE.MeshBasicMaterial;
    startX: number;
    startY: number;
    startZ: number;
    vx: number;
    vy: number;
    vz: number;
    delay: number;
    spinSpeed: number;
    baseScale: number;
  }> = [];
  private renovationOwnedGeos: THREE.BufferGeometry[] = [];
  private renovationOwnedMats: THREE.Material[] = [];
  private renovationElapsed = 0;
  private renovationDuration = 1.85;
  private renovationActive = false;
  private renovationStartScaleRatio = 1.0;
  private renovationTargetScale = 1.0;
  private renovationWave2Fired = false;
  private renovationWave3Fired = false;

  // Pointer click-vs-drag tracking
  private pointerDownPos = { x: 0, y: 0 };
  private pointerActive = false;
  private lastHoverCheck = 0;

  constructor(container: HTMLElement, callbacks: SceneCallbacks) {
    this.container = container;
    this.callbacks = callbacks;
    this.init();
  }

  private init() {
    this.isSoftwareGl = detectSoftwareWebGL();
    this.currentPondLevel = this.callbacks.initialPondLevel ?? 1;
    this.currentAnglerCount = this.callbacks.initialAnglerCount ?? 2;
    setPondVisualScale(getPondTier(this.currentPondLevel).visualScale);

    try {
      this.renderer = new THREE.WebGLRenderer({
        antialias: !this.isSoftwareGl,
        powerPreference: 'high-performance',
      });
    } catch {
      this.callbacks.onWebGLUnavailable?.();
      return;
    }

    const width = Math.max(this.container.clientWidth, 1);
    const height = Math.max(this.container.clientHeight, 1);

    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.setPixelRatio(
      this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2),
    );
    this.renderer.setSize(width, height);
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.container.appendChild(this.renderer.domElement);

    // Scene & atmospheric fog
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(SCENE_BG_COLOR);
    this.scene.fog = new THREE.FogExp2(FOG_COLOR, 0.011);

    // Mandatory studio environment map for crisp water/brass/wet-stone reflections
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    const roomEnv = new RoomEnvironment();
    this.envRT = pmremGenerator.fromScene(roomEnv, 0.04);
    this.scene.environment = this.envRT.texture;
    roomEnv.dispose();
    pmremGenerator.dispose();

    // 45-degree Isometric OrthographicCamera
    this.camera = new THREE.OrthographicCamera(-10, 10, 7, -7, 0.1, 180);
    this.updateCameraFrustum(width, height);

    const s = getPondVisualScale();
    const initialPreset = CAMERA_PRESETS[0];
    this.camera.position.set(...initialPreset.position);
    this.camera.zoom = initialPreset.zoom / (1 + (s - 1) * 0.16);
    this.camera.updateProjectionMatrix();

    // OrbitControls tuned for 2.5D manor inspection on desktop & touch
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.target.set(...initialPreset.target);
    this.controls.enableDamping = !this.isSoftwareGl;
    this.controls.dampingFactor = 0.07;
    this.controls.enableRotate = true;
    this.controls.enablePan = true;
    this.controls.enableZoom = true;
    this.controls.screenSpacePanning = false;
    this.controls.minPolarAngle = 0.42;
    this.controls.maxPolarAngle = 1.18;
    this.controls.minZoom = 0.34;
    this.controls.maxZoom = 2.8;
    this.controls.rotateSpeed = 0.72;
    this.controls.panSpeed = 0.85;
    this.controls.zoomSpeed = 0.9;
    this.controls.update();

    this.controls.addEventListener('start', () => {
      this.cameraTransition.active = false;
      this.manualZoomTarget = null;
    });

    // 3-Point Warm Sun + Cool Sky/Ground Outdoor Daylight Rig
    this.setupLighting();

    // Procedural Textures, Materials, Terrain, Water, Decor & Fish School
    this.textures = createTextureBundle(this.renderer);
    this.materials = createMaterialBundle(this.textures);
    this.terrainAndWater = createTerrainAndWater(this.materials);
    this.decor = createEnvironmentDecor(this.materials, this.currentPondLevel);
    this.anglerSystem = createAnglerSystem(this.materials);
    this.anglerSystem.setVisibleCount(this.currentAnglerCount);
    this.fishSystem = createFishSystem(this.textures, this.materials, this.callbacks.initialFishes);

    this.scene.add(this.terrainAndWater.terrainMesh);
    this.scene.add(this.terrainAndWater.waterMesh);
    this.scene.add(this.decor.group);
    this.scene.add(this.anglerSystem.group);
    this.scene.add(this.fishSystem.group);

    this.initRenovationVfxPool();

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    this.bindEvents();
    this.tick();
  }

  private setupLighting() {
    const hemiLight = new THREE.HemisphereLight(0xc2e2ff, 0x4b6344, 0.95);
    hemiLight.position.set(0, 30, 0);
    this.scene.add(hemiLight);

    const sunLight = new THREE.DirectionalLight(0xfff1d4, 2.35);
    sunLight.position.set(22, 28, 18);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.set(2048, 2048);
    sunLight.shadow.camera.near = 2;
    sunLight.shadow.camera.far = 90;
    const d = 28;
    sunLight.shadow.camera.left = -d;
    sunLight.shadow.camera.right = d;
    sunLight.shadow.camera.top = d;
    sunLight.shadow.camera.bottom = -d;
    sunLight.shadow.bias = -0.0004;
    sunLight.shadow.normalBias = 0.025;
    sunLight.shadow.radius = 2.5;
    this.scene.add(sunLight);

    const rimLight = new THREE.DirectionalLight(0xc8e4ff, 0.58);
    rimLight.position.set(-16, 12, -18);
    this.scene.add(rimLight);
  }

  private initRenovationVfxPool() {
    const group = new THREE.Group();
    group.name = 'pond-renovation-vfx';
    group.visible = false;

    const ringGeo = new THREE.RingGeometry(0.88, 1.0, 48);
    ringGeo.rotateX(-Math.PI / 2);
    this.renovationOwnedGeos.push(ringGeo);

    const ringSpecs = [
      { color: 0xf7cf6d, delay: 0.0 },
      { color: 0x5be6be, delay: 0.16 },
      { color: 0xb7f7e4, delay: 0.34 },
    ];
    for (const spec of ringSpecs) {
      const mat = new THREE.MeshBasicMaterial({
        color: spec.color,
        transparent: true,
        opacity: 0,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
      });
      this.renovationOwnedMats.push(mat);
      const mesh = new THREE.Mesh(ringGeo, mat);
      mesh.position.y = WATER_LEVEL + 0.045;
      mesh.renderOrder = 6;
      group.add(mesh);
      this.renovationRings.push({
        mesh,
        mat,
        delay: spec.delay,
        maxRadius: 9.5,
      });
    }

    const sparkleGeo = new THREE.OctahedronGeometry(0.11, 0);
    this.renovationOwnedGeos.push(sparkleGeo);
    const sparkleColors = [0xfde07c, 0x67eec8, 0xfff5d6, 0x9cf5dc];

    for (let i = 0; i < 48; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: sparkleColors[i % sparkleColors.length],
        transparent: true,
        opacity: 0,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
      });
      this.renovationOwnedMats.push(mat);
      const mesh = new THREE.Mesh(sparkleGeo, mat);
      mesh.renderOrder = 7;
      group.add(mesh);
      this.renovationSparkles.push({
        mesh,
        mat,
        startX: 0,
        startY: 0.3,
        startZ: 0,
        vx: 0,
        vy: 2.2,
        vz: 0,
        delay: (i % 12) * 0.04,
        spinSpeed: 3.5 + (i % 5) * 1.2,
        baseScale: 0.75 + (i % 4) * 0.32,
      });
    }

    this.renovationGroup = group;
    this.scene.add(group);
  }

  private startRenovationEffect(prevScale: number, newScale: number) {
    if (!this.renovationGroup) return;
    this.renovationActive = true;
    this.renovationElapsed = 0;
    this.renovationTargetScale = newScale;
    this.renovationStartScaleRatio =
      newScale > prevScale
        ? THREE.MathUtils.clamp(prevScale / newScale, 0.72, 0.96)
        : 0.94;
    this.renovationWave2Fired = false;
    this.renovationWave3Fired = false;
    this.renovationGroup.visible = true;

    // Start newly expanded terrain, water, decor & anglers from previous scale ratio for seamless expansion
    this.terrainAndWater.terrainMesh.scale.set(
      this.renovationStartScaleRatio,
      1,
      this.renovationStartScaleRatio,
    );
    this.terrainAndWater.waterMesh.scale.set(
      this.renovationStartScaleRatio,
      1,
      this.renovationStartScaleRatio,
    );
    this.decor.group.scale.set(
      this.renovationStartScaleRatio,
      0.9,
      this.renovationStartScaleRatio,
    );
    this.anglerSystem.group.scale.set(
      this.renovationStartScaleRatio,
      1,
      this.renovationStartScaleRatio,
    );

    this.renovationRings.forEach((ring, idx) => {
      ring.maxRadius = (idx === 0 ? 9.8 : idx === 1 ? 8.5 : 10.6) * newScale;
      ring.mesh.scale.setScalar(0.5 * newScale);
      ring.mat.opacity = 0;
    });

    this.renovationSparkles.forEach((sp, i) => {
      const ang = (i / this.renovationSparkles.length) * Math.PI * 2;
      const ringRadius = (i % 3 === 0 ? 1.8 : i % 3 === 1 ? 4.8 : 7.4) * newScale;
      sp.startX = Math.cos(ang) * ringRadius * 1.12;
      sp.startZ = Math.sin(ang) * ringRadius * 0.86;
      sp.startY = 0.25 + (i % 4) * 0.22;
      sp.vx = Math.cos(ang) * 0.95 * newScale;
      sp.vy = 2.1 + (i % 5) * 0.55;
      sp.vz = Math.sin(ang) * 0.72 * newScale;
      sp.delay = (i % 10) * 0.035;
      sp.mesh.position.set(sp.startX, sp.startY, sp.startZ);
      sp.mat.opacity = 0;
    });

    // Multi-wave celebratory water ripple surge (Wave 1: central & cove burst)
    const t = this.clock.elapsedTime;
    this.materials?.pushRipple(0.0, 0.0, t, 1.65);
    this.materials?.pushRipple(-4.2 * newScale, -1.8 * newScale, t + 0.06, 1.4);
    this.materials?.pushRipple(4.2 * newScale, -1.2 * newScale, t + 0.12, 1.4);
    this.materials?.pushRipple(1.4 * newScale, 2.4 * newScale, t + 0.18, 1.35);
  }

  private updateRenovationEffect(dt: number) {
    if (!this.renovationActive || !this.renovationGroup) return;

    this.renovationElapsed += dt;
    const progress = Math.min(1, this.renovationElapsed / this.renovationDuration);
    const s = this.renovationTargetScale;

    // Trigger staggered perimeter shoreline ripple waves during expansion
    if (!this.renovationWave2Fired && this.renovationElapsed >= 0.42) {
      this.renovationWave2Fired = true;
      const t = this.clock.elapsedTime;
      this.materials?.pushRipple(-5.8 * s, 1.6 * s, t, 1.4);
      this.materials?.pushRipple(5.6 * s, 1.8 * s, t + 0.06, 1.35);
      this.materials?.pushRipple(-1.8 * s, -3.2 * s, t + 0.12, 1.35);
    }
    if (!this.renovationWave3Fired && this.renovationElapsed >= 0.85) {
      this.renovationWave3Fired = true;
      const t = this.clock.elapsedTime;
      this.materials?.pushRipple(0.0, 0.1 * s, t, 1.45);
      this.materials?.pushRipple(3.6 * s, -2.5 * s, t + 0.08, 1.25);
    }

    // 1. Real-time physical pond expansion & elastic spring settle
    const expandProgress = Math.min(1, this.renovationElapsed / 0.95);
    const easeOutQuart = 1 - Math.pow(1 - expandProgress, 4);
    const xzScale = THREE.MathUtils.lerp(this.renovationStartScaleRatio, 1.0, easeOutQuart);

    const settleProgress = Math.min(1, this.renovationElapsed / 1.15);
    const c1 = 1.70158;
    const c3 = c1 + 1;
    const inv = settleProgress - 1;
    const easeOutBack = 1 + c3 * inv * inv * inv + c1 * inv * inv;
    const decorYScale = THREE.MathUtils.lerp(0.88, 1.0, easeOutBack);

    this.terrainAndWater.terrainMesh.scale.set(xzScale, 1, xzScale);
    this.terrainAndWater.waterMesh.scale.set(xzScale, 1, xzScale);
    this.anglerSystem.group.scale.set(xzScale, 1, xzScale);
    this.decor.group.scale.set(xzScale, Math.max(0.86, decorYScale), xzScale);

    this.terrainAndWater.waterMesh.position.y =
      WATER_LEVEL + Math.sin(settleProgress * Math.PI) * 0.08 * (1 - settleProgress);

    // 2. Warm golden sunlight shimmer
    this.renderer.toneMappingExposure =
      1.08 + Math.sin(Math.min(1, this.renovationElapsed / 1.25) * Math.PI) * 0.18;

    // 3. Expanding jade & gold shockwave rings across water
    for (const ring of this.renovationRings) {
      const localT = (this.renovationElapsed - ring.delay) / 1.25;
      if (localT <= 0 || localT >= 1) {
        ring.mat.opacity = 0;
        continue;
      }
      const eased = 1 - Math.pow(1 - localT, 3);
      const radius = THREE.MathUtils.lerp(0.8, ring.maxRadius, eased);
      ring.mesh.scale.set(radius, 1, radius * 0.8);
      ring.mat.opacity = Math.sin(localT * Math.PI) * 0.68 * (1 - localT * 0.35);
    }

    // 4. Rising celebration sparkles around shoreline, bridge & gazebo
    for (const sp of this.renovationSparkles) {
      const localT = (this.renovationElapsed - sp.delay) / 1.3;
      if (localT <= 0 || localT >= 1) {
        sp.mat.opacity = 0;
        continue;
      }
      const easeUp = 1 - Math.pow(1 - localT, 2);
      const swirl = localT * 1.4;
      sp.mesh.position.set(
        sp.startX + sp.vx * easeUp + Math.cos(swirl + sp.spinSpeed) * 0.25,
        sp.startY + sp.vy * easeUp,
        sp.startZ + sp.vz * easeUp + Math.sin(swirl + sp.spinSpeed) * 0.25,
      );
      sp.mesh.rotation.y += dt * sp.spinSpeed;
      sp.mesh.rotation.x += dt * sp.spinSpeed * 0.7;
      const pulse = Math.sin(localT * Math.PI);
      sp.mesh.scale.setScalar(sp.baseScale * (0.4 + pulse * 0.95));
      sp.mat.opacity = pulse * 0.92;
    }

    if (progress >= 1) {
      this.renovationActive = false;
      this.renovationGroup.visible = false;
      this.terrainAndWater.terrainMesh.scale.set(1, 1, 1);
      this.terrainAndWater.waterMesh.scale.set(1, 1, 1);
      this.anglerSystem.group.scale.set(1, 1, 1);
      this.decor.group.scale.set(1, 1, 1);
      this.terrainAndWater.waterMesh.position.y = WATER_LEVEL;
      this.renderer.toneMappingExposure = 1.08;
    }
  }

  private beginSmoothCameraTransition(
    endPos: THREE.Vector3,
    endLook: THREE.Vector3,
    endZoom: number,
    duration: number,
    zoomBreath = 0,
  ) {
    this.manualZoomTarget = null;
    this.cameraTransition.active = true;
    this.cameraTransition.startPos.copy(this.camera.position);
    this.cameraTransition.endPos.copy(endPos);
    this.cameraTransition.startLook.copy(this.controls.target);
    this.cameraTransition.endLook.copy(endLook);
    this.cameraTransition.startZoom = this.camera.zoom;
    this.cameraTransition.endZoom = endZoom;
    this.cameraTransition.elapsed = 0;
    this.cameraTransition.duration = duration;
    this.cameraTransition.zoomBreath = zoomBreath;
  }

  private updateCameraFrustum(width: number, height: number) {
    const aspect = width / Math.max(height, 1);
    // Automatically expand frustum slightly on narrow portrait phones so the whole pond fits comfortably
    const baseHalfH = aspect < 1.0 ? 8.2 / Math.max(aspect, 0.52) * 0.68 : 7.4;
    this.camera.left = -baseHalfH * aspect;
    this.camera.right = baseHalfH * aspect;
    this.camera.top = baseHalfH;
    this.camera.bottom = -baseHalfH;
    this.camera.updateProjectionMatrix();
  }

  private bindEvents() {
    const canvas = this.renderer.domElement;

    this.resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const w = Math.max(entry.contentRect.width, 1);
        const h = Math.max(entry.contentRect.height, 1);
        this.updateCameraFrustum(w, h);
        this.renderer.setSize(w, h);
      }
    });
    this.resizeObserver.observe(this.container);

    canvas.addEventListener('pointerdown', this.onPointerDown);
    canvas.addEventListener('pointerup', this.onPointerUp);
    canvas.addEventListener('pointermove', this.onPointerMove);
    canvas.addEventListener('webglcontextlost', this.onContextLost);
    canvas.addEventListener('webglcontextrestored', this.onContextRestored);
  }

  private onContextLost = (e: Event) => {
    e.preventDefault();
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);
  };

  private onContextRestored = () => {
    if (!this.disposed) {
      this.clock.start();
      this.tick();
    }
  };

  private updateNdc(clientX: number, clientY: number) {
    const rect = this.renderer.domElement.getBoundingClientRect();
    _pointerNdc.x = ((clientX - rect.left) / rect.width) * 2 - 1;
    _pointerNdc.y = -((clientY - rect.top) / rect.height) * 2 + 1;
  }

  private onPointerDown = (e: PointerEvent) => {
    if (e.button !== 0 && e.pointerType === 'mouse') return;
    this.pointerDownPos.x = e.clientX;
    this.pointerDownPos.y = e.clientY;
    this.pointerActive = true;
  };

  private onPointerUp = (e: PointerEvent) => {
    if (!this.pointerActive) return;
    this.pointerActive = false;

    const moveDist = Math.hypot(
      e.clientX - this.pointerDownPos.x,
      e.clientY - this.pointerDownPos.y,
    );
    if (moveDist > 7) return; // Dragged to orbit/pan, not a click

    this.handlePick(e.clientX, e.clientY);
  };

  private onPointerMove = (e: PointerEvent) => {
    if (e.pointerType !== 'mouse') return;
    const now = performance.now();
    if (now - this.lastHoverCheck < 55) return;
    this.lastHoverCheck = now;

    this.updateNdc(e.clientX, e.clientY);
    _raycaster.setFromCamera(_pointerNdc, this.camera);

    const fishHits = _raycaster.intersectObjects(this.fishSystem.hitMeshes, false);
    if (fishHits.length > 0) {
      this.renderer.domElement.style.cursor = 'pointer';
      return;
    }

    const waterHits = _raycaster.intersectObject(this.terrainAndWater.waterMesh, false);
    if (
      waterHits.length > 0 &&
      pondSignedDistance(waterHits[0].point.x, waterHits[0].point.z) < 0.05
    ) {
      this.renderer.domElement.style.cursor = 'pointer';
      return;
    }

    this.renderer.domElement.style.cursor = 'grab';
  };

  private handlePick(clientX: number, clientY: number) {
    this.updateNdc(clientX, clientY);
    _raycaster.setFromCamera(_pointerNdc, this.camera);
    const elapsed = this.clock.elapsedTime;

    // 1. Check Fish first
    const fishHits = _raycaster.intersectObjects(this.fishSystem.hitMeshes, false);
    if (fishHits.length > 0) {
      const fishId = fishHits[0].object.userData?.fishId as string | undefined;
      if (fishId) {
        this.selectedPond = false;
        this.selectedFishId = fishId;
        this.fishSystem.setSelectedFish(fishId);
        this.materials.pushRipple(fishHits[0].point.x, fishHits[0].point.z, elapsed, 0.75);
        const live = this.fishSystem.getFishLiveState(fishId);
        if (live) {
          this.callbacks.onSelectionChange({ type: 'fish', fish: live });
        }
        return;
      }
    }

    // 2. Check Pond water / submerged basin
    const pondTargets = [this.terrainAndWater.waterMesh, this.terrainAndWater.terrainMesh];
    const pondHits = _raycaster.intersectObjects(pondTargets, false);
    if (pondHits.length > 0) {
      const pt = pondHits[0].point;
      if (pondSignedDistance(pt.x, pt.z) < 0.14) {
        this.selectedFishId = null;
        this.selectedPond = true;
        this.fishSystem.setSelectedFish(null);
        this.materials.pushRipple(pt.x, pt.z, elapsed, 1.15);
        this.callbacks.onSelectionChange({ type: 'pond' });
        return;
      }
    }

    // 3. Clicked outside pond -> clear selection
    if (this.selectedFishId || this.selectedPond) {
      this.clearSelection();
    }
  }

  public syncFishes(fishes: ManagedFish[], withSplashForNew = false) {
    this.fishSystem?.syncFishes(fishes, withSplashForNew);
    if (this.selectedFishId) {
      const live = this.fishSystem?.getFishLiveState(this.selectedFishId);
      if (live) {
        this.callbacks.onSelectionChange({ type: 'fish', fish: live });
      } else {
        this.selectedFishId = null;
        this.callbacks.onSelectionChange({ type: 'none' });
      }
    }
  }

  public selectFishById(fishId: string) {
    this.selectedPond = false;
    this.selectedFishId = fishId;
    this.fishSystem?.setSelectedFish(fishId);
    const live = this.fishSystem?.getFishLiveState(fishId);
    if (live) {
      this.callbacks.onSelectionChange({ type: 'fish', fish: live });
    }
  }

  public triggerFeedingEffect() {
    this.fishSystem?.triggerFeedingBurst();
  }

  public setAnglerCount(count: number) {
    this.currentAnglerCount = count;
    this.anglerSystem?.setVisibleCount(count);
  }

  public setPondLevel(level: number) {
    const normalizedLevel = Math.max(1, Math.min(MAX_POND_LEVEL, level));
    if (normalizedLevel === this.currentPondLevel) return;
    const prevLevel = this.currentPondLevel;
    const prevScale = getPondTier(prevLevel).visualScale;
    this.currentPondLevel = normalizedLevel;

    const s = getPondTier(normalizedLevel).visualScale;
    setPondVisualScale(s);

    if (this.scene && this.materials) {
      // Remove and dispose old scaled geometry layers (materials/textures remain shared)
      this.scene.remove(this.terrainAndWater.terrainMesh);
      this.scene.remove(this.terrainAndWater.waterMesh);
      this.scene.remove(this.decor.group);
      this.scene.remove(this.anglerSystem.group);

      this.terrainAndWater.dispose();
      this.decor.dispose();
      this.anglerSystem.dispose();

      // Rebuild terrain basin, water surface, shoreline decor, and angler positions at new scale
      this.terrainAndWater = createTerrainAndWater(this.materials);
      this.decor = createEnvironmentDecor(this.materials, this.currentPondLevel);
      this.anglerSystem = createAnglerSystem(this.materials);
      this.anglerSystem.setVisibleCount(this.currentAnglerCount);

      this.scene.add(this.terrainAndWater.terrainMesh);
      this.scene.add(this.terrainAndWater.waterMesh);
      this.scene.add(this.decor.group);
      this.scene.add(this.anglerSystem.group);

      // Keep fish group & renovation VFX above rebuilt water/terrain
      this.scene.remove(this.fishSystem.group);
      this.scene.add(this.fishSystem.group);
      if (this.renovationGroup) {
        this.scene.remove(this.renovationGroup);
        this.scene.add(this.renovationGroup);
      }

      const preset = CAMERA_PRESETS[0];
      _targetPos.set(...preset.position);
      _targetLook.set(...preset.target);
      const targetZoom = preset.zoom / (1 + (s - 1) * 0.16);

      if (normalizedLevel > prevLevel) {
        this.startRenovationEffect(prevScale, s);
        // Smoothly glide and zoom with a subtle aerial breath so pond expansion is immediately felt
        this.beginSmoothCameraTransition(_targetPos, _targetLook, targetZoom, 1.25, 0.065);
      } else {
        this.renovationActive = false;
        if (this.renovationGroup) this.renovationGroup.visible = false;
        this.terrainAndWater.terrainMesh.scale.set(1, 1, 1);
        this.terrainAndWater.waterMesh.scale.set(1, 1, 1);
        this.anglerSystem.group.scale.set(1, 1, 1);
        this.decor.group.scale.set(1, 1, 1);
        this.renderer.toneMappingExposure = 1.08;
        this.triggerCareRipple();
        this.beginSmoothCameraTransition(_targetPos, _targetLook, targetZoom, 0.75, 0);
      }
    }
  }

  public triggerCareRipple() {
    const s = getPondVisualScale();
    const t = this.clock.elapsedTime;
    this.materials?.pushRipple(-3.9 * s, -2.4 * s, t, 1.25);
    this.materials?.pushRipple(0.0, 0.2 * s, t + 0.1, 1.1);
    this.materials?.pushRipple(3.6 * s, -0.5 * s, t + 0.2, 1.0);
  }

  public clearSelection() {
    this.selectedFishId = null;
    this.selectedPond = false;
    this.fishSystem.setSelectedFish(null);
    this.callbacks.onSelectionChange({ type: 'none' });
  }

  public selectPond() {
    this.selectedFishId = null;
    this.selectedPond = true;
    this.fishSystem.setSelectedFish(null);
    this.materials.pushRipple(0.0, 0.2, this.clock.elapsedTime, 1.0);
    this.callbacks.onSelectionChange({ type: 'pond' });
  }

  public applyCameraPreset(presetId: CameraPresetId) {
    const preset = CAMERA_PRESETS.find((p) => p.id === presetId);
    if (!preset) return;
    const s = getPondVisualScale();
    const scaleFactor = presetId === 'isometric' ? s : 1 + (s - 1) * 0.7;
    _targetPos.set(
      preset.position[0] * (presetId === 'isometric' ? 1 : scaleFactor),
      preset.position[1] * (presetId === 'isometric' ? 1 : 1 + (s - 1) * 0.3),
      preset.position[2] * (presetId === 'isometric' ? 1 : scaleFactor),
    );
    _targetLook.set(
      preset.target[0] * scaleFactor,
      preset.target[1],
      preset.target[2] * scaleFactor,
    );
    const targetZoom = preset.zoom / (1 + (s - 1) * 0.16);
    this.beginSmoothCameraTransition(_targetPos, _targetLook, targetZoom, 0.72, 0);
  }

  public zoomBy(deltaFactor: number) {
    this.cameraTransition.active = false;
    const baseZoom = this.manualZoomTarget ?? this.camera.zoom;
    this.manualZoomTarget = THREE.MathUtils.clamp(
      baseZoom * deltaFactor,
      this.controls.minZoom,
      this.controls.maxZoom,
    );
  }

  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) return;
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private tick = () => {
    if (this.disposed) return;

    const dt = Math.min(this.clock.getDelta(), 0.08);
    const elapsed = this.clock.elapsedTime;

    // Smooth eased camera pan, orbit & zoom transition
    if (this.cameraTransition.active) {
      this.cameraTransition.elapsed += dt;
      const rawT = Math.min(
        1,
        this.cameraTransition.elapsed / Math.max(0.05, this.cameraTransition.duration),
      );
      const easePan =
        rawT < 0.5
          ? 8 * rawT * rawT * rawT * rawT
          : 1 - Math.pow(-2 * rawT + 2, 4) / 2;
      const easeZoom =
        rawT < 0.5
          ? 4 * rawT * rawT * rawT
          : 1 - Math.pow(-2 * rawT + 2, 3) / 2;

      this.camera.position.lerpVectors(
        this.cameraTransition.startPos,
        this.cameraTransition.endPos,
        easePan,
      );
      this.controls.target.lerpVectors(
        this.cameraTransition.startLook,
        this.cameraTransition.endLook,
        easePan,
      );

      const breathOffset =
        this.cameraTransition.zoomBreath > 0
          ? Math.sin(rawT * Math.PI) * this.cameraTransition.zoomBreath
          : 0;
      const nextZoom = Math.max(
        this.controls.minZoom,
        THREE.MathUtils.lerp(
          this.cameraTransition.startZoom,
          this.cameraTransition.endZoom,
          easeZoom,
        ) - breathOffset,
      );

      if (Math.abs(nextZoom - this.camera.zoom) > 0.0002) {
        this.camera.zoom = nextZoom;
        this.camera.updateProjectionMatrix();
      }

      if (rawT >= 1) {
        this.cameraTransition.active = false;
      }
    } else if (this.manualZoomTarget !== null) {
      const nextZoom = THREE.MathUtils.damp(this.camera.zoom, this.manualZoomTarget, 10, dt);
      this.camera.zoom = nextZoom;
      this.camera.updateProjectionMatrix();
      if (Math.abs(nextZoom - this.manualZoomTarget) < 0.002) {
        this.camera.zoom = this.manualZoomTarget;
        this.camera.updateProjectionMatrix();
        this.manualZoomTarget = null;
      }
    }

    const s = getPondVisualScale();
    this.controls.update();
    this.controls.target.x = THREE.MathUtils.clamp(this.controls.target.x, -9.5 * s, 9.5 * s);
    this.controls.target.y = THREE.MathUtils.clamp(this.controls.target.y, -1.2, 2.0);
    this.controls.target.z = THREE.MathUtils.clamp(this.controls.target.z, -8.5 * s, 8.5 * s);
    this.materials.updateTime(elapsed);
    this.decor.update(dt, elapsed);
    this.anglerSystem.update(dt, elapsed);
    this.fishSystem.update(dt, elapsed);
    this.updateRenovationEffect(dt);

    // Periodically refresh live telemetry for currently inspected fish
    if (this.selectedFishId) {
      this.liveSyncTimer += dt;
      if (this.liveSyncTimer > 0.45) {
        this.liveSyncTimer = 0;
        const live: FishLiveState | null = this.fishSystem.getFishLiveState(this.selectedFishId);
        if (live) {
          this.callbacks.onSelectionChange({ type: 'fish', fish: live });
        }
      }
    }

    this.renderer.render(this.scene, this.camera);

    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
    } else {
      this.frameId = requestAnimationFrame(this.tick);
    }
  };

  public dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);

    this.resizeObserver?.disconnect();
    const canvas = this.renderer?.domElement;
    if (canvas) {
      canvas.removeEventListener('pointerdown', this.onPointerDown);
      canvas.removeEventListener('pointerup', this.onPointerUp);
      canvas.removeEventListener('pointermove', this.onPointerMove);
      canvas.removeEventListener('webglcontextlost', this.onContextLost);
      canvas.removeEventListener('webglcontextrestored', this.onContextRestored);
      canvas.remove();
    }

    this.controls?.dispose();
    this.fishSystem?.dispose();
    this.anglerSystem?.dispose();
    this.decor?.dispose();
    this.terrainAndWater?.dispose();
    this.renovationOwnedGeos.forEach((g) => g.dispose());
    this.renovationOwnedMats.forEach((m) => m.dispose());
    this.materials?.dispose();
    this.textures?.dispose();
    this.envRT?.dispose();
    this.renderer?.dispose();
  }
}
