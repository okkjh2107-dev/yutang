import { useCallback, useEffect, useRef, useState } from 'react';
import type { ManagementTabId } from './components/ManagementDrawer';
import { SceneHUD } from './components/SceneHUD';
import {
  activateAnglerFromAd,
  activateAutoCareFromAd,
  activateAutoRestockFromAd,
  activateAutoSellFromAd,
  advanceOneDay,
  aeratePond,
  breedFishPair,
  buyFeed,
  buyFryAndStock,
  changePondWater,
  expandPondFacility,
  feedPond,
  sellSingleFish,
  toggleAnglerOpen,
  toggleAutoCareEnabled,
  toggleAutoRestockEnabled,
  toggleAutoSellMature,
  treatPondDisease,
} from './game/simulation';
import { loadGameState, resetGameState, saveGameState } from './game/storage';
import { PondSceneManager } from './scene/PondSceneManager';
import type {
  ActionFeedback,
  AdRewardType,
  CameraPresetId,
  FeedTypeId,
  FishSpeciesId,
  GameState,
  SceneSelection,
  TimeSpeed,
} from './types/pond';

const BASE_DAY_DURATION_MS = 9000;

function computeVisibleAnglerCount(state: GameState): number {
  if (state.isBankrupt || !state.anglerOpen || state.fishes.length === 0) return 0;
  return Math.min(3, 1 + Math.floor(state.pond.facilityLevel * 0.7));
}

export default function App() {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const managerRef = useRef<PondSceneManager | null>(null);

  const [gameState, setGameState] = useState<GameState>(() => loadGameState());
  const initialFishesRef = useRef(gameState.fishes);
  const initialAnglerCountRef = useRef(computeVisibleAnglerCount(gameState));
  const initialPondLevelRef = useRef(gameState.pond.facilityLevel);

  const [timeSpeed, setTimeSpeed] = useState<TimeSpeed>(1);
  const [dayProgress, setDayProgress] = useState(0);
  const [activeDrawerTab, setActiveDrawerTab] = useState<ManagementTabId | null>(null);
  const [pendingAdType, setPendingAdType] = useState<AdRewardType | null>(null);
  const [feedback, setFeedback] = useState<ActionFeedback | null>(null);
  const feedbackTimerRef = useRef<number | null>(null);

  const [selection, setSelection] = useState<SceneSelection>({ type: 'none' });
  const [activePreset, setActivePreset] = useState<CameraPresetId>('isometric');
  const [webglError, setWebglError] = useState(false);

  const pushFeedback = useCallback((fb: ActionFeedback) => {
    setFeedback(fb);
    if (feedbackTimerRef.current !== null) {
      window.clearTimeout(feedbackTimerRef.current);
    }
    feedbackTimerRef.current = window.setTimeout(() => {
      setFeedback(null);
      feedbackTimerRef.current = null;
    }, 4500);
  }, []);

  useEffect(() => {
    return () => {
      if (feedbackTimerRef.current !== null) {
        window.clearTimeout(feedbackTimerRef.current);
      }
    };
  }, []);

  // Initialize Three.js Pond Scene once
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const manager = new PondSceneManager(container, {
      initialFishes: initialFishesRef.current,
      initialAnglerCount: initialAnglerCountRef.current,
      initialPondLevel: initialPondLevelRef.current,
      onSelectionChange: (nextSelection) => {
        setSelection(nextSelection);
      },
      onWebGLUnavailable: () => {
        setWebglError(true);
      },
    });

    managerRef.current = manager;

    return () => {
      manager.dispose();
      managerRef.current = null;
    };
  }, []);

  // Auto-save game state on every change
  useEffect(() => {
    saveGameState(gameState);
  }, [gameState]);

  // Synchronize 3D fishes, pond expansion size, and anglers with GameState
  useEffect(() => {
    managerRef.current?.syncFishes(gameState.fishes, false);
  }, [gameState.fishes]);

  useEffect(() => {
    managerRef.current?.setPondLevel(gameState.pond.facilityLevel);
  }, [gameState.pond.facilityLevel]);

  useEffect(() => {
    managerRef.current?.setAnglerCount(computeVisibleAnglerCount(gameState));
  }, [gameState.anglerOpen, gameState.pond.facilityLevel, gameState.isBankrupt, gameState.fishes.length]);

  // Pause time progression automatically on bankruptcy
  useEffect(() => {
    if (gameState.isBankrupt && timeSpeed !== 0) {
      setTimeSpeed(0);
    }
  }, [gameState.isBankrupt, timeSpeed]);

  // In-game time progression timer
  useEffect(() => {
    if (timeSpeed === 0 || gameState.isBankrupt) return;

    const tickMs = 150;
    const increment = tickMs / (BASE_DAY_DURATION_MS / timeSpeed);

    const timer = window.setInterval(() => {
      setDayProgress((prev) => {
        const next = prev + increment;
        if (next >= 1) {
          setGameState((curr) => (curr.isBankrupt ? curr : advanceOneDay(curr)));
          return next - 1;
        }
        return next;
      });
    }, tickMs);

    return () => window.clearInterval(timer);
  }, [timeSpeed, gameState.isBankrupt]);

  const handleAdvanceDay = useCallback(() => {
    setDayProgress(0);
    setGameState((curr) => {
      if (curr.isBankrupt) return curr;
      const next = advanceOneDay(curr);
      if (next.isBankrupt) {
        pushFeedback({
          ok: false,
          level: 'error',
          message: next.bankruptReason ?? '鱼塘已空塘荒废，庄园破产失败！',
        });
        return next;
      }
      const evtText =
        next.lastEvent && next.lastEvent.day === next.day
          ? `｜事件：${next.lastEvent.title}`
          : '';
      pushFeedback({
        ok: true,
        level:
          next.lastEvent && next.lastEvent.day === next.day && next.lastEvent.severity === 'danger'
            ? 'warning'
            : 'success',
        message: `已推进至第 ${next.day} 天（${next.weather}，水温 ${next.pond.temperatureC.toFixed(1)}°C${evtText}）。`,
      });
      return next;
    });
  }, [pushFeedback]);

  const handleBuyFry = useCallback(
    (speciesId: FishSpeciesId, qty: number) => {
      setGameState((curr) => {
        const res = buyFryAndStock(curr, speciesId, qty);
        pushFeedback(res.feedback);
        if (res.feedback.ok) {
          managerRef.current?.syncFishes(res.nextState.fishes, true);
        }
        return res.nextState;
      });
    },
    [pushFeedback],
  );

  const handleBuyFeed = useCallback(
    (feedId: FeedTypeId, bags: number) => {
      setGameState((curr) => {
        const res = buyFeed(curr, feedId, bags);
        pushFeedback(res.feedback);
        return res.nextState;
      });
    },
    [pushFeedback],
  );

  const handleFeedPond = useCallback(
    (feedId: FeedTypeId, amountKg: number) => {
      setGameState((curr) => {
        const res = feedPond(curr, feedId, amountKg);
        pushFeedback(res.feedback);
        if (res.feedback.ok) {
          managerRef.current?.triggerFeedingEffect();
        }
        return res.nextState;
      });
    },
    [pushFeedback],
  );

  const handleAeratePond = useCallback(() => {
    setGameState((curr) => {
      const res = aeratePond(curr);
      pushFeedback(res.feedback);
      if (res.feedback.ok) {
        managerRef.current?.triggerCareRipple();
      }
      return res.nextState;
    });
  }, [pushFeedback]);

  const handleChangeWater = useCallback(() => {
    setGameState((curr) => {
      const res = changePondWater(curr);
      pushFeedback(res.feedback);
      if (res.feedback.ok) {
        managerRef.current?.triggerCareRipple();
      }
      return res.nextState;
    });
  }, [pushFeedback]);

  const handleTreatDisease = useCallback(() => {
    setGameState((curr) => {
      const res = treatPondDisease(curr);
      pushFeedback(res.feedback);
      if (res.feedback.ok) {
        managerRef.current?.triggerCareRipple();
      }
      return res.nextState;
    });
  }, [pushFeedback]);

  const handleExpandPond = useCallback(() => {
    setGameState((curr) => {
      const res = expandPondFacility(curr);
      pushFeedback(res.feedback);
      if (res.feedback.ok) {
        managerRef.current?.setPondLevel(res.nextState.pond.facilityLevel);
      }
      return res.nextState;
    });
  }, [pushFeedback]);

  const handleToggleAnglerOpen = useCallback(() => {
    setGameState((curr) => {
      const res = toggleAnglerOpen(curr);
      pushFeedback(res.feedback);
      return res.nextState;
    });
  }, [pushFeedback]);

  const handleToggleAutoSellMature = useCallback(() => {
    setGameState((curr) => {
      const res = toggleAutoSellMature(curr);
      pushFeedback(res.feedback);
      if (res.feedback.ok) {
        managerRef.current?.syncFishes(res.nextState.fishes, false);
      }
      return res.nextState;
    });
  }, [pushFeedback]);

  const handleWatchAd = useCallback((adType: AdRewardType) => {
    setPendingAdType(adType);
  }, []);

  const handleCompleteAd = useCallback(
    (adType: AdRewardType) => {
      setPendingAdType(null);
      setGameState((curr) => {
        const res =
          adType === 'auto_care'
            ? activateAutoCareFromAd(curr)
            : adType === 'auto_restock'
              ? activateAutoRestockFromAd(curr)
              : adType === 'angler_open'
                ? activateAnglerFromAd(curr)
                : activateAutoSellFromAd(curr);
        pushFeedback(res.feedback);
        if (res.feedback.ok) {
          managerRef.current?.syncFishes(res.nextState.fishes, true);
          managerRef.current?.triggerCareRipple();
        }
        return res.nextState;
      });
    },
    [pushFeedback],
  );

  const handleCancelAd = useCallback(() => {
    setPendingAdType(null);
  }, []);

  const handleToggleAutoCare = useCallback(() => {
    setGameState((curr) => {
      const res = toggleAutoCareEnabled(curr);
      pushFeedback(res.feedback);
      return res.nextState;
    });
  }, [pushFeedback]);

  const handleToggleAutoRestock = useCallback(() => {
    setGameState((curr) => {
      const res = toggleAutoRestockEnabled(curr);
      pushFeedback(res.feedback);
      return res.nextState;
    });
  }, [pushFeedback]);

  const handleBreedPair = useCallback(
    (speciesId: FishSpeciesId) => {
      setGameState((curr) => {
        const res = breedFishPair(curr, speciesId);
        pushFeedback(res.feedback);
        if (res.feedback.ok) {
          managerRef.current?.syncFishes(res.nextState.fishes, true);
        }
        return res.nextState;
      });
    },
    [pushFeedback],
  );

  const handleSellSingleFish = useCallback(
    (fishId: string) => {
      setGameState((curr) => {
        const res = sellSingleFish(curr, fishId);
        pushFeedback(res.feedback);
        if (res.feedback.ok) {
          managerRef.current?.syncFishes(res.nextState.fishes, false);
        }
        return res.nextState;
      });
    },
    [pushFeedback],
  );

  const handleResetSave = useCallback(() => {
    const fresh = resetGameState();
    setGameState(fresh);
    setTimeSpeed(1);
    setDayProgress(0);
    setActiveDrawerTab(null);
    setPendingAdType(null);
    managerRef.current?.clearSelection();
    managerRef.current?.setPondLevel(fresh.pond.facilityLevel);
    managerRef.current?.syncFishes(fresh.fishes, true);
    managerRef.current?.setAnglerCount(computeVisibleAnglerCount(fresh));
    pushFeedback({
      ok: true,
      level: 'success',
      message: '已重置水产庄园存档，重新开始第 1 天经营！',
    });
  }, [pushFeedback]);

  const handleSelectFishInScene = useCallback((fishId: string) => {
    setActiveDrawerTab(null);
    managerRef.current?.selectFishById(fishId);
  }, []);

  const handleSelectPreset = useCallback((presetId: CameraPresetId) => {
    setActivePreset(presetId);
    managerRef.current?.applyCameraPreset(presetId);
  }, []);

  const handleZoomIn = useCallback(() => {
    managerRef.current?.zoomBy(1.18);
  }, []);

  const handleZoomOut = useCallback(() => {
    managerRef.current?.zoomBy(0.84);
  }, []);

  const handleClearSelection = useCallback(() => {
    managerRef.current?.clearSelection();
  }, []);

  return (
    <main className="relative h-dvh w-screen overflow-hidden bg-[#d6e7df]">
      <div
        ref={mountRef}
        className="h-full w-full"
        aria-label="梦幻鱼塘水产庄园 3D 场景视口"
      />

      {webglError ? (
        <div className="fixed inset-0 z-20 flex items-center justify-center bg-[#d6e7df] p-6">
          <div className="manor-surface max-w-md rounded-2xl border border-[#182622]/15 p-6 text-center">
            <h2 className="font-display text-lg font-semibold text-[#142420]">
              当前浏览器暂不支持 WebGL 3D 渲染
            </h2>
            <p className="mt-2 text-sm leading-relaxed text-[#4b5e57]">
              请开启浏览器硬件加速或使用最新版 Chrome、Safari、Edge 浏览器以体验《梦幻鱼塘：水产庄园》完整 3D 场景与经营玩法。
            </p>
          </div>
        </div>
      ) : (
        <SceneHUD
          gameState={gameState}
          timeSpeed={timeSpeed}
          dayProgress={dayProgress}
          feedback={feedback}
          selection={selection}
          activePreset={activePreset}
          activeDrawerTab={activeDrawerTab}
          pendingAdType={pendingAdType}
          onToggleDrawerTab={setActiveDrawerTab}
          onSetTimeSpeed={setTimeSpeed}
          onAdvanceDay={handleAdvanceDay}
          onSelectPreset={handleSelectPreset}
          onZoomIn={handleZoomIn}
          onZoomOut={handleZoomOut}
          onClearSelection={handleClearSelection}
          onSelectFishInScene={handleSelectFishInScene}
          onBuyFry={handleBuyFry}
          onBuyFeed={handleBuyFeed}
          onFeedPond={handleFeedPond}
          onAeratePond={handleAeratePond}
          onChangeWater={handleChangeWater}
          onTreatDisease={handleTreatDisease}
          onExpandPond={handleExpandPond}
          onToggleAnglerOpen={handleToggleAnglerOpen}
          onToggleAutoSellMature={handleToggleAutoSellMature}
          onWatchAd={handleWatchAd}
          onCompleteAd={handleCompleteAd}
          onCancelAd={handleCancelAd}
          onToggleAutoCare={handleToggleAutoCare}
          onToggleAutoRestock={handleToggleAutoRestock}
          onBreedPair={handleBreedPair}
          onSellSingleFish={handleSellSingleFish}
          onResetSave={handleResetSave}
        />
      )}
    </main>
  );
}
